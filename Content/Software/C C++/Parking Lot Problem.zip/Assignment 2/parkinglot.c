/*
	Adam Knox
	ark043
	CMPT 317
	Assignment 2

	This program was built using Visual Studio.
	
		this implementation will only work for a lot size of 9 at 
	the most. Fairly minimal adjustments would be neede to change this, 
	but I don't see the point since there are only 5 stalls in the lot.
		By separating out the constraint relaxation and the actual search
	algorithms, this program makes it simpler to implement more complicated
	procedures. 
		Another relaxation stategy could be to ignor rank, and look for the
	constraints that cause the most problems. By relaxing those, more people
	can get what they want, but potentially at the expense of more senior profs.
	This method may also require more computiation to complete since the constraints
	that impose the strictest order must be discovered.
		It would be fairly straightforward to change the problem for this program. just
	update the 2 structures to contain different details and constraints, then adjust the
	rules to match the new scenario.  The most complicated change would be to
	change the neighbour parameter since it changes how the recursion functions.

	To compile, run 
		gcc -Wall parkinglot.c -o parkinglot
	in terminal, then run
		./parkinglot
	to start the program. 

	CONSTRAINT_SET in the header file may be changed to select a different parameter set
	
*/

#include "parkinglot.h"

int main () {
	int i = 0;

	Stall stallList[NUM_STALLS_AND_PROFS];			//List of professors
	Occupant occuList[NUM_STALLS_AND_PROFS];		//list of stalls
	int profSenorityOrder[NUM_STALLS_AND_PROFS];	//the professor senority order (index 0 of this list contains index of least senior prof from occuList)



	//Populate the lot and prof lists with stats and requirements
	populateLot(stallList);
	if (CONSTRAINT_SET == 1) {
		populateProfs1(occuList);
	} else if (CONSTRAINT_SET == 2) {
		populateProfs2(occuList);
	} else if (CONSTRAINT_SET == 3) {
		populateProfs3(occuList);
	} else if (CONSTRAINT_SET == 4) {
		populateProfs4(occuList);
	} else if (CONSTRAINT_SET == 5) {
		populateProfs5(occuList);
	} 



	//Find a configuration that holds to all constraints
	char* result = constraintSatisfaction(stallList, occuList, 0, -1);
	


	//Could not satisfy all constraints, so try again with the constraints being dropped one at a time
	if (result == NULL) {

		//Get the prof condition relaxation order
		rankProfs(occuList, profSenorityOrder);

		//iterate through each prof starting with the lowest ranked until a result is achieved
		printf("\n\nLIST OF RELAXED CONSTRAINTS\n");
		for (i = 0; ((i < NUM_STALLS_AND_PROFS) && (result == NULL)); i++) {
			////drop contraints for the current prof one by one until a result is achieved////

			//drop adjacency constraint
			printf("dropped adjacency for %i\n", profSenorityOrder[i]);
			occuList[profSenorityOrder[i]].adjacentID = -1;
			result = constraintSatisfaction(stallList, occuList, 0, -1);
		
			//drop location constraint
			if (result == NULL) {
				printf("\tdropped location for %i\n", profSenorityOrder[i]);
				occuList[profSenorityOrder[i]].location = either;
				result = constraintSatisfaction(stallList, occuList, 0, -1);
			}
		
			//drop plugin constraint
			if (result == NULL) {
				printf("\t\tdropped plugin for %i\n", profSenorityOrder[i]);
				occuList[profSenorityOrder[i]].needsPower = any;
				result = constraintSatisfaction(stallList, occuList, 0, -1);
			}

		}

		printf("\n\n");
	}



	//print the configuration
	if (result != NULL) {
			printf("LOT CONFIGURATION\n");
		for (i = 0; i < NUM_STALLS_AND_PROFS; i++) {
			int index = 0;
			char indexChar = result[i];
			//get the proper character (the current id) out of the result string
			index = atoi(&indexChar);
			//print the stall allocation with the stalls indexed starting at 1
			printf("stall %i: %s\n", i+1, occuList[index].name);
		}
	} else {
		printf("no match found\n");
	}


	printf("hit enter to end program\n");
	char val;
	scanf("%c", &val);

	return 0;
}




/*
	checks for a lot allocation that satisfies all requirements made by the professors

	stallList: the list of stalls available for professors to use
	occuList: the list of professors to assign to parking lot stalls
	currentDepth: the number of recursions this function is in (ex, 0 means this is the top level)
	profID: if not ' ', then this is the only prof that will be checked for this stall

	return: a list of the stall occupants starting with the 0th stall for the first character in the string
*/
char* constraintSatisfaction(Stall* stallList, Occupant* occuList, int currentDepth, char profID) {
	int i = 0;
	char* order;


	//if all parking stalls are taken, then return the successful configuration, providing a neighbour was not specified
	if (currentDepth == NUM_STALLS_AND_PROFS && profID == -1) {
		 order = (char*) malloc(sizeof(char)*NUM_STALLS_AND_PROFS);

		//create the return list
		for (i = 0; i < NUM_STALLS_AND_PROFS; i++) {
			sprintf(&order[i], "%d", stallList[i].occupantID);
		}

		//return the list
		return order;
	} else if (currentDepth == NUM_STALLS_AND_PROFS && profID >= 0) {
		return NULL;
	}


	//not all taken, so try each unassigned prof in the stall
	for (i = 0; i < NUM_STALLS_AND_PROFS; i++) {

		//check the constraints for this professor.
		//only check this professor if stall is empty
		//only check this professor if they are the specified prof, or no prof was specified
		if ((occuList[i].stall == -1) && ((profID == -1) || (profID == i))) {

			//Place the professor in the stall
			stallList[currentDepth].occupantID = i;
			occuList[i].stall = currentDepth;

			////check if the constraints are met////
			if (
				//check plugin availability requirement
				(
					(occuList[i].needsPower == any) //don't care if a plug is there
					||
					(occuList[i].needsPower == stallList[currentDepth].hasPower)	//has a requirement
				)
				&&
				//check lot side requirement
				(correctLotSide(occuList[i].location, currentDepth) == 1)
			) {
					//check if neighbour is acceptable. Doesn't care or left neighbour agrees
					if (
						(occuList[i].adjacentID == -1) 
						|| 
						((currentDepth > 0) && (stallList[currentDepth-1].occupantID  == occuList[i].adjacentID))
					) {
						//check that the rest of the prof placements fit within constraints
						order = constraintSatisfaction(stallList, occuList, currentDepth + 1, -1);
					}


					//check if this combination will be valid with the right neighbour specified to be the agreeable neighbour
					else {
						//check that the rest of the prof placements fit within constraints
						order = constraintSatisfaction(stallList, occuList, currentDepth + 1, occuList[currentDepth].adjacentID);		
					}

					//A working combination was found, so return it
					if (order != NULL) {
						return order;
					}
				}


			//constraints are not met so remove prof from stall and try another
			stallList[currentDepth].occupantID = -1;
			occuList[i].stall = -1;
		}
	}
	
	//no combination can satisfy the constraints so return null
	return NULL;
}





/*
	Finds the prof ranking, with the lowliest prof at index 0, and the highest ranked prof in the last index

	occuList: the list of profs to rank
	profSenorityOrder: the array in which to set the order.  length should be equal to the number of profs
*/
void rankProfs(Occupant* occuList, int* profSenorityOrder) {
	int i = 0;
	int j = 0;

	int profSet[NUM_STALLS_AND_PROFS];
	
		printf("SENORITY/RANK ORDER. LOWLIEST ID ON LEFT\n");
		srand((unsigned int)time(NULL));

		////Get the order of prof senority so the constraint dropping happens in the proper order////
		//initialize arrays
		for (i = 0; i < NUM_STALLS_AND_PROFS; i++) {
			profSet[i] = 0;
			profSenorityOrder[i] = -1;
		}

		//set each order position
		for (i = 0; i < NUM_STALLS_AND_PROFS; i++) {
			//Set this position to the first unset prof. keep looking until the position is set
			for (j = 0; (j < NUM_STALLS_AND_PROFS); j++) {
				if (profSet[j] == 0) {
					profSenorityOrder[i] = j;
					profSet[j] = 1;
					goto a;
				}
			}
			a:

			//check if any other unset profs fill this position better
			for (j = 0; j < NUM_STALLS_AND_PROFS; j++) {
				if (profSet[j] == 0) {
					//if the current prof is less senior than the set prof, then set this prof
					if (
							(occuList[profSenorityOrder[i]].senority > occuList[j].senority)	//check senority
							||
							((occuList[profSenorityOrder[i]].senority == occuList[j].senority) && (occuList[profSenorityOrder[i]].rank > occuList[j].rank)) //check rank if same senority
						) {
						profSet[profSenorityOrder[i]] = 0;
						profSenorityOrder[i] = j;
						profSet[j] = 1;
					}

					//if the current prof has the same senority and rank, then set one of the to at random
					else if ((occuList[profSenorityOrder[i]].senority == occuList[j].senority) && (occuList[profSenorityOrder[i]].rank == occuList[j].rank)) {
						if (rand() % 2 == 0) {
							profSet[profSenorityOrder[i]] = 0;
							profSenorityOrder[i] = j;
							profSet[j] = 1;
						}
					}
				}
			}
			printf("%i ", profSenorityOrder[i]);
		}
} 





/*
	Checks if the given prof has been assigned to their preferred lot side

	requestedSide: the side (east/west) the prof wants
	stallNum: the stall on which to check the lot side
	
	Return: 0 if not on the correct side; 1 if on the correct side
*/
int correctLotSide(Directions requestedSide, int stallNum) {
	Directions actualSide;
	//return true if the prof doesn't care
	if (requestedSide == either) {
		return 1;
	}

	//return true if this is the center stall in an odd number of stalls
	if ((NUM_STALLS_AND_PROFS - stallNum) == (stallNum + 1)) {
		return 1;
	}

	//get the side the stall is on. take into account that integers round down
	if (stallNum < NUM_STALLS_AND_PROFS/2) {
		actualSide = west;
	} else {
		actualSide = east;
	}

	//check if prof wants to be placed here
	if (requestedSide == actualSide) {
		return 1;	
	} else {
		return 0;
	}
}




//Populates the parking lot
void populateLot(Stall* stallList) {
	stallList[0].position = 0;
	stallList[0].hasPower = yes;
	stallList[0].occupantID = ' ';

	stallList[1].position = 1;
	stallList[1].hasPower = no;
	stallList[1].occupantID = ' ';

	stallList[2].position = 2;
	stallList[2].hasPower = yes;
	stallList[2].occupantID = ' ';

	stallList[3].position = 3;
	stallList[3].hasPower = no;
	stallList[3].occupantID = ' ';

	stallList[4].position = 4;
	stallList[4].hasPower = yes;
	stallList[4].occupantID = ' ';
}




//Populates with the configuration given on the assignment sheet
void populateProfs1(Occupant* occuList) {
	//Setup person list. IDs are the index of the person. -1 for no neighbour preference
	occuList[0].stall = -1;
	occuList[0].name = "Sydney J. Hurtubise";
	occuList[0].rank = full;
	occuList[0].senority = 3;
	occuList[0].location = east;
	occuList[0].adjacentID = 3;
	occuList[0].needsPower = yes;

	occuList[1].stall = -1;
	occuList[1].name = "Horace P. Hopozopen";
	occuList[1].rank = assistant;
	occuList[1].senority = 1;
	occuList[1].location = west;
	occuList[1].adjacentID = 2;
	occuList[1].needsPower = any;

	occuList[2].stall = -1;
	occuList[2].name = "Rogatien \"G\" Cumberbatch ";
	occuList[2].rank = associate;
	occuList[2].senority = 3;
	occuList[2].location = west;
	occuList[2].adjacentID = -1;
	occuList[2].needsPower = yes;

	occuList[3].stall = -1;
	occuList[3].name = "Natch de Montreal";
	occuList[3].rank = associate;
	occuList[3].senority = 2;
	occuList[3].location = east;
	occuList[3].adjacentID = 0;
	occuList[3].needsPower = no;

	occuList[4].stall = -1;
	occuList[4].name = "R. M. Duck-Lewis";
	occuList[4].rank = associate;
	occuList[4].senority = 1;
	occuList[4].location = east;
	occuList[4].adjacentID = 1;
	occuList[4].needsPower = any;
}




//Populates with config that needs conflic resolutions up to and including third lowliest prof
void populateProfs2(Occupant* occuList) {
	//Setup person list. IDs are the index of the person. -1 for no neighbour preference
	occuList[0].stall = -1;
	occuList[0].name = "Sydney J. Hurtubise";
	occuList[0].rank = full;
	occuList[0].senority = 3;
	occuList[0].location = west;
	occuList[0].adjacentID = 3;
	occuList[0].needsPower = yes;

	occuList[1].stall = -1;
	occuList[1].name = "Horace P. Hopozopen";
	occuList[1].rank = full;
	occuList[1].senority = 1;
	occuList[1].location = west;
	occuList[1].adjacentID = 2;
	occuList[1].needsPower = any;

	occuList[2].stall = -1;
	occuList[2].name = "Rogatien \"G\" Cumberbatch ";
	occuList[2].rank = full;
	occuList[2].senority = 3;
	occuList[2].location = west;
	occuList[2].adjacentID = 3;
	occuList[2].needsPower = yes;

	occuList[3].stall = -1;
	occuList[3].name = "Natch de Montreal";
	occuList[3].rank = full;
	occuList[3].senority = 2;
	occuList[3].location = east;
	occuList[3].adjacentID = 0;
	occuList[3].needsPower = no;

	occuList[4].stall = -1;
	occuList[4].name = "R. M. Duck-Lewis";
	occuList[4].rank = full;
	occuList[4].senority = 1;
	occuList[4].location = east;
	occuList[4].adjacentID = 1;
	occuList[4].needsPower = any;
}




//Populates with config that needs conflict resolution through constraint relaxation for second lowliest prof
void populateProfs3(Occupant* occuList) {
	//Setup person list. IDs are the index of the person. -1 for no neighbour preference
	occuList[0].stall = -1;
	occuList[0].name = "Sydney J. Hurtubise";
	occuList[0].rank = full;
	occuList[0].senority = 3;
	occuList[0].location = west;
	occuList[0].adjacentID = 1;
	occuList[0].needsPower = yes;

	occuList[1].stall = -1;
	occuList[1].name = "Horace P. Hopozopen";
	occuList[1].rank = associate;
	occuList[1].senority = 2;
	occuList[1].location = east;
	occuList[1].adjacentID = 0;
	occuList[1].needsPower = no;

	occuList[2].stall = -1;
	occuList[2].name = "Rogatien \"G\" Cumberbatch ";
	occuList[2].rank = assistant;
	occuList[2].senority = 1;
	occuList[2].location = either;
	occuList[2].adjacentID = 2;
	occuList[2].needsPower = yes;

	occuList[3].stall = -1;
	occuList[3].name = "Natch de Montreal";
	occuList[3].rank = assistant;
	occuList[3].senority = 2;
	occuList[3].location = east;
	occuList[3].adjacentID = 3;
	occuList[3].needsPower = any;

	occuList[4].stall = -1;
	occuList[4].name = "R. M. Duck-Lewis";
	occuList[4].rank = assistant;
	occuList[4].senority = 1;
	occuList[4].location = east;
	occuList[4].adjacentID = 4;
	occuList[4].needsPower = no;
}




//Populates with config that needs no conflict resolution
void populateProfs4(Occupant* occuList) {
	//Setup person list. IDs are the index of the person. -1 for no neighbour preference
	occuList[0].stall = -1;
	occuList[0].name = "Sydney J. Hurtubise";
	occuList[0].rank = full;
	occuList[0].senority = 3;
	occuList[0].location = east;
	occuList[0].adjacentID = 3;
	occuList[0].needsPower = any;

	occuList[1].stall = -1;
	occuList[1].name = "Horace P. Hopozopen";
	occuList[1].rank = assistant;
	occuList[1].senority = 1;
	occuList[1].location = east;
	occuList[1].adjacentID = -1;
	occuList[1].needsPower = any;

	occuList[2].stall = -1;
	occuList[2].name = "Rogatien \"G\" Cumberbatch ";
	occuList[2].rank = associate;
	occuList[2].senority = 3;
	occuList[2].location = west;
	occuList[2].adjacentID = -1;
	occuList[2].needsPower = yes;

	occuList[3].stall = -1;
	occuList[3].name = "Natch de Montreal";
	occuList[3].rank = associate;
	occuList[3].senority = 2;
	occuList[3].location = west;
	occuList[3].adjacentID = 0;
	occuList[3].needsPower = no;

	occuList[4].stall = -1;
	occuList[4].name = "R. M. Duck-Lewis";
	occuList[4].rank = associate;
	occuList[4].senority = 1;
	occuList[4].location = east;
	occuList[4].adjacentID = -1;
	occuList[4].needsPower = any;
}




//Populates with config that needs conflict resolution through constraint relaxation for lowliest prof
void populateProfs5(Occupant* occuList) {
	//Setup person list. IDs are the index of the person. -1 for no neighbour preference
	occuList[0].stall = -1;
	occuList[0].name = "Sydney J. Hurtubise";
	occuList[0].rank = full;
	occuList[0].senority = 3;
	occuList[0].location = west;
	occuList[0].adjacentID = 3;
	occuList[0].needsPower = any;

	occuList[1].stall = -1;
	occuList[1].name = "Horace P. Hopozopen";
	occuList[1].rank = assistant;
	occuList[1].senority = 1;
	occuList[1].location = west;
	occuList[1].adjacentID = 2;
	occuList[1].needsPower = any;

	occuList[2].stall = -1;
	occuList[2].name = "Rogatien \"G\" Cumberbatch ";
	occuList[2].rank = associate;
	occuList[2].senority = 3;
	occuList[2].location = east;
	occuList[2].adjacentID = -1;
	occuList[2].needsPower = no;

	occuList[3].stall = -1;
	occuList[3].name = "Natch de Montreal";
	occuList[3].rank = associate;
	occuList[3].senority = 2;
	occuList[3].location = east;
	occuList[3].adjacentID = 2;
	occuList[3].needsPower = yes;

	occuList[4].stall = -1;
	occuList[4].name = "R. M. Duck-Lewis";
	occuList[4].rank = full;
	occuList[4].senority = 7;
	occuList[4].location = either;
	occuList[4].adjacentID = 1;
	occuList[4].needsPower = any;
}






/*
	Adam Knox
	ark043
	CMPT 317
	Assignment 2
*/

#ifndef PARKINGLOT_H
#define PARKINGLOT_H

//1: configuration given on the assignment sheet (rank order: 14320)
//2: RELAXATION: third lowest prof; RANKING: uses random selection between prof 1/4 and 0/2
//3: RELAXATION: second lowest prof; RANKING ORDER: uses rank for 0/2 and needs to go to seniority for 3 and needs to choose randomly betmeen 1/4
//4: RELAXATION: none
//5: RELAXATION: lowest prof
#define CONSTRAINT_SET 1	//1 to 5. the set of constraints to use for the profs
#define NUM_STALLS_AND_PROFS 5	//The number of professors/stalls to sort.  must be no greater than 9.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

typedef enum {assistant = 0, associate = 1, full = 2} Ranks;
typedef enum {east, west, either} Directions;
typedef enum {yes, no, any} Power;

//represents one professor
//contains the data required required for a single professor
typedef struct {
	int stall;
	char* name;
	Ranks rank;
	int senority;
	Directions location;
	char adjacentID;
	Power needsPower;

} Occupant;

//represents one stall
//Contains the data requird for a single stall
typedef struct {
	int position;	/*0 is the stall furthes west*/
	Power hasPower;
	int occupantID;
} Stall;

/*
	checks for a lot allocation that satisfies all requirements made by the professors

	stallList: the list of stalls available for professors to use
	occuList: the list of professors to assign to parking lot stalls
	currentDepth: the number of recursions this function is in (ex, 0 means this is the top level)
	profID: if not ' ', then this is the only prof that will be checked for this stall

	return: a list of the stall occupants starting with the 0th stall for the first character in the string
*/
char* constraintSatisfaction(Stall*, Occupant*, int, char);

/*
	Finds the prof ranking, with the lowliest prof at index 0, and the highest ranked prof in the last index

	occuList: the list of profs to rank
	profSenorityOrder: the array in which to set the order.  length should be equal to the number of profs
*/
void rankProfs(Occupant*, int*);

/*
	Checks if the given prof has been assigned to their preferred lot side

	requestedSide: the side (east/west) the prof wants
	stallNum: the stall on which to check the lot side
	
	Return: 0 if not on the correct side; 1 if on the correct side
*/
int correctLotSide(Directions, int);

//Populates the parking lot
void populateLot(Stall*);

//Populates with the configuration given on the assignment sheet
void populateProfs1(Occupant*);

//Populates with config that needs conflic resolutions up to and including third lowliest prof
void populateProfs2(Occupant*);

//Populates with config that needs conflict resolution through constraint relaxation for second lowliest prof
void populateProfs3(Occupant*);

//Populates with config that needs no conflict resolution
void populateProfs4(Occupant*);

//Populates with config that needs conflict resolution through constraint relaxation for lowliest prof
void populateProfs5(Occupant*);

#endif

#include <stdio.h>
int Square(int N,int* squareNumber)
{
  if (squareNumber == NULL)
  {
    return(-1);
  }
  (*squareNumber)++;
  if (N == 0) return (0);
  return (Square ((N-1),squareNumber) + N + N - 1);
}

#include "implementthread.h"
#include "calculation.h"
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>

/* an array that contains all the pids of the children threads */
static pthread_t activeThreads[MAX_THREADS];
/* The number of squares that need to be calculated by each thread */
static int numberOfSquares;
/* The number of threads to be created */
static int threadNumber;
/* The start times and squares calculated by the different threads */
static struct timeval startTimes[MAX_THREADS];
static int squaresCalculated[MAX_THREADS];

void* threadTask(void *ptr)
{
   int thisThreadNumber = 0;
   struct timeval startTime;
   struct timeval endTime;
   long seconds = 0;
   long microSeconds = 0;
   int i = 1;
   /* Gets the index associated with this pid */
   while (activeThreads[thisThreadNumber] != pthread_self() && thisThreadNumber < threadNumber)
   {
     thisThreadNumber++;
   }
   squaresCalculated[thisThreadNumber] = 0;
   /* Get the start time */
   gettimeofday(&startTime,NULL);
   startTimes[thisThreadNumber] = startTime;
   /*printf("Got to procedure threadTask\n");*/
   /* Calculate squares */
   while (i <= numberOfSquares)
   {
    Square(i,&squaresCalculated[thisThreadNumber]);
    i++;
   }
   gettimeofday(&endTime,NULL);
   /* Converts everything to microseconds then gets the difference between the start and end time */
   microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTime.tv_sec * 1000000) + startTime.tv_usec);
   /* Gets the whole seconds out of the time difference */
   seconds = microSeconds / 1000000;
   /* Gets the remaining microseconds after the seconds are removed */
   microSeconds = microSeconds % 1000000;
   printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
   printf("This child called Square %i times\n", squaresCalculated[thisThreadNumber]);
   pthread_exit(NULL);
}

void startThreads(int numberOfThreads, int squaresToCalculate)
{
  pthread_t pID;
 int i = 0;
 /*printf("Got to procedure startThreads\n");*/
 numberOfSquares = squaresToCalculate;
 threadNumber = numberOfThreads;
 while (i<numberOfThreads)
 {
   if (pthread_create(&pID,NULL,threadTask,NULL)!= 0)
   {
     printf("Error creating a thread.\n");
   }
   else
   {
     /* Adds the child to the active threads */
     activeThreads[i] = pID;
   }
   i++;
 }
 
}

void myWait(int time)
{
  sleep(time);
}

void killThreads()
{
  int i = 0;
  long seconds = 0;
  long microSeconds = 0;
  struct timeval endTime;
 /* printf("Got to procedure killThreads\n");*/
 /* printf("threadNumber is %d\n",threadNumber);*/
  while(i<threadNumber)
  {
    if (pthread_cancel(activeThreads[i]) == 0)
    {
      /*printf("killed before finished\n");*/
      gettimeofday(&endTime,NULL);
      /* Converts everything to microseconds then gets the difference between the start and end time */
      microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTimes[i].tv_sec * 1000000) + startTimes[i].tv_usec);
      /* Gets the whole seconds out of the time difference */
      seconds = microSeconds / 1000000;
      /* Gets the remaining microseconds after the seconds are removed */
      microSeconds = microSeconds % 1000000;
      printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
      printf("This child called Square %i times\n", squaresCalculated[i]);
    }
    i++;
  }
}

int main(int argc, char* argv[])
{
  return mainThread(argc, argv);
}

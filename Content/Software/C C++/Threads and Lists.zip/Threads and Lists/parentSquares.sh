#!/bin/sh

#Adam Knox & Devon Dietrich
#ark043 & djd232
#11049279 & 11053192
#CMPT 332
#Assignment 1
#Part B

#NOTE: the programs being run by this script must be in the same directory as runThreadProg.sh

#create a variable that dictates when to end the program. 0 means keep running
endProg=0

#set default operation parameters
M=4		#Number of child threads to creat
D=3		#The thread kill deadline (seconds)
N=2000000	#The number of squares to compute (square(1) to square(N))

#loop until the user wants to end the program
while (`test $endProg -eq 0`); do

	#show the menu of execution options
	echo ''
	echo ''
	echo '(1) windows'
	echo '(2) UBC Pthreads'
	echo '(3) UNIX Processes'
	echo '(4) Posix Threads'
	echo '(5) Quit'
	echo 'Please Select a threading method to run using the above menu: '

	#get the selection from the user
	read inputChoice

	#execute the proper behaviour based on the user's inputed data
	if ( `test $inputChoice -eq 1` ); then		#run the windows threading method
		echo 'you selected option 1; windows threading'
		#ensure that the person is on a windows computer
		if (`test "$OSTYPE" = "cygwin"`); then
			#select the number of threads to create
			echo 'please select the number of threads to create'
			read M

			#select the deadline time
			echo 'please select the deadline (in seconds)'
			read D

			#select the largest square to compute
			echo 'please select the largest square to compute'
			read N

			#execute the program using the given parameters
			./windows.exe $M $N $D

		#not on a windows computer so don't run the windows method
		else
			echo 'Sorry, you are not on a windows computer so you cannot use the windows threading method'
		fi

	#run the UBC pthreads method if the user selects option 2
	elif ( `test $inputChoice -eq 2` ); then
	        echo 'you selected option 2; UBC pthreads'

		#select the number of threads to create
                echo 'please select the number of threads to create'
                read M

                #select the deadline time
                echo 'please select the deadline (in seconds)'
                read D

                #select the largest square to compute
                echo 'please select the largest square to compute' 
                read N

                #execute the program using the given parameters
		./pthread $M $N $D

	#run the UNIX processes method if the user selects option 3
	elif ( `test $inputChoice -eq 3` ); then
	        echo 'you selected option 3; UNIX processes'

                #select the number of threads to create
                echo 'please select the number of threads to create'
                read M

                #select the deadline time
                echo 'please select the deadline (in seconds)'
                read D

                #select the largest square to compute
                echo 'please select the largest square to compute' 
                read N

                #execute the program using the given parameters
		./unixprocess $M $N $D

	#run the posix thread method if the user selects option 4
	elif ( `test $inputChoice -eq 4` ); then
	        echo 'you selected option 4; posix threads'

                #select the number of threads to create
                echo 'please select the number of threads to create'
                read M

                #select the deadline time
                echo 'please select the deadline (in seconds)'
                read D

                #select the largest square to compute
                echo 'please select the largest square to compute' 
                read N

                #execute the program using the given parameters
		./posixthread $M $N $D

	#end the program if the user selects option 5
	elif ( `test $inputChoice -eq 5` ); then
	        echo 'Goodbye'
		endProg=1

	#bad input, so try again
	else
		echo 'the option you selected is invalid.'
		endProg=0
	fi
done

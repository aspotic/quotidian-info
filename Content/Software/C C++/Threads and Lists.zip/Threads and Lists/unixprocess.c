#include "implementthread.h"
#include "calculation.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <signal.h>
/* Stores the pid's of all the child processes */
static pid_t active_processes[MAX_THREADS];
/* The start time of the child process*/
static struct timeval startTime;
/* Total number of squares calculated by the child process*/
static int squaresCalculated;
/* The number of threads to be created*/
static int threadNumber;

void signalHandler(int signalNumber)
{
  long seconds = 0;
  long microSeconds = 0;
  struct timeval endTime;
  gettimeofday(&endTime,NULL);
  /* converts all of endTime and startTime to microseconds then subtracts startTime from endTime */
  microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTime.tv_sec * 1000000) + startTime.tv_usec);
  /* Devides time taken in microseconds to get time taken in seconds. */
  seconds = microSeconds / 1000000;
  /* Takes the mod of the total time in microseconds to remove the whole seconds from it */
  microSeconds = microSeconds % 1000000;
  printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
  printf("This child called Square %i times\n", squaresCalculated);
  /*printf("the signal handled, singal number = %i\n",SIGALRM);*/
  exit(-1);
}

void threadTask(int squaresToCalculate, int currentThread)
{
  struct timeval endTime;
  long seconds = 0;
  long microSeconds = 0;
  int i = 1;
  /*printf("Got to procedure threadTask\n");*/
  squaresCalculated = 0;
  gettimeofday(&startTime,NULL);
  while (i <= squaresToCalculate)
  {
   Square(i,&squaresCalculated);
   i++;
  }
  gettimeofday(&endTime,NULL);
  /* converts all of endTime and startTime to microseconds then subtracts startTime from endTime */
  microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTime.tv_sec * 1000000) + startTime.tv_usec);
  /* Devides time taken in microseconds to get time taken in seconds. */
  seconds = microSeconds / 1000000;
  /* Devides time taken in microseconds to get time taken in seconds. */
  microSeconds = microSeconds % 1000000;
  printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
  printf("This child called Square %i times\n", squaresCalculated);
  exit(0);
}

void startThreads(int numberOfThreads, int squaresToCalculate)
{
  /* handler is the SIGALRM handler for all the children it calls the function signalHandler()*/
  struct sigaction handler;
  /* ignore is the handler for the parent process, it ignores SIGALRM*/
  struct sigaction ignore;
  int i;
  pid_t child;
  handler.sa_handler = &signalHandler;
  ignore.sa_handler = SIG_IGN;
  /* puts the number of threads into a global variable, this is used by killThreads() and myWait()*/
  threadNumber = numberOfThreads;
  /*printf("Got to procedure startThreads\n");*/
  for(i=0; i < numberOfThreads; i++) 
  {
    child = fork();
    if (child == 0)
    {
      /* child == 0 when we're actually in the child process */
      /*Gives the child the handler*/
      sigaction(SIGALRM,&handler,NULL);
      threadTask(squaresToCalculate, i);
    }
    /* in the parent still */
    active_processes[i] = child;
  }
  /* Gives the parent the ignore handler*/
  sigaction(SIGALRM,&ignore,NULL);
}

void killThreads()
{
  int i = 0;
  pid_t process;
  /* kill is used to send signals to other processes */
  while (i < threadNumber)
  {
    process = active_processes[i];
    kill( process, SIGALRM );
    i++;
  }
}

void timer(int time)
{
  sleep(time);
  killThreads();
  exit(0);
}

void myWait(int time)
{
  int i = 0;
  int status;
  pid_t child;
  child = fork();
  if (child == 0)
  {
    /* child == 0 when we're actually in the child process */
    timer(time);
  }
  while (i< threadNumber)
  {
    waitpid(active_processes[i], &status, 0);
    /*printf("finished waiting for %i, status = %i\n",active_processes[i],status);*/
    i++;
  }
  if (status == 0)
  {
    kill(child,SIGALRM);
  }
  exit(0);
}

int main(int argc, char* argv[])
{
   return mainThread(argc, argv);
}

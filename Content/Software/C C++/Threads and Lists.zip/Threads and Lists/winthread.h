 #include <windows.h>
 /**
 * This function is run by all the threads created from threadtask().
 * It will try to compute the square of numbers up to the one provided.
 * When it is stopped or finishes it prints out the time since it began and the number of invocations of Square().
 */
DWORD WINAPI threadTask(LPVOID);


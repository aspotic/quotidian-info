/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 1
	Part C
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"





char *printList(LIST* list) {

	int i;
	char *listContent;
	char * tempStore;
	int * item;
	
	if (list == NULL)
		return "gave a null list pointer";
	
	item = ListFirst(list);
	listContent = malloc(500 * sizeof(char));
	tempStore = malloc(50 * sizeof(char));
	
	sprintf(listContent, "[");
	for (i = 0; i < list->size; i++) {
		if (item != NULL) {
			sprintf(tempStore,"%d", *item);
			strcat(listContent, tempStore);
		} else {
			printf("\t\tERROR: Number of items in list does not match list size in printList()\n");
		}
		item = ListNext(list);
		if (item != NULL) {
			sprintf(tempStore," ");
			strcat(listContent, tempStore);
			if (!(item == ListCurr(list)))
				printf("\t\tERROR: ListNext followed by ListCurr results do not match in printList()\n");
		
		}
	}
	sprintf(tempStore,"]");
	strcat(listContent, tempStore);
	free(tempStore);
	
	return listContent;
}





char *printListReverse(LIST* list) {
	int i;
	char *listContent;
	char * tempStore;
	int * item;
	
	if (list == NULL)
		return "gave a null list pointer";
	
	item = ListLast(list);
	listContent = malloc(500 * sizeof(char));
	tempStore = malloc(50 * sizeof(char));
	
	sprintf(listContent, "[");
	
	for (i = 0; i < list->size; i++) {
		if (item != NULL) {
			sprintf(tempStore,"%d", *item);
			strcat(listContent, tempStore);
		} else {
			printf("\t\tERROR: Number of items in list does not match list size in printListReverse()\n");
		}
		item = ListPrev(list);
		if (item != NULL) {
			sprintf(tempStore," ");
			strcat(listContent, tempStore);
			if (!(item == ListCurr(list)))
				printf("\t\tERROR: ListNext followed by ListCurr results do not match in printListReverse()\n");
		
		}
	}
	sprintf(tempStore,"]");
	strcat(listContent, tempStore);
	free(tempStore);
	
	return listContent;
}

int compareInt (void *int1, void *int2) {
	return (*(int *)int1 == *(int *)int2);
}





void freeItem(void *a)
{
  return;
}





/*Test function*/
int main () {
	/*
		create items to add to the lists during testing
	*/
	char * listDataIs;
	
	int item1;
	int item2;
	int item3;
	int item4;
	int item5;
	int item6;
	int item7;
	int store2;
	int badtest;
	
	int *store;
	
	LIST *testList1; 
	LIST *testList2; 
	LIST *testList3; 
	LIST *testList4; 
	LIST *testList5; 
	LIST *testList6; 
	LIST *testList7; 
	LIST *testList8; 
	LIST *testList9; 
	LIST *testList10; 
	LIST *testList11; 
	LIST *testList12;
	LIST *testList13; 

	item1 = 1;
	item2 = 2;
	item3 = 3;
	item4 = 4;
	item5 = 5;
	item6 = 6;
	item7 = 7;
	




	/*
		LstiCreate() Testing Phase 1
	*/
	printf("\nTESTING: ListCreate\n");
	
	/*TEST 1: handles initial data setup and creation of first list*/
	badtest = 0;
	testList1 = ListCreate();
	if (testList1 == NULL) {
		printf("\t\tERROR: testList1 has a null value\n");
		badtest = 1;
	}
	if (testList1->size != 0) {
		printf("\t\tERROR: testList1 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");
		
	/*TEST 2: can still create lists after the number of free lists is incremented by increasing mem size*/
	badtest = 0;
	testList2 = ListCreate();
	if (testList2 == NULL) { 
		printf("\t\tERROR: testList2 has a null value\n");
		badtest = 1;
	}
	if (testList2->size != 0) { 
		printf("\t\tERROR: testList2 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
		
	/*TEST 3: can still create lists after the number of free lists is decremented by using a free list*/
	badtest = 0;
	testList3 = ListCreate();
	if (testList3 == NULL) { 
		printf("\t\tERROR: testList3 has a null value\n");
		badtest = 1;
	}
	if (testList3->size != 0) { 
		printf("\t\tERROR: testList3 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
		
	/*TEST 4: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
		testList4 = ListCreate();
	if (testList4 == NULL) { 
		printf("\t\tERROR: testList4 has a null value\n");
		badtest = 1;
	}
	if (testList4->size != 0) { 
		printf("\t\tERROR: testList4 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");
	
	/*TEST 5: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList5 = ListCreate();
	if (testList5 == NULL) { 
		printf("\t\tERROR: testList5 has a null value\n");
		badtest = 1;
	}
	if (testList5->size != 0) { 
		printf("\t\tERROR: testList5 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 5\n");
		
	/*TEST 6: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList6 = ListCreate();
	if (testList6 == NULL) { 
		printf("\t\tERROR: testList6 has a null value\n");
		badtest = 1;
	}
	if (testList6->size != 0) { 
		printf("\t\tERROR: testList6 does not have size 0\n");	
		badtest = 1;
	}	
	if (badtest == 1)
		printf("\tEnd of Errors for Test 6\n");
		
	/*TEST 7: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList7 = ListCreate();
	if (testList7 == NULL) { 
		printf("\t\tERROR: testList7 has a null value\n");
		badtest = 1;
	}
	if (testList7->size != 0) { 
		printf("\t\tERROR: testList7 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 7\n");
		
	/*TEST 8: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList8 = ListCreate();
	if (testList8 == NULL) { 
		printf("\t\tERROR: testList8 has a null value\n");
		badtest = 1;
	}
	if (testList8->size != 0) { 
		printf("\t\tERROR: testList8 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 8\n");
	
	/*TEST 9: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList9 = ListCreate();
	if (testList9 == NULL) { 
		printf("\t\tERROR: testList9 has a null value\n");
		badtest = 1;
	}
	if (testList9->size != 0) { 
		printf("\t\tERROR: testList9 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 9\n");
		
	/*TEST 10: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList10 = ListCreate();
	if (testList10 == NULL) { 
		printf("\t\tERROR: testList10 has a null value\n");
		badtest = 1;
	}
	if (testList10->size != 0) { 
		printf("\t\tERROR: testList10 does not have size 0\n");	
		badtest = 1;
	}	
	if (badtest == 1)
		printf("\tEnd of Errors for Test 10\n");
		
	/*TEST 11: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList11 = ListCreate();
	if (testList11 == NULL) { 
		printf("\t\tERROR: testList11 has a null value\n");
		badtest = 1;
	}
	if (testList11->size != 0) { 
		printf("\t\tERROR: testList11 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 11\n");
		
	/*TEST 12: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList12 = ListCreate();
	if (testList12 == NULL) { 
		printf("\t\tERROR: testList12 has a null value\n");
		badtest = 1;
	}
	if (testList12->size != 0) { 
		printf("\t\tERROR: testList12 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 12\n");
		
	/*TEST 13: Not explicitly for testing ListCreate(), but for testing other functions*/
	badtest = 0;
	testList13 = ListCreate();
	if (testList13 == NULL) { 
		printf("\t\tERROR: testList13 has a null value\n");
		badtest = 1;
	}
	if (testList12->size != 0) { 
		printf("\t\tERROR: testList13 does not have size 0\n");	
		badtest = 1;
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 13\n");





	/*
		ListInsert() Testing Phase 1
	*/
	printf("\nTESTING: ListInsert\n");
	
	/*TEST 1: handles initial data structure setup and use of first node*/
	badtest = 0;
	if (ListInsert(testList1, (void *)&item1) == -1) {
		printf("\t\tERROR: testList1 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList1)), "[1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList1)), "[1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");

	/*TEST 2: handles adding more than 1 node to a list*/
	badtest = 0;
	if (ListInsert(testList1, (void *)&item2) == -1) {
		printf("\t\tERROR: testList1 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList1)), "[2 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[2 1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList1)), "[1 2]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1 2]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: handles adding a node after the number of available nodes is incremented by mem size increase*/
	badtest = 0;
	if (ListInsert(testList1, (void *)&item3) == -1) {
		printf("\t\tERROR: testList1 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList1)), "[3 2 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[3 2 1]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList1)), "[1 2 3]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1 2 3]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);	
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	
	/*TEST 4: handles adding nodes after the number of available nodes is decremented by using a previous node*/
	badtest = 0;
	if (ListInsert(testList1, (void *)&item4) == -1) {
		printf("\t\tERROR: testList1 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList1)), "[4 3 2 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[4 3 2 1]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList1)), "[1 2 3 4]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1 2 3 4]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");

	/*TEST 5: handles adding an item to more than 1 list*/
	badtest = 0;
	if (ListInsert(testList2, (void *)&item5) == -1) {
		printf("\t\tERROR: testList2 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList2)), "[5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList2)), "[5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 5\n");

	/*TEST 6: handles adding multiple items to multiple lists*/
	badtest = 0;
	if (ListInsert(testList2, (void *)&item6) == -1) {
		printf("\t\tERROR: testList2 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList2)), "[6 5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[6 5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList2)), "[5 6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[5 6]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 6\n");
		
	/*TEST 7: handle inserting an item between two nodes*/
	ListNext(testList2);
	badtest = 0;
	if (ListInsert(testList2, (void *)&item7) == -1) {
		printf("\t\tERROR: testList2 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList2)), "[6 7 5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[6 7 5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList2)), "[5 7 6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList2 contains:%s\n\t\t\tWhen it should contain:[5 7 6]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 7\n");




	/*
		ListAppend() Testing Phase 1
	*/
	printf("\nTESTING: ListAppend\n");
	
	/*TEST 1: add 1 node to a list*/
	badtest = 0;
	if (ListAppend(testList3, (void *)&item1) == -1) {
		printf("\t\tERROR: testList3 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList3)), "[1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList3 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList3)), "[1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList3 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");

	/*TEST 2: handles adding more than 1 node to a list*/
	badtest = 0;
	if (ListAppend(testList3, (void *)&item2) == -1) {
		printf("\t\tERROR: testList3 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList3)), "[1 2]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList3 contains:%s\n\t\t\tWhen it should contain:[1 2]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList3)), "[2 1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList3 contains:%s\n\t\t\tWhen it should contain:[2 1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");

	/*TEST 3: handles adding an item to more than 1 list*/
	badtest = 0;
	if (ListAppend(testList4, (void *)&item5) == -1) {
		printf("\t\tERROR: testList4 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList4)), "[5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList4)), "[5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");

	/*TEST 4: handles adding multiple items to multiple lists*/
	badtest = 0;
	if (ListAppend(testList4, (void *)&item6) == -1) {
		printf("\t\tERROR: testList4 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList4)), "[5 6]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5 6]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList4)), "[6 5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[6 5]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");





	/*
		ListPrepend() Testing Phase 1
	*/
	printf("\nTESTING: ListPrepend\n");
	
	/*TEST 1: add 1 node to a list*/
	badtest = 0;
	if (ListPrepend(testList5, (void *)&item1) == -1) {
		printf("\t\tERROR: testList5 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList5)), "[1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList5 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList5)), "[1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList5 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");

	/*TEST 2: handles adding more than 1 node to a list*/
	badtest = 0;
	if (ListPrepend(testList5, (void *)&item2) == -1) {
		printf("\t\tERROR: testList5 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList5)), "[2 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList5 contains:%s\n\t\t\tWhen it should contain:[2 1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList5)), "[1 2]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList5 contains:%s\n\t\t\tWhen it should contain:[1 2]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");

	/*TEST 3: handles adding an item to more than 1 list*/
	badtest = 0;
	if (ListPrepend(testList6, (void *)&item5) == -1) {
		printf("\t\tERROR: testList6 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList6)), "[5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList6 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList6)), "[5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList6 contains:%s\n\t\t\tWhen it should contain:[5]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");

	/*TEST 4: handles adding multiple items to multiple lists*/
	badtest = 0;
	if (ListPrepend(testList6, (void *)&item6) == -1) {
		printf("\t\tERROR: testList6 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList6)), "[6 5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList6 contains:%s\n\t\t\tWhen it should contain:[6 5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList6)), "[5 6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList6 contains:%s\n\t\t\tWhen it should contain:[5 6]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");





	/*
		ListConcat() Test Phase 1
	*/
	printf("\nTESTING: ListConcat\n");
	 
	/*TEST 1: add empty list to empty list*/
	badtest = 0;
	ListConcat(testList10, testList9);
	if (0 != strcmp((listDataIs = printList(testList10)), "[]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList10 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList10)), "[]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList10 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs); 
		badtest = 1;
	}
	testList9 = NULL;
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");
		
	/*TEST 2: add emty list to non empty list*/
	badtest = 0;
	ListConcat(testList1, testList10);
	if (0 != strcmp((listDataIs = printList(testList1)), "[4 3 2 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[4 3 2 1]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList1)), "[1 2 3 4]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList1 contains:%s\n\t\t\tWhen it should contain:[1 2 3 4]\n", listDataIs); 
		badtest = 1;
	}
	testList10 = NULL;
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
		
	/*TEST 3: add non empty list to empty list*/
	badtest = 0;
	ListConcat(testList11, testList2);
	if (0 != strcmp((listDataIs = printList(testList11)), "[6 7 5]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[6 7 5]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList11)), "[5 7 6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[5 7 6]\n", listDataIs); 
		badtest = 1;
	}
	testList2 = NULL;
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
		
	/*TEST 4: add non empty list to non empty list*/
	badtest = 0;
	ListConcat(testList4, testList3);
	if (0 != strcmp((listDataIs = printList(testList4)), "[5 6 1 2]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5 6 1 2]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList4)), "[2 1 6 5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[2 1 6 5]\n", listDataIs); 
		badtest = 1;
	}
	testList3 = NULL;
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");





	/*
		ListAdd() Testing Phase 1
	*/
	
	printf("\nTESTING: ListAdd\n");
	
	/*TEST 1: handles first node in the list*/
	badtest = 0;
	if (ListAdd(testList7, (void *)&item1) == -1) {
		printf("\t\tERROR: testList7 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList7)), "[1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList7 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList7)), "[1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList7 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 1\n");

	/*TEST 2: handles adding more than 1 node to a list*/
	badtest = 0;
	if (ListAdd(testList7, (void *)&item2) == -1) {
		printf("\t\tERROR: testList7 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList7)), "[1 2]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList7 contains:%s\n\t\t\tWhen it should contain:[1 2]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList7)), "[2 1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList7 contains:%s\n\t\t\tWhen it should contain:[2 1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/* TEST 3: handles adding nodes to multiple lists*/
	badtest = 0;
	if (ListAdd(testList8, (void *)&item3) == -1) {
		printf("\t\tERROR: testList8 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList8)), "[3]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[3]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList8)), "[3]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[3]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	
	/*TEST 4: handles adding multiple nodes to multiple lists*/
	badtest = 0;
	if (ListAdd(testList8, (void *)&item4) == -1) {
		printf("\t\tERROR: testList8 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList8)), "[3 4]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[3 4]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList8)), "[4 3]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[4 3]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");
		
	/*TEST 5: handle adding an item between two nodes*/
	badtest = 0;
	ListPrev(testList8);
	if (ListAdd(testList8, (void *)&item5) == -1) {
		printf("\t\tERROR: testList8 returned error code -1\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList8)), "[3 5 4]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[3 5 4]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList8)), "[4 5 3]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList8 contains:%s\n\t\t\tWhen it should contain:[4 5 3]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 5\n");

	
	
	

	/*
		Test ListSearch
	*/
	printf("\nTESTING: ListSearch\n");
	
	/*Case 1: Item Found*/
	badtest = 0;
	if (&item1 != ListSearch(testList4, compareInt, (void *)&item1)) {
		listDataIs = printList(testList4);
		printf("\t\tERROR: looking for item %d in list %s, but could not find item when it should be there\n", item1, listDataIs);
		free(listDataIs);
		printf("\tEnd of Errors for Test 1\n");
	}
	
	/*Case 2: Item Not Found*/
	badtest = 0;
	if (NULL != ListSearch(testList4, compareInt, (void *)&item7)) {
		listDataIs = printList(testList4);
		printf("\t\tERROR: looking for item %d in list %s, but found item when it shouldnt be there\n", item7, listDataIs);
		free(listDataIs);
		printf("\tEnd of Errors for Test 2\n");
	}
	
	
	
	
	
	/*
		Test ListCount
	*/
	printf("\nTESTING: ListCount\n"); 
	 
	/*Empty List*/
	if ((store2 = ListCount(testList12)) != 0) {
	 	printf("\t\tERROR: was looking for a list size of 0, but the count value was %d\n", store2); 
		printf("\tEnd of Errors for Test 1\n");
	}
		 
	/*Not emty list*/
	if ((store2 = ListCount(testList4)) != 4){
	 	printf("\t\tERROR: was looking for a list size of 4, but the count value was %d\n", store2); 
		printf("\tEnd of Errors for Test 2\n");
	}
	
	 

	
	/*
		Test ListFirst
	*/
	 printf("\nTESTING: ListFirst\n");
	 
	/*TEST 1: can handle emtpy list*/
	badtest = 0;
	if (NULL != ListFirst(testList12)) {
		printf("\t\tERROR: Should not have found a value at the head of the empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
	
	/*TEST 2: can handle moving to the start of the list from a different position*/
	badtest = 0;
	if ((store = ListFirst(testList4)) == NULL) {
		printf("\t\tERROR: ListFirst returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item5 != *store) {
			printf("\t\tERROR: Should Have found the integer '5' at the list head, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: can handle already being at the start of the list*/
	badtest = 0;
	if ((store = ListFirst(testList4)) == NULL) {
		printf("\t\tERROR: ListFirst returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item5 != *store) {
			printf("\t\tERROR: Should Have found the integer '5' at the list head, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	
	
	
	
	
	/*
		Test ListLast
	*/
	printf("\nTESTING: ListLast\n");
	 
	/*TEST 1: can handle emtpy list*/
	badtest = 0;
	if (NULL != ListLast(testList12)) {
		printf("\t\tERROR: Should not have found a value at the tail of the empty list, but did.\n");
		printf("\tEnd of Errors for Test 1\n");
	}
	
	/*TEST 2: can handle moving to the end of the list from a different position*/
	badtest = 0;
	if ((store = ListLast(testList4)) == NULL) {
		printf("\t\tERROR: ListLast returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item2 !=  *store) {
			printf("\t\tERROR: Should Have found the integer '2' at the list tail, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: can handle already being at the end of the list*/
	badtest = 0;
	if ((store = ListLast(testList4)) == NULL) {
		printf("\t\tERROR: ListLast returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item2 !=  *store) {
			printf("\t\tERROR: Should Have found the integer '2' at the list tail, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	
	
	 

	
	/*
		Tests for ListTrim
	*/
	printf("\nTESTING: ListTrim\n");
	
	/*TEST 1: Attempt to trim an empty list*/
	badtest = 0;
	if (NULL != ListTrim(testList13)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
		
	/*TEST 2: Trim a list with multiple items down to no items*/
	badtest = 0;
	if ((store = ListTrim(testList11)) == NULL) {
		printf("\t\tERROR: ListTrim returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item5 !=  *store) {
			printf("\t\tERROR: Should Have removed the integer '5' from the list's tail, but removed %d.\n", *store); 
			badtest = 1;
		}
	}
	if (0 != strcmp((listDataIs = printList(testList11)), "[6 7]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[6 7]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList11)), "[7 6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[7 6]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);	
	if ((store = ListTrim(testList11)) == NULL) {
		printf("\t\tERROR: ListTrim returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item7 !=  *store) {
			printf("\t\tERROR: Should Have removed the integer '5' from the list's tail, but removed %d.\n", *store); 
			badtest = 1;
		}
	}
	if (0 != strcmp((listDataIs = printList(testList11)), "[6]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[6]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList11)), "[6]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[6]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);	
	if ((store = ListTrim(testList11)) == NULL) {
		printf("\t\tERROR: ListTrim returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item6 !=  *store) {
			printf("\t\tERROR: Should Have removed the integer '6' from the list's tail, but removed %d.\n", *store); 
			badtest = 1;
		}
	}
	if (0 != strcmp((listDataIs = printList(testList11)), "[]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs);
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList11)), "[]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: Ensure items may still be added to the list after items have been removed*/
	badtest = 0;
	if (ListPrepend(testList11, (void *)&item1) == -1) {
		printf("\t\tERROR: testList11 returned error code -1 for ListPrepend(testList11)\n"); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList11)), "[1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printListReverse(testList11)), "[1]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList11 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	
	
	
	
	
	/*
		Test ListPrev
	*/
	printf("\nTESTING: ListPrev\n");
	 
	/*TEST 1: can handle an empty list*/
	badtest = 0;
	if (NULL != ListPrev(testList12)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
		
	/*TEST 2: can handle a list with multiple nodes (move from one node to the next)*/
	badtest = 0;
	if ((store = ListPrev(testList4)) == NULL) {
		printf("\t\tERROR: ListPrev returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item1 !=  *store) {
			printf("\t\tERROR: Should Have found the integer '1' at the list tail, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: can handle a list with only 1 item (attempts to move to a nonexistent node)*/
	badtest = 0;
	if (NULL != ListPrev(testList11)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 3\n");
	}
	 

	
	
	/*
		Test ListNext
	*/
	printf("\nTESTING: ListNext\n");
	 
	/*TEST 1: can handle an empty list*/
	badtest = 0;
	if (NULL != ListNext(testList12)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
		
	/*TEST 2: can handle a list with multiple nodes (move from one node to the next)*/
	badtest = 0;
	if ((store = ListNext(testList4)) == NULL) {
		printf("\t\tERROR: ListNext returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item2 !=  *store) {
			printf("\t\tERROR: Should Have found the integer '2' at the list tail, but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	
	/*TEST 3: can handle a list with only 1 item (attempts to move to a nonexistent node)*/
	badtest = 0;
	if (NULL != ListNext(testList11)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 3\n");
	}
	
	
	
	
	/*
		Test ListCurr
	*/
	 printf("\nTESTING: ListCurr\n");
	 
	/*TEST 1: can handle an empty list*/
	badtest = 0;
	if (NULL != ListCurr(testList12)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
		
	/*TEST 2: can handle a non empty list*/
	badtest = 0;
	if ((store = ListCurr(testList4)) == NULL) {
		printf("\t\tERROR: ListCurr returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item2 !=  *store) {
			printf("\t\tERROR: Should Have returned the integer '2', but found %d.\n", *store); 
			badtest = 1;
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");


	

	
	/*
		Tests for ListRemove
	*/
	printf("\nTESTING: ListRemove\n");
	
	/*TEST 1: attempt to remove item from a list with no items*/
	badtest = 0;
	if (NULL != ListRemove(testList12)) {
		printf("\t\tERROR: Should not have found a value in the empty empty list, but did.\n"); 
		printf("\tEnd of Errors for Test 1\n");
	}
	
	/*TEST 2: Remove last item of a multi item list*/
	badtest = 0;
	if ((store = ListRemove(testList4)) == NULL) {
		printf("\t\tERROR: ListRemove returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item2 !=  *store) {
			printf("\t\tERROR: Should removed the integer '2' from the list, but removed %d.\n", *store);
			badtest = 1;
		}
	}
	if (0 != strcmp((listDataIs = printListReverse(testList4)), "[1 6 5]")) {
		printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[1 6 5]\n", listDataIs); 
		badtest = 1;
	}
	if (0 != strcmp((listDataIs = printList(testList4)), "[5 6 1]")) {
		printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5 6 1]\n", listDataIs);
		badtest = 1;
	}
	free(listDataIs);
	if (badtest == 1)
		printf("\tEnd of Errors for Test 2\n");
	 
	/*TEST 3: Remove item that is not at the head or tail of the list*/
	badtest = 0;
	if ((store = ListPrev(testList4)) == NULL) {
		printf("\t\tERROR: ListPrev returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item6 != *store) {
	 		printf("\t\tERROR: Could not run test because ListPrev() returned %d, when it should have returned '6'\n", *store); 
			badtest = 1;
	 	} else {
			if ((store = ListRemove(testList4)) == NULL) {
				printf("\t\tERROR: ListRemove returned NULL.\n"); 
				badtest = 1;
			} else {
				if (item6 != *store) {
					printf("\t\tERROR: Should removed the integer '6' from the list, but removed %d.\n", *store); 
					badtest = 1;
				}
				if (0 != strcmp((listDataIs = printList(testList4)), "[5 1]")) {
					printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[5 1]\n", listDataIs);
					badtest = 1;
				}
				if (0 != strcmp((listDataIs = printListReverse(testList4)), "[1 5]")) {
					printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[1 5]\n", listDataIs); 
					badtest = 1;
				}
				free(listDataIs);
			}
	 	}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 3\n");
	 
	/*TEST 4: Remove first item from a multi item list*/
	badtest = 0;
	if ((store = ListFirst(testList4)) == NULL) {
		printf("\t\tERROR: ListFirst returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item5 != *store) {
	 		printf("\t\tERROR: Could not run test because ListFirst() returned %d, when it should have returned '6'\n", *store); 
			badtest = 1;
		} else {	
			if ((store = ListRemove(testList4)) == NULL) {
				printf("\t\tERROR: ListRemove returned NULL.\n"); 
				badtest = 1;
			} else {
				if (item5 !=  *store) {
					printf("\t\tERROR: Should removed the integer '5' from the list, but removed %d.\n", *store); 
					badtest = 1;
				}
				if (0 != strcmp((listDataIs = printList(testList4)), "[1]")) {
					printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs);
					badtest = 1;
				}
				if (0 != strcmp((listDataIs = printListReverse(testList4)), "[1]")) {
					printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[1]\n", listDataIs); 
					badtest = 1;
				}
				free(listDataIs);
			}
		}
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 4\n");
	
	/*TEST 5: Remove only item from a single item list*/
	badtest = 0;
	if ((store = ListRemove(testList4)) == NULL) {
		printf("\t\tERROR: ListRemove returned NULL.\n"); 
		badtest = 1;
	} else {
		if (item1 !=  *store) {
			printf("\t\tERROR: Should removed the integer '1' from the list, but removed %d.\n", *store); 
			badtest = 1;
		}
		if (0 != strcmp((listDataIs = printList(testList4)), "[]")) {
			printf("\t\tERROR: using printList()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs);
			badtest = 1;
		}
		if (0 != strcmp((listDataIs = printListReverse(testList4)), "[]")) {
			printf("\t\tERROR: using printListReverse()\n\t\t\ttestList4 contains:%s\n\t\t\tWhen it should contain:[]\n", listDataIs); 
			badtest = 1;
		}
		free(listDataIs);
	}
	if (badtest == 1)
		printf("\tEnd of Errors for Test 5\n");

	
	

	
	/*
		Free any still existing lists
	*/
	printf("\nTESTING: ListFree\n");

	/*TEST 1: Remove an empty list*/
	ListFree (testList12, freeItem);
	testList12 = NULL;
	
	/*TEST 2: Remove a non empty list*/
	ListFree (testList1, freeItem);
	testList1 = NULL;
	
	/*TEST 3: Remove a NULL list*/
	ListFree (testList12, freeItem);
	
	/*TEST : Not specifically for testing purposes, rather to make sure no memory leaks occur.*/
	ListFree (testList4, freeItem);
	testList4 = NULL;
	ListFree (testList5, freeItem);
	testList5 = NULL;
	ListFree (testList6, freeItem);
	testList6 = NULL;
	ListFree (testList7, freeItem);
	testList7 = NULL;
	ListFree (testList8, freeItem);
	testList8 = NULL;
	ListFree (testList11, freeItem);
	testList11 = NULL;
	ListFree (testList13, freeItem);
	testList13 = NULL;

	
	
	
	
	return 0;
}

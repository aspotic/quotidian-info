/**
 * Calculates the square of the integer provided in a very slow way.
 * Also increments the integer passed in each time it is called
 */
int Square(int,int*);

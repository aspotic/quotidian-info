#include "implementthread.h"
#include "calculation.h"
#include "winthread.h"
#include <stdio.h>
#include <windows.h>
static int squares;
int keepRunning = 1;

/**
 * Converts the time from GetSystemTime into milliseconds.
 */
int getTime()
{
  int timeInMilliseconds;
  SYSTEMTIME now;
  GetSystemTime(&now);
  timeInMilliseconds = now.wDay * 24 * 60 * 60 * 1000;
  timeInMilliseconds = timeInMilliseconds + (now.wHour * 60 * 60 * 1000);
  timeInMilliseconds = timeInMilliseconds + (now.wMinute * 60 * 1000);
  timeInMilliseconds = timeInMilliseconds + (now.wSecond * 1000);
  timeInMilliseconds = timeInMilliseconds + (now.wMilliseconds);
  return timeInMilliseconds;
}

void startThreads(int numberOfThreads, int squaresToCalculate)
{
  int i = 1;
  squares = squaresToCalculate;
  while ( i <= numberOfThreads )
  {
    CreateThread(NULL,0,threadTask,&squares,0,NULL);
    i++;
  }
}

void killThreads()
{
  keepRunning = 0;
}

DWORD WINAPI threadTask(LPVOID squaresToCalculate)
{
   int executionTime;
   int startTime = getTime();
   int squares = (*(int*)(squaresToCalculate));
   int i = 1;
   int squaresCalled = 0;
   while ( i <= squares && keepRunning == 1)
   {
      Square(i,&squaresCalled);
      i++;
   }
   executionTime = (getTime() - startTime);
   printf("This child ran for %d milliseconds\n", executionTime);
   printf("This child called Square %i times\n", squaresCalled);
  return(0);
}

/**
 * Since sleep is specific to windows.h it is done here.
 */
void myWait(int time)
{
  Sleep(time*1000);
}

int main(int argc, char* argv[])
{
  return mainThread(argc, argv);
}

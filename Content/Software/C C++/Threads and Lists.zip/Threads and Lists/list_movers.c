/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 1
	Part C
*/

#include <stdio.h>
#include "list.h"





/*
ListCount
	Counts the number of items in the list
Preconditions
	list must contain a pointer to a valid list
Postconditions
	The number of list items has been counted
Return
	the number of items in the list
*/
int ListCount(LIST *list) {
	/*check for a nonexistent list*/
	if (list == NULL)
		return -1;
		
        return list->size;
}





/*
ListFirst
	Sets the selected item to be the first item in the list, then return a pointer to the item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the selected item is now the first item
Return
	a pointer to the first item in the list
*/
void *ListFirst(LIST *list) {
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0))
		return NULL;
		
	/*Move to the first item in the list and return it*/
	list->current = list->head;	

        return (void *)list->current->data;
}





/*
ListLast
	Sets the selected item to be the last item in the list, then return a pointer to the item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the selected item is now the last item
Return
	A pointer to the last item in the list
*/
void *ListLast(LIST *list) {
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0))
		return NULL;
		
	/*Move to the last item in the list and return it*/
	list->current = list->tail;	

        return (void *)list->current->data;
}





/*
ListNext
	Selects the next item in the list and returns it
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the following item has been selected
Return
	A pointer to the newly selected item
*/
void *ListNext(LIST *list) {
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0) || (list->current == NULL))
		return NULL;
		
	/*Move to next item in list and return it*/
	if ((NODE*)list->current->next != NULL) {
		list->current = (NODE*)list->current->next;	
		return (void *)list->current->data;
	} else {
		return NULL;
	}
}





/*
ListPrev
	Selects the previous item in the list and returns it
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the previous item has been selected
Return
	A pointer to the newly selected item
*/
void *ListPrev(LIST *list) {
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0) || (list->current == NULL))
		return NULL;
		
	/*Move to previous item in list and return it*/
	if (list->current->prev != NULL) {
		list->current = list->current->prev;	
		return (void *)list->current->data;
	} else {
		return NULL;
	}
}





/*
ListCurr
	returns a pointer to the list's selected item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	-
Return
	A pointer to the selected item
*/
void *ListCurr(LIST *list) {
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0) || (list->current == NULL))
		return NULL;
		
        return (void *)list->current->data;
}





/*
ListSearch
	Searches a list for an item and returns it if found
Preconditions
	list must contain a pointer to a valid list
	comparator must contain the address to a routine that will return a true false
	result from the comparison of two items
	comparisonArg must contain the data being searched for
Postconditions
	The item has been searched for, and if found, has been set to the the current item
Return
	A pointer to the item currently selected in the list
	NULL if comparisonArg item was not found
*/
void *ListSearch(LIST *list, int (*comparator)(void *, void *), void *comparisonArg) {
	/*create variables*/
	NODE *current;
	void *item;
	int i;
	
	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0))
		return NULL;

	current = list->current;	/*store the current node in case a match isn't found*/
	list->current = list->head;	/*move to the top of the list for it to be searched*/
	
	/*find the item in the list*/
	for (i = 0; i < list->size; i++) {
		/*set the current item*/
		item = list->current->data;
	
		/*check if the current item is a match*/
		if (comparator ((void *)item, comparisonArg)) {
			return list->current->data;
		}
		
		/*Move to next item in list and return it*/
		list->current = list->current->next;	
	}

	return NULL;
}

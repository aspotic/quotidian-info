#include "implementthread.h"
#include <stdio.h>
#include <stdlib.h>
int mainThread (int argc, char *argv[]) {
  int numberOfThreads;
  int numberOfSquares;
  int time;

  if (argc != 4) 
  {
     printf("Invalid number of arguments to this program.\n");
     return -1;
  }
  numberOfThreads = atoi(argv[1]);
  numberOfSquares = atoi(argv[2]);
  time = atoi(argv[3]);
  if (numberOfThreads <= 0 || numberOfSquares <= 0 || time <= 0)
  {
    printf("Invalid arguments to this program.\n");
    return -1;
  }
  startThreads(numberOfThreads,numberOfSquares);
  myWait(time);
  killThreads();
  return 0;
}

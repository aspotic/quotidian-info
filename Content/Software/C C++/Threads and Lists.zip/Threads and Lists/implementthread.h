#ifndef __IMPLEMENTTHREAD_H
#define __IMPLEMENTTHREAD_H
/* The max number of threads or processes that this program can have */
#define MAX_THREADS 10000
/**
 * This function takes the number of threads as an integer and creates them.
 * The second integer is for the number of squares for the thread to calculate.
 * The threads are set to run threadtask()
 */
void startThreads(int, int);

/**
 * This function is used to tell all the threads created from startThreads() to stop
 */
void killThreads();

/**
* Function used by the main to wait until the given time has elapsed.
*/
void myWait(int);

/**
 * Main of this program, since ubc threads start at mainp, the implementations are in charge of calling the main.
 */
int mainThread(int, char*[]);

#endif

#include <stdio.h>
#include <standards.h>
#include <os.h>
#include <sys/time.h>
#include "implementthread.h"
#include "calculation.h"
#define STACK_BYTES 2560000

/* an array that contains all the pids of the children threads */
static PID activeThreads[MAX_THREADS];
/* The number of squares that need to be calculated by each thread */
static int numberOfSquares;
/* The number of threads to be created */
static int threadNumber;
/* Arguments to mainThread */
static int pThread_argc;
static char** pThread_argv;
/* The start times and squares calculated by the different threads */
static struct timeval startTimes[MAX_THREADS];
static int squaresCalculated[MAX_THREADS];

void threadTask()
{
   int thisThreadNumber = 0;
   struct timeval endTime;
   long seconds = 0;
   long microSeconds = 0;
   int i = 1;
   /* Gets the index associated with this pid */
   while (activeThreads[thisThreadNumber] != MyPid() && thisThreadNumber < threadNumber)
   {
     thisThreadNumber++;
   }
   squaresCalculated[thisThreadNumber] = 0;
   /* Get the start time */
   gettimeofday(&startTimes[thisThreadNumber],NULL);
   /*printf("Got to procedure threadTask\n");*/
   /* Calculate squares */
   while (i <= numberOfSquares)
   {
    Square(i,&squaresCalculated[thisThreadNumber]);
    i++;
   }
   gettimeofday(&endTime,NULL);
   /* Converts everything to microseconds then gets the difference between the start and end time */
   microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTimes[thisThreadNumber].tv_sec * 1000000) + startTimes[thisThreadNumber].tv_usec);
   /* Gets the whole seconds out of the time difference */
   seconds = microSeconds / 1000000;
   /* Gets the remaining microseconds after the seconds are removed */
   microSeconds = microSeconds % 1000000;
   printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
   printf("This child called Square %i times\n", squaresCalculated[thisThreadNumber]);
   Pexit();
}

void startThreads(int numberOfThreads, int squaresToCalculate)
{
 PID pID;
 int i = 0;
 /*printf("Got to procedure startThreads\n");*/
 numberOfSquares = squaresToCalculate;
 threadNumber = numberOfThreads;
 while (i<numberOfThreads)
 {
   pID = Create(threadTask,STACK_BYTES,"",NULL,NORM,USR);
   if (pID == PNUL)
   {
     printf("Error creating a thread.\n");
   }
   else
   {
     /* Adds the child to the active threads */
     activeThreads[i] = pID;
   }
   i++;
 }
 
}

void myWait(int time)
{
  Sleep(time*10);
}

void killThreads()
{
  int i = 0;
  PID pidToPrint = PNUL;
  long seconds = 0;
  long microSeconds = 0;
  struct timeval endTime;
  /*printf("Got to procedure killThreads\n");*/
  /*printf("threadNumber is %d\n",threadNumber);*/
  while(i<threadNumber)
  {
    if (PExists(activeThreads[i]) == 1)
    {
      pidToPrint = Kill(activeThreads[i]);
      if (pidToPrint != PNUL)
      {
	/*printf("killed before finished\n")*/
	gettimeofday(&endTime,NULL);
	/* Converts everything to microseconds then gets the difference between the start and end time */
	microSeconds = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTimes[i].tv_sec * 1000000) + startTimes[i].tv_usec);
	 /* Gets the whole seconds out of the time difference */
	seconds = microSeconds / 1000000;
	/* Gets the remaining microseconds after the seconds are removed */
	microSeconds = microSeconds % 1000000;
	printf("This child ran for %li seconds and %li microseconds\n", seconds,microSeconds);
	printf("This child called Square %i times\n", squaresCalculated[i]);
      }
    }
    i++;
  }
}

void main_thread()
{
  mainThread(pThread_argc, pThread_argv);
}

int mainp(int argc, char* argv[])
{
  pThread_argc = argc;
  pThread_argv = argv;
  /* Cant call mainThread directly due to limitations on the argument passing */
  Create( main_thread, STACK_BYTES, "", NULL, NORM, USR);
  return 0;
}

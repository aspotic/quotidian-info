/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 2
	Part A
*/

#include "Monitor.h"
PID **entryList;


/******************************************************************/
/*set debug = 0 for standard use, set debug = 1 for debugging mode*/
/******************************************************************/
int debug = 0;
/******************************************************************/


/**
	MonInit
	Description
		Setup Data Structure for the monitor.
	Preconditions
		the monitor has not already been initialized
	Postconditions
		the monitor is initialized
	Return
		-
*/
void MonInit() {
	int i;

	/*debug mode data*/
	if (debug == 1) {
		printf("initialized MonInit\n\n");
		/*create monitor entry debugging list*/
		entryList = malloc(sizeof(PID*));
	}
	/*end debug mode data*/

	/*condition variables should be set to 0*/
	for (i = 0; i < 8; i++) {
		semaphore[i].S = NewSem(0);
		semaphore[i].size = 0;
		semaphore[i].value = 0;
	}

	/*entry semaphore should be set to 1 so they wont wait right off the bat*/
	semaphore[entrySem].S = NewSem(1);
	semaphore[entrySem].size = 0;
	/*urgent sempahore should be set to 0 because when an item uses it, it is supposed to wait */
	semaphore[urgentSem].S = NewSem(0);
	semaphore[urgentSem].size = 0;


	initialized = malloc(1);
}





/**
	MonEnter
	Description
		This function fakes the entry into the monitor object.
		If the monitor is occupied, then the process PID is
		added to a list of waiting processes & suspended
	Preconditions
		process is not in the monitor
	Postconditions
		The process is in the monitor
	Return
		-
*/
void MonEnter() {
	int i;

	if (initialized == NULL) {
		MonInit();
	}

	/*increment the number of items in the main monitor entry queue*/
	semaphore[entrySem].size++;
	/****start of debug list****/
	if (debug == 1) {
		entryList = realloc(entryList, sizeof(PID*)*semaphore[entrySem].size);	/*make room for the new item in the list*/
		entryList[semaphore[entrySem].size-1] = malloc(sizeof(PID));/*allocate space for the new pid*/
		*(entryList[semaphore[entrySem].size-1]) = MyPid();			/*add the new pid to the end of the list*/

		/*print the current set of processes waiting to enter the monitor*/
		printf("monEnter process waiting list\n");
		for (i = 0; i < semaphore[entrySem].size; i++) {
			printf("%d) process %d\n", i, *(entryList[i]));
		}
		printf("\n");
	}
	/****end of debug list****/

	/*puts the current thread into the entry queue*/
	P(semaphore[entrySem].S);
	/* made it off the queue so decrement the number of items in the queue */
	semaphore[entrySem].size--;

	/****start of debug list****/
	if (debug == 1) {
		free(entryList[0]);	/*remove the first item since at this point, the item that just entered the monitor is the first in the list*/
		/*shift all pids*/
		for (i = 0; i < semaphore[entrySem].size; i++) {
			*(entryList[i]) = *(entryList[i+1]);
		}
		entryList = realloc(entryList, sizeof(PID*)*semaphore[entrySem].size);	/*remove the redundant item at the list tail*/
		printf("process %d entered monitor\n", MyPid());
	}
	/****end of debug list****/
}




/**
	MonLeave
	Description
		Last statement executed before return.
		Tells the monitor that the process is out of it, and puts the next
		waiting process into the monitor
	Preconditions
		process is in the monitor
	Postconditions
		Process is out of the monitor, and next waiting process is in the monitor
	Return
		-
	
*/
void MonLeave() {
	/****debug section****/
	if (debug == 1) {
		printf ("process %d leaving monitor\n\n", MyPid());
	}
	/**end debug section**/

	/*Start the next thread in the urgent process queue, if there is one*/
	if (semaphore[urgentSem].size > 0) {
		V(semaphore[urgentSem].S);
		return;
	}
	/* If nothing is on the urgent process queue, then start something on the regular queue */
	else {
		V(semaphore[entrySem].S);
		return;
	}
}





/**
	MonWait
	Description
		This function waits until a certain condition variable is true.
		Passes in the indexes of the condition variables that it is waiting for.
	Preconditions
		process is in the monitor
		an acceptable condition variable is input (integer ids 0 through 7 are acceptable)
	Postconditions
		the process has decremented the condition variable
	Return
		-
*/
int MonWait(int condVar) {
	/* Not valid condition variables */
	if ((condVar > 7) || (condVar < 0))
		return -1;

	/* If this thread is going to be put in the queue then it has to leave the monitor */
	if (semaphore[condVar].size > 0 || semaphore[condVar].value < 1) {
		semaphore[condVar].size++;
		/****debug section****/
		if (debug == 1) {
			printf ("process %d must wait\n", MyPid());
		}
		/**end debug section**/

		/*temporarily leave the monitor until the proper conditions are met*/
		MonLeave();

		/*reenter the monitor on the urgent queue (wait until the signaling process has left)*/
		/*proper conditions were met, so update the appropriate condition variable*/
		semaphore[condVar].value--;
		P(semaphore[condVar].S);
		semaphore[condVar].size--;

		/****debug section****/
		if (debug == 1) {
			printf ("process %d going to urgent queue\n", MyPid());
		}
		/**end debug section**/

		/*wait for the signaling process to leave the monitor before entering*/
		semaphore[urgentSem].size++;
		P(semaphore[urgentSem].S);
		semaphore[urgentSem].size--;

		/****debug section****/
		if (debug == 1) {
			printf ("process %d entering monitor from urgent queue\n", MyPid());
		}
		/**end debug section**/


	}
	/* Should not be blocked however it maintains the size of the queue just in case. */
	else {
		semaphore[condVar].size++;
		semaphore[condVar].value--;
		P(semaphore[condVar].S);
		semaphore[condVar].size--;
	}
	return 0;
}





/**
MonNotify
Description
	Tells the monitor that the condition variable is true.
	Waiting process resumes when the notifying process leaves the monitor
Preconditions
		process is in the monitor
		an acceptable condition variable is input (integer ids 0 through 7 are acceptable)
	Postconditions
		this process woke up the next process waiting on the condition variable (if one exists) &
		incremented the condition variable
	Return
		-
*/
int MonNotify(int condVar) {
	/* Not valid condition variables */
	if ((condVar > 7) || (condVar < 0))
		return -1;
	
	/* increment the condition variables semaphore and continue on. */
	V(semaphore[condVar].S);
	semaphore[condVar].value++;

	return 0;
}

/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 2
	Part A
*/

#include "Monitor.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define STACK_BYTES 265000
#define RUN_TIME 150	/*the length of time that this program will run for*/


typedef enum{chop1 = 0, chop2 = 1, chop3 = 2, chop4 = 3, chop5 = 4} chopsticks;


PID philosopher[5];
PID threadTimer;
PID waiter;


/**
	ThreadTimer
	Description
		kills the program after a set ammount of time
	Preconditions
		-
	Postconditions
		the program has ended
	Return
		-
*/
void ThreadTimer() {
	int i;
	/*start the countdown*/
	Sleep(RUN_TIME);
	
	/*countdown done, so kill the waiter thread if it hasn't ended already*/
	if (PExists(waiter)) {
		Kill(waiter);
	}
	
	/*kill all the philosopher threads*/
	for (i = 0; i < 5; i++) {
		if (PExists(philosopher[i])) {
			Kill(philosopher[i]);
		}
	}

	Pexit();
}



/**
	Waiter
	Description
		brings all the chopsticks to the table
	Preconditions
		-
	Postconditions
		chopsticks are on the table and ready to be used
	Return
		-
*/
void Waiter() {
	/*make sure no philosophers are touching the table when the waiter places all the chopsticks*/
	MonEnter();

	/* place the chopsticks*/
	MonNotify(chop1);
	MonNotify(chop2);
	MonNotify(chop3);
	MonNotify(chop4);
	MonNotify(chop5);

	/*leave the table so that a philosopher may pick up some chopsticks*/
	MonLeave();
}



/**
	think
	Description
		The philosopher is currently thinking & not eating
	Preconditions
		-
	Postconditions
		the philosopher wants to be done thinking
	Return
		-
*/
void think() {
	/*think for a random amount of time*/
	Sleep(rand() % 4);

}



/**
	wantsToEat
	Description
		the philosopher would like to stop thinking and begin to eat, 
		but will continue to think until chopsticks become available
	Preconditions
		the philosopher is thinking
		left is the chopstick on his left that he wants to pick up
		right is the chopstick on his right that he wants to pick up
	Postconditions
		the philosopher is eating using chopsticks left and right
	Return
		-
*/
void wantsToEat(chopsticks left, chopsticks right) {
	/*think until eating is possible*/
	MonEnter();
	if (right == 0) {
		MonWait(right);
		MonWait(left);
	} else {
		MonWait(left);
		MonWait(right);
	}
	printf("Philosopher %d takes chopsticks %d and %d\n",right,left,right);
	/*the philosopher has gotten his chopsticks, so he leaves 
		and allows another philosopher to check for chopsticks*/
	MonLeave();
	/*philosopher is now eating*/
}



/**
	eat
	Description
		the philosopher eats for a random ammount of time, then stops to begin thinking
	Preconditions
		the philosopher has gotten his chopsticks
	Postconditions
		the philosopher is now thinking
	Return
		-
*/
void eat(chopsticks left, chopsticks right) {
	/*eat for a random amount of time*/
	Sleep(rand() % 4);

	/*put down chopsticks because done eating*/
	MonEnter();
	MonNotify(left);
	MonNotify(right);
	printf("Philosopher %d finished eating\n",right);
	MonLeave();
	/*philosopher is now thinking*/
}



/**
	Philosopher
	Description
		this is the philosopher who checks for utensils, eats, and thinks
	Preconditions
		right is the name of the philosopher
	Postconditions
		-
	Return
		-
*/
void Philosopher (void * right) {
	chopsticks chopstickL;
	chopsticks chopstickR;

	/*select the philosophers right chopstick*/
	chopstickR = *(chopsticks *)right;

	/*select the philosophers left chopstick*/
	if (chopstickR == 0)
		chopstickL = chop5;
	else
		chopstickL = *(chopsticks *)right - 1;

	/*think, then eat, then think, ... until killed*/
	while (1) {
		think();
		wantsToEat(chopstickL, chopstickR);
		eat(chopstickL, chopstickR);
	}
}



/**
	mainp
	Description
		starts all the thread needed to make the philosopher problem run
	Preconditions
		-
	Postconditions
		philosopher problem has begun
	Return
		0 for success, 1 for failure
*/
int mainp() {
	/*declare variables*/
	chopsticks *stick1;
	chopsticks *stick2;
	chopsticks *stick3;
	chopsticks *stick4;
	chopsticks *stick5;

	/*initialize variables*/
	stick1 = malloc(sizeof(chopsticks));
	stick2 = malloc(sizeof(chopsticks));
	stick3 = malloc(sizeof(chopsticks));
	stick4 = malloc(sizeof(chopsticks));
	stick5 = malloc(sizeof(chopsticks));

	*stick1 = chop1;
	*stick2 = chop2;
	*stick3 = chop3;
	*stick4 = chop4;
	*stick5 = chop5;

	/*get the random number generator going*/
	srand((unsigned int) time(0));

	/*bring the chopsticks to the table*/
	waiter = Create(Waiter,STACK_BYTES,"",NULL,NORM,USR);

	/*start the philosopher threads*/
	philosopher[chop1] = Create(Philosopher,STACK_BYTES,"",stick1,NORM,USR);
	philosopher[chop2] = Create(Philosopher,STACK_BYTES,"",stick2,NORM,USR);
	philosopher[chop3] = Create(Philosopher,STACK_BYTES,"",stick3,NORM,USR);
	philosopher[chop4] = Create(Philosopher,STACK_BYTES,"",stick4,NORM,USR);
	philosopher[chop5] = Create(Philosopher,STACK_BYTES,"",stick5,NORM,USR);

	/*get the kill timer going*/
	threadTimer = Create(ThreadTimer,STACK_BYTES,"",NULL,NORM,USR);

  return 0;
}


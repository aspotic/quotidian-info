/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 1
	Part C
*/

#ifndef list_h
#define list_h

/*Set the minimum list of lists & list of nodes sizes*/
#define MIN_NODES 2;
#define MIN_LISTS 1;

/*Create the node structure*/
typedef struct NODE {
	struct NODE *prev;
	struct NODE *next;
	void *data;
} NODE;

/*Create the list structure*/
typedef struct {	
	int size;
	NODE *head;
	NODE *tail;
	NODE *current;
} LIST;

/*Create the node storage structure*/
typedef struct {	
	int size;
	int numFree;
	NODE **nodeList;
} NODESTORE;
NODESTORE * nodeStore;

/*Create the list storage structure*/
typedef struct {	
	int size;
	int numFree;
	LIST **listList;
} LISTSTORE;
LISTSTORE * listStore;




/*
ListCreate
	Creates a new list
Preconditions
	-
Postconditions
	A new list has been created, and a painter to it
Return
	A pointer to the new list
*/
LIST *ListCreate();


/*
ListAdd
	Adds an item directly below the list's selected item then selects the new item
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	the item has been added below the list's selected item and the new item has been selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListAdd(LIST *list, void *item);


/*
ListInsert
	Adds an item directly above the list's selected item then selects the new item
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	the item has been added above the list's selected item and the new item has been selected	
Return
	0 : successful operation
	-1 : operation failed
*/
int ListInsert(LIST *list, void *item);


/*
ListAppend
	Adds a new item to the end of the list, then selects it
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	The new item has been added to the end of the list and selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListAppend(LIST *list, void *item);


/*
ListPrepend
	Adds a new item to the start of the list, then selects it
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	The new item has been added to the start of the list and selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListPrepend(LIST *list, void *item);


/*
ListConcat
	Adds the data from list 2 to list 1, then destroys list 2
Preconditions
	list1 must contain a pointer to a valid list
	list2 must contain a pointer to a second vaid list
Postconditions
	data from list 2 is now in list 1, and list 2 is gone
Return
	-
*/
void ListConcat(LIST *list1, LIST *list2);


/*
ListCount
	Counts the number of items in the list
Preconditions
	list must contain a pointer to a valid list
Postconditions
	The number of list items has been counted
Return
	the number of items in the list
*/
int ListCount(LIST *list);


/*
ListFirst
	Sets the selected item to be the first item in the list, then return a pointer to the item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the selected item is now the first item
Return
	a pointer to the first item in the list
*/
void *ListFirst(LIST *list);


/*
ListLast
	Sets the selected item to be the last item in the list, then return a pointer to the item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the selected item is now the last item
Return
	A pointer to the last item in the list
*/
void *ListLast(LIST *list);


/*
ListNext
	Selects the next item in the list and returns it
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the following item has been selected
Return
	A pointer to the newly selected item
*/
void *ListNext(LIST *list);


/*
ListPrev
	Selects the previous item in the list and returns it
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the previous item has been selected
Return
	A pointer to the newly selected item
*/
void *ListPrev(LIST *list);


/*
ListCurr
	returns a pointer to the list's selected item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	-
Return
	A pointer to the selected item
*/
void *ListCurr(LIST *list);


/*
ListSearch
	Searches a list for an item and returns it if found
Preconditions
	list must contain a pointer to a valid list
	comparator must contain the address to a routine that will return a true false
	result from the comparison of two items
	comparisonArg must contain the data being searched for
Postconditions
	The item has been searched for, and if found, has been set to the the current item
Return
	A pointer to the item currently selected in the list
	NULL if comparisonArg item was not found
*/
void *ListSearch(LIST *list, int (*comparator)(void *, void *), void *comparisonArg);


/*
ListRemove
	Removes the selected item from the list and selects the next item in the list
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the item is no longer in the list
Return
	The removed item
*/
void *ListRemove (LIST *list);


/*
ListFree
	
Preconditions
	list must contain a pointer to a valid list
	itemFree must contain a pointer to a routine that will free an item
Postconditions
	The list is removed
Return
	-
*/
void ListFree(LIST *list, void (*itemFree)(void *));


/*
ListTrim
	Removes the last item in the list and returns it, then sets the new selected item to be the new last item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the last item in the list has been removed
Return
	a pointer to the removed item
*/
void *ListTrim(LIST *list);


/*
checkNodeMemory
	Checks if there is enough memory available for a new node, and if there isn't, then it makes room
Preconditions
	-
Postconditions
	a free node is found, and memory may have been increased
Return
	a pointer to the free node
	NULL if an error occurs
*/
NODE* checkNodeMemory ();
LIST* checkListMemory ();
void removeNodes(NODE* removedNode);
void removeLists(LIST* removedList);

#endif

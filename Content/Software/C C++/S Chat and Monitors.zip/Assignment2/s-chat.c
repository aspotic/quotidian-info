/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 2
	Part B
*/

#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "list.h"
#include "rtthreads.h"
#include "RttCommon.h"
#include "RttThreadId.h"

#define STACK_SIZE 256000000
#define MAX_MESSAGE_LENGTH 255

/******************************************************************/
/*set debug = 0 for standard use, set debug = 1 for debugging mode*/
/******************************************************************/
int debug = 0;
/******************************************************************/

RttThreadId *server;
RttThreadId *keyboard;
RttThreadId *transmit;
RttThreadId *terminal;
RttThreadId *receive;

int socketOut;
struct sockaddr_in remoteAddr;

int socketIn;
struct sockaddr_in localAddr;
socklen_t socklen;


typedef enum {false = 0, true = 1} boolean;





/**
isBigEndian
	Description
		Checks endianness by checking the bytes of an integer.
	Preconditions
		-
	Postconditions
		-
	Return
		true if using big endian, false if not using big endian
 */
boolean isBigEndian() {
	/*create variables*/
	int i;
	char *checkBytes;
	
	
	/*initialize variables*/
	i = 1;
	checkBytes = (char *) &i;
	
	
	/* If the first byte contains the 1 then it must be little endian */
	if (checkBytes[0] == 1) {
		if (debug == 1) {
			printf("isBigEndian() found Little endian\n");
		}
		return false;
		
	} else {
		if (debug == 1) {
			printf("isBigEndian() found big endian\n");
		}
		return true;
	}
}







/**
keyboardThread
	Description
		takes input fromt the keyboard, then sends it to the server thread,
		also ends the program if the end program combo is entered on a line alone
	Preconditions
		-
	Postconditions
		-
	Return
		RTTTHREAD
 */
RTTTHREAD keyboardThread() {
	/*create variables*/
	unsigned int msgFrmServLen;
	unsigned int msgToServLen;
	
	const char *endMethod;
	char *msgToServ;
	char *msgFrmServ;
	
	boolean end;
	
	int i;
	
	
	/*initialize variables*/
	msgFrmServLen = MAX_MESSAGE_LENGTH;
	msgFrmServ = malloc(sizeof(char) * (msgFrmServLen + 1));
	
	msgToServLen = MAX_MESSAGE_LENGTH;
	msgToServ = malloc(sizeof(char) * (msgToServLen + 1));
	
	endMethod = "\\q\n";	/*the set of characters that must appear as a line to end the program*/
	end = false;
	i = 0;


	/*set file stdin non blocking*/
	fcntl(0,O_NONBLOCK);
	
	
	/*show the user that the program has started*/
	printf("s-chat\n");


	/*the main loop where keyboard input is taken, and sent to the server*/
	while (end == false) {
		/*clear the buffer*/
		memset(msgToServ,'\0', msgToServLen);
		
		/*get the line from the user*/
		read(0, msgToServ, msgToServLen);

		/*if the line is equal to the quit sequence of characters, then end the program*/
		if (strcmp(msgToServ, endMethod) == 0) {
			printf("quiting s-chat\n");
			end = true;

		/*not ending the program, so get the characters ready to send*/
		} else if (msgToServ[0] != '\0') {
			if (debug == 1) {
				printf("Keyboard sending message: %s to server\n",msgToServ);
			}
			/*notify the server that keyboard data is available*/
			RttSend((*server), msgToServ, msgToServLen, msgFrmServ, &msgFrmServLen);
			
			if (debug == 1) {
				printf("Keyboard recieved reply from server: %s\n",msgFrmServ);
			}
			/*resend the message if the server didn't get it, but don't allow an infinite loop to occure*/
			i = 0;
			while(strcmp("server: received keyboard input", msgFrmServ) != 0 && i < 3) {
				RttSend((*server), msgToServ, msgToServLen, msgFrmServ, &msgFrmServLen); i++;
			}
		}
		
		/*sleep so that another thread may begin*/
		RttUSleep(10);
	}
	
	
	/*set stdin to blocking again*/
	fcntl(0,0);

	if (debug == 1) {
		printf("Keyboard is killing other threads\n");
	}
	/*kill all other threads*/
	RttKill(*server);
	RttKill(*transmit);
	RttKill(*receive);
	RttKill(*terminal);

	if (debug == 1) {
		printf("Keyboard is freeing thread id's\n");
	}
	/*free the malloced thread ids*/
	free(server);
	free(transmit);
	free(receive);
	free(terminal);
	free(keyboard);


	if (debug == 1) {
		printf("Keyboard is exiting\n");
	}
	/*end this thread*/
	RttExit();
} 







/**
transmitThread
	Description
		gets a message from the server, then sends it accross the network
	Preconditions
		-
	Postconditions
		-
	Return
		RTTTHREAD 
 */
RTTTHREAD transmitThread() {
	/*decalre variables*/
	unsigned int msgFrmServLen;
	unsigned int msgToServLen;
	
	size_t remoteAddrLen;
	
	char *msgFrmServ;
	char *msgToServ;


	/*initialize variables*/
	msgFrmServLen = MAX_MESSAGE_LENGTH;
	msgFrmServ = malloc(sizeof(char) * (msgFrmServLen + 1));
	
	msgToServLen = 27;
	msgToServ = malloc(sizeof(char) * (msgToServLen + 1));
	msgToServ = "transmit: waiting for data";	/*update the serverMessageLen if the size of this changes*/

	
	/*find the remote address info*/
	remoteAddrLen = (size_t) sizeof(remoteAddr);

	/*main loop where the thread sends the server's data over the network*/
	while (1) {
		if (debug == 1) {
			printf("Transmit is sending a message to the server: %s\n",msgToServ);
		}
		/*notify the server that the thread is ready to transmit data*/
		RttSend((*server), msgToServ, msgToServLen, msgFrmServ, &msgFrmServLen);
		
		if (debug == 1) {
			printf("Transmit recieved a reply message from the server: %s\n",msgFrmServ);
		}

		if (debug == 1) {
			printf("Sending reply using outgoing socket\n");
		}
		/*server wants data sent, so send it*/
		sendto(socketOut, msgFrmServ, msgFrmServLen, 0, (struct sockaddr *) &remoteAddr, remoteAddrLen);

		/*reset the server message*/
		msgFrmServLen = 0;
		
		/*sleep so that another thread may begin*/
		RttUSleep(10);
	}
}







/**
terminalThread
	Description
		gets a message from the server thread, then prints it to the terminal screen
	Preconditions
		-
	Postconditions
		-
	Return
		RTTTHREAD
 */
RTTTHREAD terminalThread() {
	/*declare variables*/
	unsigned int msgFrmServLen;
	unsigned int msgToServLen;
	
	char *msgFrmServ;
	char *msgToServ;


	/*initialize variables*/
	msgToServLen = 27;	
	msgToServ = malloc(sizeof(char) * (msgToServLen + 1));
	msgToServ = "terminal: waiting for data";	/*make sure to update msgToServLen if the length of this string changes*/
	
	msgFrmServLen = MAX_MESSAGE_LENGTH;
	msgFrmServ = malloc(sizeof(char) * (msgFrmServLen + 1));


	/*main loop that checks the server for data, then 
		outputs the next available message to the screen*/
	while(1) {
		if (debug == 1) {
			printf("Terminal is sending a message to server: %s\n",msgToServ);
		}
		/*notify the server that the thread is ready to receive data*/
		RttSend((*server), msgToServ, msgToServLen, msgFrmServ, &msgFrmServLen);
		
		if (debug == 1) {
			printf("Terminal recieved a reply message from the server: %s\n",msgFrmServ);
		}
		/*print the received data to the screen*/
		printf("\n>%s", msgFrmServ);
		
		/*sleep so that another thread can start*/
		RttUSleep(10);
	}
}







/**
receiveThread
	Description
		checks for data from the remote computer, and then sends what it got to the server
	Preconditions
		-
	Postconditions
		-
	Return
		RTTTHREAD
 */
RTTTHREAD receiveThread() {
	/*declare variables*/
	unsigned int msgFrmServLen;
	unsigned int msgToServLen;
	
	char *msgFrmServ;
	char *msgToServ;


	/*initialize variables*/	
	msgFrmServLen = MAX_MESSAGE_LENGTH;
	msgFrmServ = malloc(sizeof(char) * (msgFrmServLen + 1));

	msgToServLen = MAX_MESSAGE_LENGTH;
	msgToServ = malloc(sizeof(char) * (msgToServLen + 1));


	/*main loop where the thread checks for data grams, and informs the server what was received*/
	while (1) {
		/*clear out any old data*/
		msgFrmServLen = MAX_MESSAGE_LENGTH;
		msgToServLen = MAX_MESSAGE_LENGTH;
		
		memset(msgFrmServ, '\0', msgFrmServLen);
		memset(msgToServ, '\0', msgToServLen);

		if (debug == 1) {
			printf("Recieve is waiting for a message from the incoming socket\n");
		}
		/*check for a datagram from the remote computer*/
		while (msgToServ[0] == '\0') {
			recvfrom(socketIn, msgToServ, msgToServLen, 0, (struct sockaddr *) &localAddr, &socklen);
			RttUSleep(10);
		}
		
		if (debug == 1) {
			printf("Recieve got a message from the incoming socket: %s\n",msgToServ);
		}
		
		if (debug == 1) {
			printf("Recieve is sending the message: %s to the server\n",msgToServ);
		}
		/*notify the server what was found*/
		RttSend((*server), msgToServ, msgToServLen, msgFrmServ, &msgFrmServLen);

		/*pause the thread so that another may go*/
		RttUSleep(10);
	}
}







/**
serverThread
	Description
		controls all the thread for the chat program. Makes sure each thread runs when it should, and has what it needs to run
	Preconditions
		-
	Postconditions
		-
	Return
		RTTTHREAD
 */
RTTTHREAD serverThread() {
	/*declare variables*/
	int terminalIsWaiting;
	int transmitIsWaiting;
	
	unsigned int msgFrmServLen;
	unsigned int msgToServLen;
	
	LIST *displayStrings;
	LIST *outputStrings;

	char *msgFrmServ;
	char *msgToServ;
	char *data;
	
	RttThreadId *from;

	
	/*initialize variables*/
	terminalIsWaiting = false;
	transmitIsWaiting = false;
	
	outputStrings = ListCreate();
	displayStrings = ListCreate();

	msgFrmServLen = MAX_MESSAGE_LENGTH;
	msgFrmServ = malloc(sizeof(char) * (msgFrmServLen + 1));

	msgToServLen = MAX_MESSAGE_LENGTH;
	msgToServ = malloc(sizeof(char) * (msgToServLen + 1));

	from = malloc(sizeof(RttThreadId));


	/*main loop where the server controls each thread*/
	while(1) {
		/*reset incoming data variable*/
		memset(msgToServ,'\0', msgToServLen);
		msgToServLen = MAX_MESSAGE_LENGTH;

		if (debug == 1) {
			printf("Server is waiting for a message from a thread\n");
		}
		/*get the message from the thread*/
		RttReceive(from, msgToServ, &msgToServLen);


		/*KEYBOARD: if the keyboard thread is calling, then take the data, and send it to transmitThread*/
		if ((*from).hid == (*keyboard).hid && (*from).lid == (*keyboard).lid) {
			if (debug == 1) {
				printf("Server got a message from the keyboard: %s\n",msgToServ);
			}
			/*send a reply to the calling thread*/
			msgFrmServ = "server: received keyboard input";	/*set the message to send back to the thread*/
			if (debug == 1) {
				printf("Server is sending a reply to the keyboard: %s\n",msgFrmServ);
			}
			RttReply((*keyboard), msgFrmServ, msgFrmServLen);	/*send the message to the thread*/

			/*copy the data so it can be stored in the list*/
			data = malloc(sizeof(char) * (msgToServLen + 1));
			strcpy(data, msgToServ);
			
			if (debug == 1) {
				printf("Server adding:%s to outputStrings list\n",data);
			}
			/*store the data in the list of items to send to transmitThread*/
			ListAppend(outputStrings, data);
		}
		
		/*RECEIVE: if the receive thread is calling, then take its data, and send it to terminalThread*/
		if (((*from).hid == (*receive).hid && (*from).lid == (*receive).lid)) {
			if (debug == 1) {
				printf("Server got a message from receive: %s\n",msgToServ);
			}
			
			
			/*send a reply to the calling thread*/
			msgFrmServ = "receive: received network data";	/*set the message to send back to the thread*/
			if (debug == 1) {
				printf("Server sending a reply to receive: %s\n",msgFrmServ);
			}
			RttReply((*receive), msgFrmServ, msgFrmServLen);	/*send the message to the thread*/

			/*display the message only if there is one*/
			if (msgToServ[0] != '\0') {
				/*copy the data so that it can be stored in the list*/
				data = malloc(sizeof(char) * (msgToServLen + 1));
				strcpy(data, msgToServ);
					
				if (debug == 1) {
					printf("Server appending: %s to displayStrings\n",data);
				}
				/*put the message in the list of messages that have yet to be displayed*/
				ListAppend(displayStrings, data);	
			}
		}
		
		
		/*TEMINAL: if the terminal thread is calling, then give it something to output when something becomes available to output*/
		if (((*from).hid == (*terminal).hid && (*from).lid == (*terminal).lid) || terminalIsWaiting == true) {
			if (debug == 1 && terminalIsWaiting == false) {
				printf("Server got a message from terminal: %s\n",msgToServ);
			}
			/*send an item to terminal if one is available, and note that the terminal is busy*/
			if (ListCount(displayStrings) > 0) {
				
				if (debug == 1) {
					printf("Server sending reply to terminal: %s\n",(char*)ListFirst(displayStrings));
				}
				/*send the data to terminalThread*/
				RttReply((*terminal), ListFirst(displayStrings), 256);	
				
				if (debug == 1) {
					printf("Server trimming the displayStrings list\n");
				}
				/*remove the item so it is not sent again*/
				ListTrim(displayStrings);	
				
				if (debug == 1) {
					printf("Server sets the terminal status to not waiting\n");
				}
				/*make sure terminalThread doesn't receive something else before its ready*/
				terminalIsWaiting = false;	
			
			/*note that terminal should receive an item as soon as one is available to send*/
			} else {
				if (debug == 1 && terminalIsWaiting == false) {
					printf("Server setting the terminal status to waiting\n");
				}
				terminalIsWaiting = true;
			}
		}
		
		
		/*TRANSMIT: if the transmit thread is calling, then give it a message to send when one becomes available*/
		if (((*from).hid == (*transmit).hid && (*from).lid == (*transmit).lid) || transmitIsWaiting == true) {
			if (debug == 1 && transmitIsWaiting == false) {
				printf("Server got a message from transmit: %s\n",msgToServ);
			}
			/*if data is available to transmit, then send it to transmitThread*/
			if (ListCount(outputStrings) > 0) {
				if (debug == 1) {
					printf("Server sending reply to transmit: %s\n",(char*)ListFirst(outputStrings));
				}
				/*send the data to transmitThread*/
				RttReply((*transmit), ListFirst(outputStrings), 256);
				
				if (debug == 1) {
					printf("Server trimming the outputStrings list\n");
				}
				/*make sure transmitThread doesn't receive something else before its ready*/
				ListTrim(outputStrings);
				
				if (debug == 1) {
					printf("Server sets the transmit status to not waiting\n");
				}
				/*remove the item so it is not sent again*/
				transmitIsWaiting = false;
				
			/*note that transmit should receive an item as soon as one is available to send*/
			} else {
				if (debug == 1 && transmitIsWaiting == false) {
					printf("Server sets the transmit status to waiting\n");
				}
				transmitIsWaiting = true;
			}
		}
	}
}







/**
setupConnection
	Description
		create the connection between the computers over the network
	Preconditions
		localport is an available port on the local machine
		remoteport is the port the remote computer is using to send data
		remoteName is the computer name of the remote computer
	Postconditions
		a connection between the two computers has been established
	Return
		0/false if the connection failed
		1/success if the connection was made
 */
boolean setupConnection(int localport, int remoteport, char *remoteName) {
	struct hostent *remoteHost;
	struct hostent *localHost;
	char *localName;
	int localNameLen;

	localNameLen = 50;
	localName = malloc(sizeof(char) * (localNameLen + 1));
	
	/*get the remote computer data*/
	if (debug == 1) {
		printf("Getting the remote host %s by name.\n",remoteName);
	}
	remoteHost = gethostbyname(remoteName);
	if (remoteHost == 0) {
		perror("");
		printf("error finding remote computer with name '%s'\n", remoteName);
		return false;
	}

	if (debug == 1) {
		printf("Setting remote port to %i\n",remoteport);
		printf("Setting the local port to %i\n",localport);
	}
	/*set the proper endian*/
	if (isBigEndian() == false) {
		remoteAddr.sin_port = htons(remoteport);
		localAddr.sin_port = htons(localport);
		
	} else {
		remoteAddr.sin_port = htonl(remoteport);
		localAddr.sin_port = htonl(localport);
	}
	

	/*setup send data functionality*/
	/*get the name of this computer*/
	if (gethostname(localName, localNameLen) == -1) {
		perror("");
		printf("error finding localhost info\n");
		return false;
	}

	if (debug == 1) {
		printf("Finding local host ip address using local host name: %s\n",localName);
	}
	/*get the local computer data*/
	localHost = gethostbyname(localName);
	if (localHost == 0) {
		perror("");
		printf("error finding local computer with name '%s'\n", localName);
		return false;
	}

	if (debug == 1) {
		printf("Creating outgoing socket\n");
	}
	socketOut = socket(AF_INET,SOCK_DGRAM,0);
	if (socketOut == -1) {
		perror("error creating outgoing socket");
		return false;
	}

	remoteAddr.sin_family = AF_INET;
 	remoteAddr.sin_addr.s_addr = *(long *)(remoteHost->h_addr);
	
	
	if (debug == 1) {
		printf("Creating incoming socket\n");
	}
	/*setup receive data functionality*/
	socketIn = socket (AF_INET,SOCK_DGRAM,0);
	if (socketIn == -1) {
		perror("error creating incoming socket");
		return false;
	}
	
	localAddr.sin_family = AF_INET;
 	localAddr.sin_addr.s_addr = *(long *)(localHost->h_addr);

	if (debug == 1) {
		printf("Binding the incoming data socket to the local address.\n");
	}
 	/*bind the incoming data socket*/
	if (bind( socketIn, (struct sockaddr *) &localAddr, sizeof(localAddr)) == -1) {
		perror("error binding the incoming data socket to");
		printf("%li\n", (long) remoteAddr.sin_addr.s_addr);
		return false;
	}
	
	socklen = (socklen_t) sizeof(localAddr);
	
	
	return true;
}







/**
mainp
	Description
		connects the computers over the network, and starts up all the chat threads
	Preconditions
		needs 3 command line parameters: <receiving port> <name of remote computer> <sending port>
	Postconditions
		program is done
	Return
		0 for success, 1 for failure
 */
int mainp (int argc, char* argv[]) {
	/*define variables*/
	RttSchAttr serverSch;
	RttSchAttr keyboardSch;
	RttSchAttr transmitSch;
	RttSchAttr terminalSch;
	RttSchAttr receiveSch;

	char *serverName;
	char *keyboardName;
	char *transmitName;
	char *terminalName;
	char *receiveName;
	
	
	/*make sure the command line parameters were entered*/
	if (argc != 4) {
		printf("you did not enter any command line params; please enter\n ./s-chat <receiving port> <name of remote computer> <sending port>\n");
		return 1;
	}
	
	
	/*create a connection to the other computer*/
	if (!(setupConnection(atoi(argv[1]), atoi(argv[3]), argv[2]))) {
		return 0;
	}
	
	/*initialize variables needed to start up each thread*/
	serverName = "Server";
	server = malloc(sizeof(RttThreadId));
	serverSch.startingtime = RTTZEROTIME;
	serverSch.priority = RTTNORM;
	serverSch.deadline = RTTNODEADLINE;

	keyboardName = "keyboard";
	keyboard = malloc(sizeof(RttThreadId));
	keyboardSch.startingtime = RTTZEROTIME;
	keyboardSch.priority = RTTNORM;
	keyboardSch.deadline = RTTNODEADLINE;

	transmitName = "transmit";
	transmit = malloc(sizeof(RttThreadId));
	transmitSch.startingtime = RTTZEROTIME;
	transmitSch.priority = RTTNORM;
	transmitSch.deadline = RTTNODEADLINE;


	receiveName = "receive";
	receive = malloc(sizeof(RttThreadId));
	receiveSch.startingtime = RTTZEROTIME;
	receiveSch.priority = RTTNORM;
	receiveSch.deadline = RTTNODEADLINE;

	
	terminalName = "terminal";
	terminal = malloc(sizeof(RttThreadId));
	terminalSch.startingtime = RTTZEROTIME;
	terminalSch.priority = RTTNORM;
	terminalSch.deadline = RTTNODEADLINE;
	printf("hello\n");

	/*start the threads*/
	if (debug == 1) {
		printf("Creating server thread\n");
	}
	RttCreate(server, serverThread, STACK_SIZE, serverName, NULL, serverSch, RTTUSR);
	
	if (debug == 1) {
		printf("Creating terminal thread\n");
	}
	RttCreate(terminal, terminalThread, STACK_SIZE, terminalName, NULL, terminalSch, RTTUSR);
	
	if (debug == 1) {
		printf("Creating receive thread\n");
	}
	RttCreate(receive, receiveThread, STACK_SIZE, receiveName, NULL, receiveSch, RTTUSR);
	
	if (debug == 1) {
		printf("Creating transmit thread\n");
	}
	RttCreate(transmit, transmitThread, STACK_SIZE, transmitName, NULL, transmitSch, RTTUSR);
	
	if (debug == 1) {
		printf("Creating keyboard thread\n");
	}
	RttCreate(keyboard, keyboardThread, STACK_SIZE, keyboardName, NULL, keyboardSch, RTTUSR);

	return 0;
}

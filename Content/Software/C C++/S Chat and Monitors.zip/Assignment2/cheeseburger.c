/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 2
	Part A
*/

#include "Monitor.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define STACK_BYTES 265000
#define RUN_TIME 1	/*this is the number of seconds the program will run for*/

typedef enum{bun = 0, meat = 1, cheese = 2, table = 3, JugheadBun = 4, JugheadMeat = 5, JugheadCheese = 6} Ingredients;

PID archie;
PID jughead[3];
PID threadTimer;



/**
	eatCheeseburger
	Description
		jughead leaves the table
	Preconditions
		-
	Postconditions
		-
	Return
		-
*/
void eatCheeseburger() {
	MonNotify(table);
}



/**
	makecheeseburger
	Description
		jughead takes the two ingredients he needs to make a cheeseburger
	Preconditions
		-
	Postconditions
		-
	Return
		-
*/
void makeCheeseburger(Ingredients num1, Ingredients num2) {
	MonWait(num1);
	MonWait(num2);
}



/**
	Jughead
	Description
		Jughead creates 1 ingredient, then takes the two others needed 
		from the table, and then makes and eats a cheeseburger
	Preconditions
		datIn contains the type of ingredient this jughead makes himself
	Postconditions
		-
	Return
		-
*/
void Jughead (void * dataIn) {
	Ingredients Ingredient;

	Ingredient = *(Ingredients *)dataIn;

	/*jughead continues to eat until he is killed*/
	while (1) {
		MonEnter();
		/*Has 1 ingredient*/

		/*Take the two ingredients that jughead doesn't have, then make the burger & eat it*/
		if (Ingredient == bun) {
			MonWait(JugheadBun);
			printf("J %d took (%d, %d)\n", (int)Ingredient, meat, cheese);
			printf("J %d making a burger\n", (int)Ingredient);
			makeCheeseburger(cheese,meat);
			printf("J %d eating the burger\n", (int)Ingredient);
			eatCheeseburger();
		} else if (Ingredient == meat) {
			MonWait(JugheadMeat);
			printf("J %d took (%d, %d)\n", (int)Ingredient, bun, cheese);
			printf("J %d making a burger\n", (int)Ingredient);
			makeCheeseburger(cheese,bun);
			printf("J %d eating the burger\n", (int)Ingredient);
			eatCheeseburger();
		} else if (Ingredient == cheese) {
			MonWait(JugheadCheese);
			printf("J %d took (%d, %d)\n", (int)Ingredient, bun, meat);
			printf("J %d making a burger\n", (int)Ingredient);
			makeCheeseburger(bun,meat);
			printf("J %d eating the burger\n", (int)Ingredient);
			eatCheeseburger();
		}

		/*leave the monitor*/
		MonLeave();
	}
}



/**
	Archie
	Description
		Archie makes 2 of the 3 possible ingredients at random, then places them on the table.  He then repeats this when the table is empty
	Preconditions
		-
	Postconditions
		-
	Return
		-
*/
void Archie () {
	int num1;
	int num2;

	/*make random generator random*/
	srand((unsigned int) time(0));

	while (1) {
		MonEnter();

		/*prepares 1 random ingredient*/
		num1 = rand() % 3;

		/*prepares 1 random ingredient different from the first*/
		num2 = rand() % 3;
		if (num1 == num2) {		/*if the second ingredient is the same as the first*/
			num2 = rand() % 2;	/*then run a new random number between two choices*/
			/*if a duplicate was selected again, then treat it as the choice not listed*/
			if (num1 == bun) {
				if (num2 == bun)
					num2 = cheese;
			} else if (num1 == meat) {
				if (num2 == meat)
					num2 = cheese;
			}
		}

		/*notify the monitor that the two new items are available*/
		MonNotify(num1);
		MonNotify(num2);
		printf("A notified (%d, %d) available\n", num1, num2);

		/* Archie says which jughead can go based on the ingredients that he put on the table. */
		if((num1 == cheese && num2 == meat) || (num2 == cheese && num1 == meat)) {
			MonNotify(JugheadBun);
		}
		else if ((num1 == cheese && num2 == bun) || (num2 == cheese && num1 == bun)) {
			MonNotify(JugheadMeat);
		}
		else {
			MonNotify(JugheadCheese);
		}

		/*loop*/
		MonLeave();
		MonWait(table);
	}
}



/**
	ThreadTimer
	Description
		waits a certain ammount of time, then ends the program by killing all the threads
	Preconditions
		-
	Postconditions
		all archie and jughead threads are ended
	Return
		-
*/
void ThreadTimer() {
	/*start the countdown for when to end the program*/
	Sleep(RUN_TIME);

	/*kill archie*/
	if (PExists(archie)) {
	  Kill(archie);
	}

	/*kill the jughead that makes buns*/
	if (PExists(jughead[bun])) {
	  Kill(jughead[bun]);
	}
		
	/*kill the jughead that makes meat*/
	if (PExists(jughead[meat])) {
	  Kill(jughead[meat]);
	}
	
	/*kill the jughead that makes cheese*/
	if (PExists(jughead[cheese])) {
	  Kill(jughead[cheese]);
	}

	/*kill this thread to end the program*/
	Pexit();
}



/**
	mainp
	Description
		starts the archie, jughead, and timer processes
	Preconditions
		-
	Postconditions
		all the required threads have started
	Return
		0 for success, 1 if an error occured
*/
int mainp() {
	Ingredients *Bun;
	Ingredients *Meat;
	Ingredients *Cheese;

	/*get problem threads going*/
	Bun = malloc(sizeof(Ingredients));
	Meat = malloc(sizeof(Ingredients));
	Cheese = malloc(sizeof(Ingredients));
	
	*Bun = bun;
	*Meat = meat;
	*Cheese = cheese;
	/* The table starts out empty */
	MonNotify(table);
	jughead[bun] = Create(Jughead,STACK_BYTES,"",Bun,NORM,USR);
	jughead[meat] = Create(Jughead,STACK_BYTES,"",Meat,NORM,USR);
	jughead[cheese] = Create(Jughead,STACK_BYTES,"",Cheese,NORM,USR);
	archie = Create(Archie,STACK_BYTES,"",NULL,NORM,USR);
	threadTimer = Create(ThreadTimer,STACK_BYTES,"",NULL,NORM,USR);

  return 0;
}


/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 1
	Part C
*/

#include <stdlib.h>
#include <stdio.h>
#include "list.h"





/*
ListCreate
	Creates a new list
Preconditions
	-
Postconditions
	A new list has been created, and a painter to it
Return
	A pointer to the new list
*/
LIST *ListCreate() {
	LIST *newList = checkListMemory ();
	return newList;
}





/*
ListAdd
	Adds an item directly below the list's selected item then selects the new item
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	the item has been added below the list's selected item and the new item has been selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListAdd (LIST *list, void *item) {
	/*Get the location of the new node*/
	NODE* newNodeNum = checkNodeMemory();
	
	/*make sure the node, given list, and given item exist*/
	if ((newNodeNum == NULL)||(list == NULL)||(item == NULL))
		return -1;
		
	if ((list->current == NULL)&&(list->size > 0))
		return -1;

	/*CASE 1: empty list*/
	if (list->size == 0) {
		list->head = newNodeNum;
		list->tail = newNodeNum;
		
		newNodeNum->prev = NULL;
		newNodeNum->next = NULL;
		
	/*CASE 2: list size = 1*/
	} else if (list->size == 1) {
		list->tail = newNodeNum;
		
		list->current->next = newNodeNum;
		
		newNodeNum->prev = list->current;
		newNodeNum->next = NULL;
		
	/*CASE 3: list size > 1*/
	} else if (list->size > 1) {
		
		newNodeNum->prev = list->current;
		
		if (list->current == list->tail) {
			list->tail = newNodeNum;
			newNodeNum->next = NULL;
		} else {
			newNodeNum->next = list->current->next;
			list->current->next->prev = newNodeNum;
		}
			
		list->current->next = newNodeNum;
	}
	
	list->current = newNodeNum;
	newNodeNum->data = item;	
	list->size++;

	/*Return 0 for success*/
        return 0;
}





/*
ListInsert
	Adds an item directly above the list's selected item then selects the new item
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	the item has been added above the list's selected item and the new item has been selected	
Return
	0 : successful operation
	-1 : operation failed
*/
int ListInsert(LIST *list, void *item) {
	/*Get the location of the new node*/
	NODE* newNodeNum = checkNodeMemory();

	/*make sure the node, given list, and given item exist*/
	if ((newNodeNum == NULL)||(list == NULL)||(item == NULL))
		return -1;

	if ((list->current == NULL)&&(list->size > 0))
		return -1;

	/*setup the prev, next, and data variables for the new node*/
	if (list->size == 0) {	/*case 1: empty list*/
		/*Setup New Node*/
		newNodeNum->prev = NULL;
		newNodeNum->next = NULL;

		/*Setup List to Handle new Node*/
		list->head = newNodeNum;
		list->tail = newNodeNum;
	
	} else {	/*case 2: non-empty list*/
		
		newNodeNum->next = list->current;
		
		if (list->current == list->head) {
			list->head = newNodeNum;
			newNodeNum->prev = NULL;
		} else {
			newNodeNum->prev = list->current->prev;
			newNodeNum->prev->next = newNodeNum;
		}
			
		list->current->prev = newNodeNum;
	}
	
	list->current = newNodeNum;
	newNodeNum->data = item;	
	list->size++;

	/*Return 0 for success*/
        return 0;
}





/*
ListAppend
	Adds a new item to the end of the list, then selects it
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	The new item has been added to the end of the list and selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListAppend(LIST *list, void *item) {
	/*Get the location of the new node*/
	NODE* newNodeNum = checkNodeMemory();
	
	/*make sure the node and input info exist*/
	if ((newNodeNum == NULL)||(list == NULL)||(item == NULL))
		return -1;
	
	/*setup the prev, next, and data variables for the new node*/
	if (list->size == 0) {	/*case 1: empty list*/
		/*Setup New Node*/
		newNodeNum->prev = NULL;
		newNodeNum->next = NULL;
		
		/*Setup List to Handle new Node*/
		list->head = newNodeNum;
		list->tail = newNodeNum;
		list->current = newNodeNum;
		
	} else {	/*case 2: non-empty list*/
		
		/*Setup New Node*/
		newNodeNum->prev = list->tail;
		newNodeNum->next = NULL;
		
		/*update other node*/
		list->tail->next = newNodeNum;
		
		/*Setup List*/
		list->tail = newNodeNum;
		list->current = newNodeNum;
	}
	
	newNodeNum->data = item;
	list->size++;
	
	/*Return 0 for success*/
	return 0;
}





/*
ListPrepend
	Adds a new item to the start of the list, then selects it
Preconditions
	list must contain a pointer to a valid list
	item must contain a pointer to a valid item
Postconditions
	The new item has been added to the start of the list and selected
Return
	0 : successful operation
	-1 : operation failed
*/
int ListPrepend(LIST *list, void *item) {
	/*Get the location of the new node*/
	NODE* newNodeNum;
	newNodeNum = checkNodeMemory();
	
	/*make sure the node and input info exist*/
	if ((newNodeNum == NULL)||(list == NULL)||(item == NULL))
		return -1;

	/*setup the prev, next, and data variables for the new node*/
	if (list->size == 0) {	/*case 1: empty list*/
		/*Setup New Node*/
		newNodeNum->prev = NULL;
		newNodeNum->next = NULL;

		/*Setup List to Handle new Node*/
		list->head = newNodeNum;
		list->tail = newNodeNum;
		list->current = newNodeNum;
	
	} else {	/*case 2: non-empty list*/

		/*Setup New Node*/
		newNodeNum->prev = NULL;
		newNodeNum->next = list->head;
		
		/*Setup old head node*/
		list->head->prev = newNodeNum;

		/*Setup List*/
		list->head = newNodeNum;
		list->current = newNodeNum;
	}

	newNodeNum->data = item;
	list->size++;

	/*Return 0 for success*/
        return 0;
}





/*
ListConcat
	Adds the data from list 2 to list 1, then destroys list 2
Preconditions
	list1 must contain a pointer to a valid list
	list2 must contain a pointer to a second vaid list
Postconditions
	data from list 2 is now in list 1, and list 2 is gone
Return
	-
*/
void ListConcat(LIST *list1, LIST *list2) {
	/*Declare Variables
	int i;*/

	/*ensure both lists exist*/
	if ((list1 == NULL) || (list2 == NULL))
		return;
		
	/*CASE 1: list1 !empty; list2 !empty*/
	if ((list1->size > 0 ) && (list2->size > 0)) {
		list1->tail->next = list2->head;
		list2->head->prev = list1->tail;
		list1->tail = list2->tail;
		list1->size += list2->size;
	
		/*Remove the empty second list*/
		removeLists(list2);
	
	/*CASE 2: list1 empty; list2 !empty*/
	} else if ((list1->size == 0 ) && (list2->size > 0)) {
		list1->head = list2->head;
		list1->tail = list2->tail;
		list1->size = list2->size;
	
		/*Remove the empty second list*/
		removeLists(list2);
	
	/*CASE 3: list1 !empty; list2 empty*/
	} else if ((list1->size > 0 ) && (list2->size == 0)) {
		/*Remove the empty second list*/
		removeLists(list2);
	
	/*CASE 4: list1 empty; list2 empty*/
	} else if ((list1->size == 0 ) && (list2->size == 0)) {
		/*Remove the empty second list*/
		removeLists(list2);
	}
}




/*
checkNodeMemory
	*NOTE: 	this algorithm works when nodes are never removed.  It will have to be modified when add 			node removal functionality in added
	Checks if there is enough memory available for a new node, and if there isn't, then it makes room
Preconditions
	-
Postconditions
	a free node is found, and memory may have been increased
Return
	a pointer to the free node
	NULL if an error occurs
*/
NODE* checkNodeMemory () {
	/*Declare Variables*/
	NODE *newNode;
	int i = 0;
	
	/*create the node store using minimum values if it doesn't exist yet*/
	if (nodeStore == NULL) {
		nodeStore = malloc(sizeof(NODESTORE));
		nodeStore->size = MIN_NODES;
		nodeStore->numFree = MIN_NODES;
		nodeStore->nodeList = malloc(nodeStore->size*sizeof(NODE*));

		/*create the initial nodes*/
		for (i = 0; i < nodeStore->size; i++) {
			nodeStore->nodeList[i] = malloc(sizeof(NODE));
			nodeStore->nodeList[i]->prev = NULL;
			nodeStore->nodeList[i]->next = NULL;
			nodeStore->nodeList[i]->data = NULL;
		}	

	}


	/*double the node store size if no space left*/
	if (nodeStore->numFree == 0) {
		/*setup the new list so it now has as many free nodes as used nodes*/
		nodeStore->nodeList = realloc(nodeStore->nodeList, nodeStore->size*sizeof(NODE*));

		/*setup the new empty nodes for future use*/
		for (i = 0; i < nodeStore->size; i++) {
			nodeStore->nodeList[i] = (NODE *)malloc(sizeof(NODE));
			nodeStore->nodeList[i]->prev = NULL;
			nodeStore->nodeList[i]->next = NULL;
			nodeStore->nodeList[i]->data = NULL;
		}		

		/*set the node store size indicators*/
		nodeStore->numFree += nodeStore->size;
		nodeStore->size += nodeStore->size;
	}

	/*Pull a free node for the user*/
	nodeStore->numFree--;
	newNode = nodeStore->nodeList[nodeStore->numFree];
	nodeStore->nodeList = realloc(nodeStore->nodeList, nodeStore->numFree*sizeof(NODE*));


	/*Return the heap address of the new node*/

	/*
	printf("NUMBER OF FREE NODES: %d; NUMBER OF NODES IN TOTAL: %d\n", nodeStore->numFree, nodeStore->size);
    */
    	return newNode;
}







LIST* checkListMemory (){
	LIST *newList;
	int i = 0;
	/*create the list store using minimum values if it doesn't exist yet*/
	if (listStore == NULL) {
		listStore = malloc(sizeof(LISTSTORE));
		listStore->size = MIN_LISTS;
		listStore->numFree = MIN_LISTS;
		listStore->listList = malloc(listStore->size*sizeof(LIST*));

		/*create the initial lists*/
		for (i = 0; i < listStore->size; i++) {
			listStore->listList[i] = malloc(sizeof(LIST));
			listStore->listList[i]->size = 0;
			listStore->listList[i]->head = NULL;
			listStore->listList[i]->tail = NULL;
			listStore->listList[i]->current = NULL;
		}	

	}


	/*double the list store size if no space left*/
	if (listStore->numFree == 0) {
		/*create the new list so it now has as many free lists as used lists*/
		listStore->listList = realloc(listStore->listList, listStore->size*sizeof(LIST*));

		/*setup the new empty lists for future use*/
		for (i = 0; i < listStore->size; i++) {
			listStore->listList[i] = (LIST *)malloc(sizeof(LIST));
			listStore->listList[i]->size = 0;
			listStore->listList[i]->head = NULL;
			listStore->listList[i]->tail = NULL;
			listStore->listList[i]->current = NULL;
		}		

		/*set the list store size indicators*/
		listStore->numFree += listStore->size;
		listStore->size += listStore->size;
	}



	/*Pull a free list for the user*/
	listStore->numFree--;
	newList = listStore->listList[listStore->numFree];
	listStore->listList = realloc(listStore->listList, listStore->numFree*sizeof(LIST*));

	/*Return the heap address of the new list*/
        return newList;
}


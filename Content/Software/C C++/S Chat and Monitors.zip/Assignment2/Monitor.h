/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 2
	Part A
*/

#ifndef Monitor_h
#define Monitor_h
#include <stdlib.h>
#include <stdio.h>

#include <os.h>
#include <standards.h>
#define entrySem 9
#define urgentSem 8

typedef struct {
	int S;
	int size;
	int value;
} sem;

sem semaphore[10]; 

int *initialized;




/**
	MonEnter
	Description
		This function fakes the entry into the monitor object.
		If the monitor is occupied, then the process PID is
		added to a list of waiting processes & suspended
	Preconditions
		process is not in the monitor
	Postconditions
		The process is in the monitor
	Return
		-
*/
void MonEnter();





/**
	MonWait
	Description
		This function waits until a certain condition variable is true.
		Passes in the indexes of the condition variables that it is waiting for.
	Preconditions
		process is in the monitor
		an acceptable condition variable is input (integer ids 0 through 7 are acceptable)
	Postconditions
		the process has decremented the condition variable
	Return
		-
*/
int MonWait(int condVar);





/**
	MonInit
	Description
		Setup Data Structure for the monitor.
	Preconditions
		the monitor has not already been initialized
	Postconditions
		the monitor is initialized
	Return
		-
*/
void MonInit();





/**
	MonLeave
	Description
		Last statement executed before return.
		Tells the monitor that the process is out of it, and puts the next
		waiting process into the monitor
	Preconditions
		process is in the monitor
	Postconditions
		Process is out of the monitor, and next waiting process is in the monitor
	Return
		-
	
*/
void MonLeave();





/**
MonNotify
Description
	Tells the monitor that the condition variable is true.
	Waiting process resumes when the notifying process leaves the monitor
Preconditions
		process is in the monitor
		an acceptable condition variable is input (integer ids 0 through 7 are acceptable)
	Postconditions
		this process woke up the next process waiting on the condition variable (if one exists) &
		incremented the condition variable
	Return
		-
*/
int MonNotify(int condVar);
#endif

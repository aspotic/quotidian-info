/*
	Adam Knox & Devon Dietrich
	ark043 & djd232
	11049279 & 11053192
	CMPT 332
	Assignment 1
	Part C
*/

#include <stdio.h>
#include <stdlib.h>
#include "list.h"





/*
ListRemove
	Removes the selected item from the list and selects the next item in the list
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the item is no longer in the list
Return
	The removed item
*/
void *ListRemove (LIST *list) {
	/*Declare variables*/
	void *removedData;
	NODE *removedNode;
	/*check for an empty or nonexistent list*/
	/*CASE 1: Empty list*/
	if ((list == NULL) || (list->size == 0)||(list->current == NULL) || (list->current == NULL))
		return NULL;

	/*Store the pointer to the data in the node being removed*/
	removedData = list->current->data;
	
	/*Remove the node from the list*/
	removedNode = list->current;

	/*CASE 2: Only 1 item in the list*/
	if ((list->current == list->tail)&&(list->current == list->head)) {
		list->head = NULL;
		list->tail = NULL;
		list->current = NULL;
		list->size--;
	
	/*CASE 3: current item is the last one in the list, but not the only item*/
	} else if ((list->current == list->tail)&&(list->current != list->head)) {
		list->current->prev->next = NULL;
		list->tail = list->current->prev;
		list->current = list->current->prev;
		list->size--;
	
	/*CASE 4: current item is not the last one or the first one, and also not the only item*/
	} else if ((list->current != list->tail)&&(list->current != list->head)) {
		list->current->prev->next = list->current->next;
		list->current->next->prev = list->current->prev;
		list->current = list->current->next;
		list->size--;

	/*CASE 5: current item is the head, but not the only item*/
	} else if ((list->current != list->tail)&&(list->current == list->head)) {
		list->current->next->prev = NULL;
		list->head = list->current->next;
		list->current = list->current->next;
		list->size--;
	}
	
	
	/*Free the node*/
	removeNodes(removedNode);

	/*Return the address to the data that was in the node*/
	return removedData;
}





/*
ListTrim
	Removes the last item in the list and returns it, 
	then sets the new selected item to be the new last item
Preconditions
	list must contain a pointer to a valid list
Postconditions
	the last item in the list has been removed
Return
	a pointer to the removed item
*/
void *ListTrim(LIST* list) {
	/*Declare variables*/
	void *removedData;
	NODE *removedNode;

	/*check for an empty or nonexistent list*/
	if ((list == NULL) || (list->size == 0))
		return NULL;

	/*Store the pointer to the data in the node being removed*/
	removedData = list->tail->data;
	list->current = list->tail;
	
	/*Remove the node from the list*/
	removedNode = list->current;
	
	/*Deal with removing a node from a list of size > 1*/
	if (list->size > 1) {
		/*deal with removing the node at the bottom of the list*/
			list->current->prev->next = NULL;	/*Make prev node skip current node going forward*/
			list->tail = list->current->prev;
			list->current = list->tail;	
		
	/*Deal with removing a node from a list of size == 1*/
	} else {
		list->head = NULL;
		list->current = NULL;
		list->tail = NULL;
	}
	
	/*Reflect new size of list in the list structure*/
	list->size--;
	
	/*Free the node*/
		removeNodes(removedNode);


	/*Return the address to the data that was in the node*/
	return removedData;
}





/*
ListFree
	
Preconditions
	list must contain a pointer to a valid list
	itemFree must contain a pointer to a routine that will free an item
Postconditions
	The list is removed
Return
	-
*/
void ListFree(LIST *list, void (*itemFree)(void *)) {
	/*Declare variables*/
	int i;
	NODE *removedNode;
	
	/*If there is no list, or the user is attempting to refree a list, then nothing to do*/
	if (list == NULL)
		return;
	
	/*remove each node from the list*/
	list->current = list->tail;
	for (i = 0; i < list->size; i++) {
		/*Free the node*/
		removedNode = list->current;
	
		if (list->current == NULL) {
			printf("premature list->current=NULL in ListFree()\n");
		} else {
			/*Free the item*/
			(*itemFree)(list->current->data);
			/*Remove the node*/
			list->current = removedNode->prev;
			removeNodes(removedNode);
		}
		
	}
	
	removeLists(list);
}





void removeNodes(NODE* removedNode){
	int minNodes = MIN_NODES;
		
		/*half the node store size if half the nodes are empty*/
		if (((nodeStore->size - nodeStore->numFree) == nodeStore->numFree) && ((nodeStore->size - nodeStore->numFree) > minNodes)) {
		/*reallocate memory so that all the free nodes no longer exist, but leave room for the one about to be added*/
			nodeStore->nodeList = realloc(nodeStore->nodeList, (nodeStore->numFree + 1)*sizeof(NODE*));	
	
			/*set the node store size indicators*/
			nodeStore->numFree = 1;
			nodeStore->size = (nodeStore->numFree + 1);
		
		/*add room in the array for 1 free node*/
		} else {
			/*reallocate mem. so there is room for one more item*/
			nodeStore->nodeList = realloc(nodeStore->nodeList, (nodeStore->numFree + 1)*sizeof(NODE*));	
	
			/*set the node store size indicators*/
			nodeStore->numFree++;
		}
		
	
		/*clean out the added free node*/
		nodeStore->nodeList[nodeStore->numFree-1] = removedNode;	/*Put name of node being freed here*/
		nodeStore->nodeList[nodeStore->numFree-1]->prev = NULL;
		nodeStore->nodeList[nodeStore->numFree-1]->next = NULL;
		nodeStore->nodeList[nodeStore->numFree-1]->data = NULL;
}





void removeLists(LIST* removedList){
	int minLists = MIN_LISTS;
	/*put list back in the available lists list*/
	/*half the list store size if half the lists are empty and the final
		number of lists will be greater than the minimun required*/
	if (((listStore->size - listStore->numFree) == listStore->numFree) && ((listStore->size - listStore->numFree) > minLists)){
		/*reallocate memory so that all the free lists no longer exist, but leave room for the one about to be added*/
		listStore->listList = realloc(listStore->listList, (listStore->numFree + 1)*sizeof(LIST*));	

		/*set the list store size indicators*/
		listStore->numFree = 1;
		listStore->size = (listStore->numFree + 1);
	
	/*add room in the array for 1 free node*/
	} else {
		/*reallocate mem. so there is room for one more list*/
		listStore->listList = realloc(listStore->listList, (listStore->numFree + 1)*sizeof(LIST*));	

		/*set the list store size indicators*/
		listStore->numFree++;
	}

	/*clean out the added free list*/
	listStore->listList[listStore->numFree-1] = removedList;	/*Put name of list being freed here*/
	listStore->listList[listStore->numFree-1]->size = 0;
	listStore->listList[listStore->numFree-1]->head = NULL;
	listStore->listList[listStore->numFree-1]->tail = NULL;
	listStore->listList[listStore->numFree-1]->current = NULL;
}

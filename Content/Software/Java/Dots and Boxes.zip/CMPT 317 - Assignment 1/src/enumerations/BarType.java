package enumerations;

/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * the bar orientations on this board
 */
public enum BarType {
	Horizontal, Vertical;
	
	public static BarType swap(BarType value) {
		if (value == BarType.Vertical) {
			return BarType.Horizontal;
		} else {
			return BarType.Vertical;
		}
	}
}

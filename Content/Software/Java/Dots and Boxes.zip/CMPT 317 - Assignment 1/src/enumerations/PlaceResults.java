package enumerations;

/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * the possible result from attempting to place a bar on the board
 */
public enum PlaceResults {
	Placed, AlreadyTaken, SquareFormed
}

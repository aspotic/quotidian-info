package enumerations;

/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * the possible values a box on the board may have
 */
public enum BoxValues {
	b, H, C;
	
	public static BoxValues switchPlayer(BoxValues currentPlayer) {
		if (currentPlayer == BoxValues.C) {
			return BoxValues.H;
		} else if (currentPlayer == BoxValues.H) {
			return BoxValues.C;
		} else {
			return currentPlayer;
		}
	}
}

import algorithms.SearchTree;
import algorithms.SearchTreeAB;
import datastructures.Board;
import enumerations.BoxValues;

/**
 * 
 * @author adam knox
 * ark043
 * CMPT 317
 * Assignment 1
 *
 * runs the program
 * 
 * NOTE: because of memory constraints, I designed the algorithm to be able to drop nodes from the tree when they wont be looked at again.
 * this may be turned off, but will cause the board size to be limited by memory. the node count is a count of all the nodes that were created by the
 * search, and is only the number of nodes in the actual tree when it doesn't drop nodes after they are done with.
 * 
 * To change the board used, just update the variable boardFileName to contain the appropriate game board
 * 
 * The board representation is in Board.java. I separated the parts of the board into 3 components. one matrix for vertical lines, one for horizontal lines,
 * and one for the box owners C, H, or b. I did this because the dots do not need to be stored in memory, and the lines are accessed more often than the box
 * owners, and keeping them in the same matrix causes the computer to have to move through a larger matrix than necessary.  The vertical and horizontal lines
 * probably could have been kept in the same matrix. Though this method of storage makes the computer get through the operations faster, it also makes reading
 * in boards more complicated, and requires a bit more coding. I think the best representation would have been one matrix for lines (no dots), and a second for box owners.
 * 
 * ------ Results for board 1 ------
 * minimax
 * winner: Tie
 * score: 2 to 2
 * nodes generated: 242 337 217
 * .-.-.
 * |H|C|
 * .-.-.
 * |H|C|
 * .-.-.
 * 
 * minimax with alpha beta pruning
 * winner: 
 * score: 2 to 2
 * nodes generated: 75 687
 * .-.-.
 * |H|C|
 * .-.-.
 * |H|C|
 * .-.-.
 * 
 * ------ Results for board 2 ------
 * minimax
 * winner: human
 * score: 3 to 1
 * nodes generated: 503
 * .-.-.
 * |H|H|
 * .-.-.
 * |C|H|
 * .-.-.
 * 
 * minimax with alpha beta pruning
 * winner: human
 * score: 3 to 1
 * nodes generated: 113
 * .-.-.
 * |H|H|
 * .-.-.
 * |C|H|
 * .-.-.
 * 
 * ------ Results for board 3 ------
 * minimax
 * winner: computer 
 * score: 4 to 0
 * nodes generated: 81
 * .-.-.
 * |C|C|
 * .-.-.
 * |C|C|
 * .-.-.
 * 
 * minimax with alpha beta pruning
 * winner: computer
 * score: 4 to 0
 * nodes generated: 33
 * .-.-.
 * |C|C|
 * .-.-.
 * |C|C|
 * .-.-.
 * 
 * Discussion
 * I calculated that there should theoretically be the sum from i = 0 to N of N!/i! nodes generated
 * in a minimax search tree assuming a node is generated even for a player who is allowed to move a second time
 * where N is the number of possible bar placements on the initial board. this function follows an exponential
 * curve meaning as the board size increases by one bar, the search space increases by N times the previous search
 * space.  This is a very steep curve meaning scalability to larger systems is extremely poor. Running the algorithm
 * (without alpha beta pruning) took a few hours for a 2 by 2 board so a 2x3 board would likely take days to run.
 * This means that for any reasonable board size, the minimax search is not practical because of time constraints
 * The alpha beta pruning does significantly decrease the number of nodes generated, meaning the search runs much
 * more quickly. it took only a couple seconds for a 2x2 board. The curve is still exponential though because a 2x3
 * board took much longer. This means the minimax is not practical, and the minimax with alpha beta pruning is only
 * slightly more practical, but still not very.
 * 
 */
public class run {
	private static String boardFileName = "Board1.txt";		//the filename of the board to read in as the initial board configuration
	private static BoxValues nextPlayer = BoxValues.C;		//the player who will make the next move on the initial board
	private static boolean dropNodes = true;				//true if the nodes are dropped after use to save on memory; false to keep the search tree intact
	private static boolean samePlayerNodes = false;			//true means a single turn may have multiple nodes; false means each turn only has one node
	
	public static void main(String[] val) {
		//Create the initial board
		Board board = new Board(boardFileName);
		
		//Run the minimax search on the board to get the result of a game between two optimal players
		//SearchTree searchTree = new SearchTree(board, nextPlayer, dropNodes, samePlayerNodes);
		
		//display the result of the minimax algorithm
		//searchTree.printResult();
		
		//run the minimax search using alpha beta pruning
		SearchTreeAB searchTreeAB = new SearchTreeAB(board, nextPlayer, dropNodes, samePlayerNodes);
		
		//display the results of the minimax search with alpha beta pruning
		searchTreeAB.printResult();
	}
}

package algorithms;

import datastructures.Board;
import datastructures.Node;
import enumerations.BarType;
import enumerations.BoxValues;
import enumerations.PlaceResults;
/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * builds the search tree and returns the result of two optimal players using the minimax algorithm
 */
public class SearchTree {

	private Board finalBoard;	//the outcome board of a game between two optimal players
	private int columns;		//number of columns of boxes on the board
	private int rows;			//number of rows of boxes in the board
	private BoxValues playFor;	//who the algorithm tries to win the game for
	private Node tree;			//the top node of the search tree
	private long nodeCount;		//the number of nodes in the search tree
	private boolean dropNodes;	//true if the nodes are dropped after use to save on memory; false to keep the search tree intact
	private boolean samePlayerNodes;	//true means a single turn may have multiple nodes; false means each turn only has one node
	
	
	
	
	/**
	 * 
	 * @param initialBoard the board on which the first move will be made
	 * @param player the player performing the first move on the initial board
	 */
	public SearchTree(Board initialBoard, BoxValues player, boolean dropNodes, boolean samePlayerNodes) {
		this.samePlayerNodes = samePlayerNodes; 
		//set whether or not nodes should be dropped
		this.dropNodes = dropNodes;
		//set the board dimensions
		columns = initialBoard.getColumns();
		rows = initialBoard.getRows();
		//store who the algorithm should optimize for
		playFor = player;
		//create search tree's first node
		tree = new Node(null);
		nodeCount = 1;
		tree.board = new Board(initialBoard);
		//get the final board (run the minimax algorithm)
		finalBoard = minimax(tree, player);
	}
	
	
	
	
	/**
	 * 
	 * @param node the node containing the current board state
	 * @param player the player who is going to move off the current board
	 * @return the board after the player has made the optimal move
	 */
	private Board minimax(Node node, BoxValues player) {
		
		//the board is full, so the end of the tree has been reached so return the board
		if (node.board.isFull()) {
			node.board.score = node.board.getNumBoxesWon(playFor);
			return node.board;
		}
		
		//the board is not yet full, so check for optimal choice
		else {
			int maxR = rows;
			int maxC = columns + 1;
			int optimalNode = -1;
			BarType barType = BarType.Vertical;
			int optimalScore = Integer.MIN_VALUE;
			int sign;
			
			//choose to maximize or minimize
			if (this.playFor == player) {
				sign = 1;
			} else {
				sign = -1;
			}
			
			//check each possible play
			for (int t = 0; t < 2; t++) {
				for (int c = 0; c < maxC; c++) {
					for (int r = 0; r < maxR; r++) {
						//-----check if the bar placement is valid------
						Board board = new Board(node.board);
						PlaceResults placeStatus = board.placeBar(barType, player, r, c);

						if ((placeStatus == PlaceResults.SquareFormed) && (!samePlayerNodes)) {
							this.nodeCount--;
						}
						
						if (placeStatus != PlaceResults.AlreadyTaken) {
							//create a child with the appropriate bar placement
							Node child = new Node(node);
							child.board = board;
							nodeCount++;
							
							//add the child to the current node
							node.newChild(child);
							
							//switch players if a bar was placed but no square formed
							if (placeStatus == PlaceResults.Placed) {
								player = BoxValues.switchPlayer(player);
							}
								
							//get the score for the current child
							child.board = minimax(child, player);
							
							//undo player change
							if (placeStatus == PlaceResults.Placed) {
								player = BoxValues.switchPlayer(player);
							}
							
							//check if score is currently the best choice
							if (sign*child.board.score > optimalScore) {
								optimalNode = node.numChildren()-1;
								optimalScore = node.child(optimalNode).board.score;
							}
						}
					}
				}
				//setup for horizontal bar placements
				barType = BarType.swap(barType);
				maxR++;
				maxC--;				
			}
			
			//get the optimal play
			Board optimal = new Board(node.child(optimalNode).board);
			
			//get rid of the child nodes since they wont be touched again and they take up large amounts of memory
			if (dropNodes) {node.removeChildren();}
			
			//return the optimal board
			return optimal;
		}
	}
	
	
	
	
	/**
	 * prints the result of the game to the screen
	 */
	public void printResult() {
		int humanWon = finalBoard.getNumBoxesWon(BoxValues.H);
		int computerWon = finalBoard.getNumBoxesWon(BoxValues.C);

		System.out.println("Minimax Algorithm");
		System.out.println("Boxes won by human: " + humanWon);
		System.out.println("Boxes won by computer: " + computerWon);
		
		if (humanWon > computerWon) {
			System.out.println("The human won the game");
		} else if (humanWon < computerWon) {
			System.out.println("The computer won the game");
		} else if (humanWon == computerWon) {
			System.out.println("Tie game");
		} 

		//theoretically the number of nodes should be the sum from i=0 to N of N!/i! where N is the number of possible bar placements on the initial board
		System.out.println("Number of nodes search algorithm checked (if a player gets to go again, it counts as another node): " + nodeCount);
		
		System.out.println();
		finalBoard.printBoard(0);
		System.out.println();
	}
}
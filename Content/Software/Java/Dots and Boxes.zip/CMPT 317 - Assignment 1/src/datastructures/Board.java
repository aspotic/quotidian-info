package datastructures;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import enumerations.BarType;
import enumerations.BoxValues;
import enumerations.PlaceResults;

/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * Stores the dots and boxes board and necessary information about the board in its current state
 */
public class Board {
	
	private boolean[][] Vlines;		//A matrix that stores all the possible vertical bars; true means a bar is in that position, false means it has not be placed
	private boolean[][] Hlines;		//A matrix that stores all the possible horizontal bars; true means a bar is in that position, false means it has not be placed
	private BoxValues[][] Owner;	//A matrix that stores all the box states (blank (b), human (H), or computer (C))

	private int rows;				//The number of rows of possible boxes on the board
	private int columns;			//The number of columns of possible boxes on the board
	
	private int computerBoxes = 0;	//The number of boxes currently held by the computer
	private int humanBoxes = 0;		//The number of boxes currently held by the human
	
	public int score;				//The score for this board (the best possible score for the player being optimized for)
	
	
	
	
	/**
	 * @description Creates a new board from file
	 * 
	 * @param filename the name of the text file to use, including .txt at the end
	 */
	public Board (String filename) {
		//figure out board dimensions
		try {
			FileInputStream fstream = new FileInputStream(filename);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//read the file line by line
			rows = 0;
			while ((strLine = br.readLine()) != null)   {columns = strLine.length(); rows++;}
			rows = (rows-1)/2;
			columns = (columns-1)/2;
			//close the input stream
			in.close();
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
		//construct matrices
		Owner = new BoxValues[this.rows][this.columns];
		Vlines = new boolean[this.rows][this.columns + 1];
		Hlines = new boolean[this.rows + 1][this.columns];

		
		//read in the board
		try {
			FileInputStream fstream = new FileInputStream(filename);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			  
			//read the file line by line
			int row = 1;
			while ((strLine = br.readLine()) != null)   {
				
				//fill the matrices
				//handles even rows
				if (row % 2 == 0) {
					//loop through each column
					for (int col = 1; col <= strLine.length(); col++) {
						String character = strLine.substring(col-1, col);
						
						//if on an even column, then the cell is either b, C, or H
						if (col % 2 == 0) {
							BoxValues boxVal = enumerations.BoxValues.valueOf(character);
							Owner[row/2-1][col/2-1] = boxVal;
							
							//increment the number of boxes held by the player
							if (boxVal == BoxValues.C) {
								this.computerBoxes++;
							} else if (boxVal == BoxValues.H) {
								this.humanBoxes++;
							}
								
						//if on an odd column, then the cell is either b, or |
						} else {
							if (character.equals("|")) {
								Vlines[row/2-1][col/2] = true;
							} else {
								Vlines[row/2-1][col/2] = false;
							}
						}
					}
				//handles odd rows
				} else {
					//only look at odd columns
					for (int col = 2; col < strLine.length(); col+=2) {
						String character = strLine.substring(col-1, col);
						//set horizontal line cell to true if a -; false if a b
						if (character.equals("-")) {
							Hlines[row/2][col/2-1] = true;
						} else {
							Hlines[row/2][col/2-1] = false;
						}
					}
				}
				row++;
			}
			//close the input stream
			in.close();
			
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	
	
	
	/**
	 * @description Copies another board
	 * 
	 * @param board the board to duplicate
	 */
	public Board (Board board) {
		this.rows = board.getRows();
		this.columns = board.getColumns();
		this.computerBoxes = board.computerBoxes;
		this.humanBoxes = board.humanBoxes;
		
		Owner = new BoxValues[this.rows][this.columns];
		Vlines = new boolean[this.rows][this.columns + 1];
		Hlines = new boolean[this.rows + 1][this.columns];
		
		for (int r = 0; r < this.rows; r++) {
			for (int c = 0; c < this.columns; c++) {
				this.Vlines[r][c] = board.Vlines[r][c];
				this.Hlines[r][c] = board.Hlines[r][c];
				this.Owner[r][c] = board.Owner[r][c];
			}
		}
		
		for (int r = 0; r < this.rows; r++) {
			this.Vlines[r][this.columns] = board.Vlines[r][this.columns];
		}
		
		for (int c = 0; c < this.columns; c++) {
			this.Hlines[this.rows][c] = board.Hlines[this.rows][c];
		}
	}
	
	
	
	
	/**
	 * 
	 * @return the number of rows of potential boxes
	 */
	public int getRows() {
		return rows;
	}
	
	
	
	
	/**
	 * 
	 * @return the number of columns of potential boxes
	 */
	public int getColumns() {
		return columns;
	}
	
	
	
	
	/**
	 * 
	 * @param player the player who's box count to get
	 * @return the number of boxes the player has won so far
	 */
	public int getNumBoxesWon (BoxValues player) {
		if (player == BoxValues.C)
			return this.computerBoxes;
		else if (player == BoxValues.H)
			return this.humanBoxes;
		else
			return -1;
	}
	
	
	
	
	/**
	 * 
	 * @return true if the board is full, false if there are still places available
	 */
	public boolean isFull () {
		if ((this.humanBoxes + this.computerBoxes) == (this.rows * this.columns))
			return true;
		else
			return false;
	}
	
	
	
	
	/**
	 * @description Places a bar on the requested position
	 * @param barType the type of bar being placed (horizontal or vertical)
	 * @param player the player who wants to place a bar
	 * @param row the row index of where the bar should be placed
	 * @param column the column index of where the bar should be placed
	 * @return AlreadyTaken if a bar was already there; Placed if the bar was placed; SquareFormed if the placed bar formed a square
	 */
	public PlaceResults placeBar(BarType barType, BoxValues player, int row, int column) {
		if (barType == BarType.Horizontal) {
			
			//bar placed
			if (Hlines[row][column] == false) {
				Hlines[row][column] = true;
				
				//Square formed and claimed
				if (findAndSetSquares(true, player, barType, row, column)) {
					return PlaceResults.SquareFormed;
				} 
				
				//no square formed
				else {
					return PlaceResults.Placed;
				}
				
			//bar already there
			} else {
				return PlaceResults.AlreadyTaken;
			}
		} 
		
		else {
			//bar placed
			if (Vlines[row][column] == false) {
				Vlines[row][column] = true;
				
				//Square formed and claimed
				if (findAndSetSquares(true, player, barType, row, column)) {
					return PlaceResults.SquareFormed;
				} 
				
				//no square formed
				else {
					return PlaceResults.Placed;
				}
				
			//bar already there
			} else {
				return PlaceResults.AlreadyTaken;
			}
		}
	}

	
	
	
	/**
	 * @description removes the bar at the requested position
	 * @param barType the type of bar being pulled (horizontal or vertical)
	 * @param player the player removing the bar
	 * @param row the row index of the bar to be removed
	 * @param column the column index of the bar to be removed
	 * @return true if the bar was removed, false if it wasn't there to begin with
	 */
	public boolean pullBar(BarType barType, BoxValues player, int row, int column) {
		if (barType == BarType.Horizontal) {
			//bar is currently there
			if (Hlines[row][column] == true) {
				Hlines[row][column] = false;
				
				//unclaim any squares
				findAndSetSquares(false, player, barType, row, column);
				
				return true;
				
			//bar not there, so can't be pulled
			} else {
				return false;
			}
		}
		
		else {
			//bar is currently there
			if (Vlines[row][column] == true) {
				Vlines[row][column] = false;
				
				//unclaim any squares
				findAndSetSquares(false, player, barType, row, column);
				
				return true;
				
			//bar not there, so can't be pulled
			} else {
				return false;
			}
		}
	}
	
	
	
	
	/**
	 * @description claims/unclaims squares adjacent to the bar
	 * @param isTakingSquare true if the square is being claimed, false if it is being reset to blank
	 * @param player the player to claim/unclaim any squares
	 * @param type the type of bar placed/pulled. vertical or horizontal
	 * @param row the row the bar was/is in (wrt the bar type's matrix)
	 * @param col the column the bar was/is in (wrt the bar type's matrix)
	 * @return true if any squares were taken/reset, false if none were taken/reset
	 */
	private boolean findAndSetSquares(boolean isTakingSquare, BoxValues player, BarType type, int row, int col) {
		boolean squareFormed = false;

		//check for a horizontally placed bar
		if  (type == BarType.Horizontal) {
			//check above if not at top of board
			if (row > 0) {
				int barCount = 1;
				//check for a bar on the right
				if (Vlines[row-1][col+1])
					barCount++;
				
				//check for a bar on the left
				if (Vlines[row-1][col])
					barCount++;
				
				//check for a bar above
				if (Hlines[row-1][col])
					barCount++;
				
				//if a box is formed, then claim the box
				if (barCount == 4) {
					setSquare(isTakingSquare, player, row-1, col);
					squareFormed = true;
				}
			}
			
			//check below if not at bottom of board
			if (row < rows) {
				int barCount = 1;
				//check for a bar on the right
				if (Vlines[row][col+1])
					barCount++;
				
				//check for a bar on the left
					if (Vlines[row][col])
						barCount++;
				
				//check for a bar below
					if (Hlines[row+1][col])
						barCount++;

				//if a box is formed, then claim the box
				if (barCount == 4) {
					setSquare(isTakingSquare, player, row, col);
					squareFormed = true;
				}
			}
			
		} 
		
		//check for a vertically placed bar
		else {
			//check to left
			if (col > 0) {
				int barCount = 1;
				//check for a bar above
				if (Hlines[row][col-1])
					barCount++;
				
				//check for a bar below
				if (Hlines[row+1][col-1])
					barCount++;
				
				//check for a bar to left
				if (Vlines[row][col-1])
					barCount++;
				
				//if a box is formed, then claim the box
				if (barCount == 4) {
					setSquare(isTakingSquare, player, row, col-1);
					squareFormed = true;
				}
			}
			
			
			//check to right
			if (col < columns) {
				int barCount = 1;
				//check for a bar above
				if (Hlines[row][col])
					barCount++;
				
				//check for a bar below
				if (Hlines[row+1][col])
					barCount++;
				
				//check for a bar to right
				if (Vlines[row][col+1])
					barCount++;
				
				//if a box is formed, then claim the box
				if (barCount == 4) {
					setSquare(isTakingSquare, player, row, col);
					squareFormed = true;
				}
			}
		}
		
		return squareFormed;
	}
	
	
	
	
	/**
	 * @description sets the square to whatever the user requests
	 * @param isTakingSquare true if the square is being taken, false if it is being reset to blank
	 * @param player the player (setting)/(who set) the square
	 * @param row the row of the square wrt the owner matrix
	 * @param col the column of the square wrt the owner matrix
	 */
	private void setSquare(boolean isTakingSquare, BoxValues player, int row, int col) {
		if (isTakingSquare) {
			Owner[row][col] = player;
			
			if (player == BoxValues.C) {
				this.computerBoxes++;
			} else if (player == BoxValues.H) {
				this.humanBoxes++;
			}
		}
		
		else {
			Owner[row][col] = BoxValues.b;
		
			if (player == BoxValues.C) {
				this.computerBoxes--;
			} else if (player == BoxValues.H) {
				this.humanBoxes--;
			}
		}
		
	}
	
	
	
	
	/**
	 * @description prints the layout of the board
	 * @param numTabs how many tabs to the right the board should be printed
	 */
	public void printBoard (int numTabs) {
		for (int r = 1; r <= rows*2 + 1; r++) {
			//print the tabs
			for (int t = 0; t < numTabs; t++) {
				System.out.print("\t");
			}
			
			//print the board row (even)
			if (r%2 != 0) {
				for (int c = 0; c < columns; c++) {
					if (Hlines[(r-1)/2][c])
						System.out.print(".-");
					else
						System.out.print(".b");
				}
				System.out.print(".");
			} 
			
			//print the board row (odd)
			else {
				for (int c = 1; c <= columns*2 + 1; c++) {
					if (c%2 != 0) {
						if (Vlines[(r-1)/2][(c-1)/2])
							System.out.print("|");
						else
							System.out.print("b");
					} else {
						System.out.print(Owner[(r-1)/2][(c-1)/2]);
					}
				}
				
			}

			System.out.println();
		}
	}
}
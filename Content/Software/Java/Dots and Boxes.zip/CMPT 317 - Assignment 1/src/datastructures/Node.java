package datastructures;

import java.util.LinkedList;

/**
 * 
 * @author adam knox
 * CMPT 317
 * Assignment 1
 *
 * a node in a tree. stores a board configuration
 */
public class Node {
	public Board board;					//the stored board
	
    private Node parent;				//the parent node of this node
    private LinkedList<Node> children;	//the list of child nodes immediately under this node

    /**
     * @description creates a new node
     * @param parent the parent of the new node
     */
    public Node(Node parent) {
        this.children = new LinkedList<Node>();
        this.parent = parent;
    }
    
    /**
     * @description adds the given node as a child to this node
     * @param child the node to add as a child
     */
    public void newChild(Node child) {
    	children.add(child);
    }
    
    /**
     * 
     * @param index the index of the child to get
     * @return the child with the given index
     */
    public Node child(int index) {
    	return children.get(index);
    }
    
    /**
     * 
     * @return the number of children this node has
     */
    public int numChildren () {
    	return children.size();
    }
    
    /**
     * 
     * @return the parent of this node
     */
    public Node parent() {
    	return parent;
    }
    
    /**
     * @description removes all the children from the current node
     */
    public void removeChildren() {
    	children = null;
    }
}
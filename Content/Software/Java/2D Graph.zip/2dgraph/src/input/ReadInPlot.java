package input;

/**
 * @description reads a project file into the container Graph
 */
import java.awt.Color;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileReader;

import plotInstance.GraphData;
import enumerations.RGB;
import enumerations.RegTypes;
//used for unit tests
import container.DataPoint;
import output.SavePlot;

public class ReadInPlot {

	/**
	 * @description gets the data from the file, and places it in the Graph
	 * @param file
	 *            name of the file
	 * @return true if successful exception if not
	 * @author Adam Knox
	 */
	public static boolean Read(String file) {
		FileInputStream fileStream;
		DataInputStream dataInStream;
		String line;

		// clear out all the old graph data
		GraphData.get().resetGraph();

		try {
			// Open the file and prepare it for reading
			fileStream = new FileInputStream(file);
			BufferedReader inbuf = new BufferedReader(new FileReader(file));

			// create a data input stream to read from
			dataInStream = new DataInputStream(fileStream);

			// read each line
			int numLines = 0;
			while ((line = inbuf.readLine()) != null) {
				// check if this is the start of a set of data line data
				if (line.equals("START OF DATALINE")) {
					// make sure a line is added if there are more than one
					numLines++;
					if (numLines > 1)
						GraphData.get().addNewLine();

					// read in the data for the data line
					String var = "";
					String data = "";
					while (((line = inbuf.readLine()) != null) && !(line.equals("END OF DATALINE"))) {
						// set the current variable being operated on
						String[] stringSet = line.split("_#2DGrapher#_");
						var = stringSet[0].toString();

						// get the current variables data
						if (stringSet.length == 2)
							data = stringSet[1].toString();

						// store the line data in the structure
						if (var.equals("lineName")) {
							String lineName = "";
							while (((line = inbuf.readLine()) != null) && !(line.equals("endLineName_#2DGrapher#_"))) {
								// add each internal line to the string
								lineName += line + "\n";
							}
							// remove the new line character
							lineName = lineName.substring(0, lineName.length() - 1);
							// store the string in the data structure
							GraphData.get().getLine(numLines - 1).setName(lineName);

						} else if (var.equals("regString")) {
							String regString = "";
							while (((line = inbuf.readLine()) != null) && !(line.equals("endRegString_#2DGrapher#_"))) {
								// add each internal line to the string
								regString += line + "\n";
							}
							// remove the new line character
							regString = regString.substring(0, regString.length() - 1);
							// store the string in the data structure
							GraphData.get().getLine(numLines - 1).setRegString(regString);

						} else if (var.equals("points")) {
							// split strings so there is one for each point
							String[] points = data.split("[}][)][ ][(]");

							// remove the '}) ' from the last item
							if (points[points.length - 1].length() - 3 >= 0)
								points[points.length - 1] = points[points.length - 1].substring(0, points[points.length - 1].length() - 3);

							// remove the '(' from the first item
							if (points[0].length() >= 1) {
									points[0] = points[0].substring(1);

									// parse each point into its x, eastError,
									// westError, y, northError, and southError
									// components

									for (int i = 0; i < points.length; i++) {
									// split into x and y components
									String[] xyComponents = points[i].split("[}][,]");

									// split x into x point and x error points
									String[] xcomponent = xyComponents[0].split("[,][{]");
									// split y into y point and y error points
									String[] ycomponent = xyComponents[1].split("[,][{]");

									// split x error bars
									String[] xErrorBars = xcomponent[1].split("[,]");
									// split y error bars
									String[] yErrorBars = ycomponent[1].split("[,]");

									// Put the point into the structure
									GraphData.get().insertPointSequential(numLines-1, Double.parseDouble(xcomponent[0]), Double.parseDouble(ycomponent[0]),
											Double.parseDouble(xErrorBars[0]), Double.parseDouble(xErrorBars[1]), Double.parseDouble(yErrorBars[0]),
											Double.parseDouble(yErrorBars[1]));
								}
							}

						} else if (var.equals("regData")) {
							// split strings so there is one for each regression
							// type
							String[] regDataList = data.split("[}][,][ ]");

							// get the indices of each item since for some
							// reason they are output in a random order
							Integer[] num = new Integer[5];
							num[RegTypes.power.ordinal()] = getRegTypeIndex(RegTypes.power, regDataList);
							num[RegTypes.logarithmic.ordinal()] = getRegTypeIndex(RegTypes.logarithmic, regDataList);
							num[RegTypes.linear.ordinal()] = getRegTypeIndex(RegTypes.linear, regDataList);
							num[RegTypes.polynomial.ordinal()] = getRegTypeIndex(RegTypes.polynomial, regDataList);
							num[RegTypes.exponential.ordinal()] = getRegTypeIndex(RegTypes.exponential, regDataList);

							// parse the string into the lists of values
							for (int i = 0; i < 5; i++) {
								// remove the } from the last item
								if (num[i] == 4) {
									regDataList[num[i]] = regDataList[num[i]].substring(0, regDataList[num[i]].length() - 2);

									// remove the '{' from the first item
								} else if (num[i] == 0) {
									regDataList[num[i]] = regDataList[num[i]].substring(1);
								}

								// remove the NAME= from each regression type
								regDataList[num[i]] = regDataList[num[i]].substring(regDataList[num[i]].indexOf("{") + 1);

								// check if anything is in each item, if there
								// is, then split it, and store it
								if (!regDataList[num[i]].equals("")) {
									// split the string and put it in a
									// temporary string array
									String[] itemList = regDataList[num[i]].split(", ");

									// store each item
									for (int j = 0; j < itemList.length; j++) {
										// split the item into its name and
										// value components
										String[] components = itemList[j].split("=");

										// put the data into the appropriate
										// structure
										if (components[1].equals("null")) {
											GraphData.get().getLine(numLines - 1).addRegDataItem(RegTypes.fromOrdinal(i), components[0], 0);
										} else {
											GraphData.get().getLine(numLines - 1)
													.addRegDataItem(RegTypes.fromOrdinal(i), components[0], Double.parseDouble(components[1]));
										}
									}
								}
							}

						} else if (var.equals("regDisplayedData")) {
							// split strings so there is one for each regression
							// type
							String[] regDisplayList = data.split("], ");

							// get the indices of each item since for some
							// reason they are output in a random order
							Integer[] num = new Integer[5];
							num[RegTypes.power.ordinal()] = getRegTypeIndex(RegTypes.power, regDisplayList);
							num[RegTypes.logarithmic.ordinal()] = getRegTypeIndex(RegTypes.logarithmic, regDisplayList);
							num[RegTypes.linear.ordinal()] = getRegTypeIndex(RegTypes.linear, regDisplayList);
							num[RegTypes.polynomial.ordinal()] = getRegTypeIndex(RegTypes.polynomial, regDisplayList);
							num[RegTypes.exponential.ordinal()] = getRegTypeIndex(RegTypes.exponential, regDisplayList);

							// parse the string into the lists of items
							for (int i = 0; i < 5; i++) {
								// remove the } from the last item
								if (num[i] == 4) {
									regDisplayList[num[i]] = regDisplayList[num[i]].substring(0, regDisplayList[num[i]].length() - 2);

									// remove the '{' from the first item
								} else if (num[i] == 0) {
									regDisplayList[num[i]] = regDisplayList[num[i]].substring(1);
								}

								// remove the NAME= from each regression type
								regDisplayList[num[i]] = regDisplayList[num[i]].substring(regDisplayList[num[i]].indexOf("[") + 1);

								// check if anything is in each item, if there
								// is, then split it, and store it
								if (!regDisplayList[num[i]].equals("")) {
									// split the string and put it in a
									// temporary string array
									String[] itemList = regDisplayList[num[i]].split(", ");

									// store each item
									for (int j = 0; j < itemList.length; j++) {
										GraphData.get().getLine(numLines-1).setDisplayedRegItem(RegTypes.fromOrdinal(i), itemList[j]);
									}
								}
							}

						} else if (var.equals("lineThickness")) {
							GraphData.get().getLine(numLines - 1).setLineThickness(Integer.parseInt(data));
						} else if (var.equals("pointThickness")) {
							GraphData.get().getLine(numLines - 1).setPointThickness(Integer.parseInt(data));
						} else if (var.equals("errorBarThickness")) {
							GraphData.get().getLine(numLines - 1).setErrorBarThickness(Integer.parseInt(data));
						} else if (var.equals("lineVisible")) {
							GraphData.get().getLine(numLines - 1).setLineVisible(Boolean.parseBoolean(data));
						} else if (var.equals("xErrorVisible")) {
							GraphData.get().getLine(numLines - 1).setXErrorVisible(Boolean.parseBoolean(data));
						} else if (var.equals("yErrorVisible")) {
							GraphData.get().getLine(numLines - 1).setYErrorVisible(Boolean.parseBoolean(data));
						} else if (var.equals("pointVisible")) {
							GraphData.get().getLine(numLines - 1).setPointVisible(Boolean.parseBoolean(data));
						} else if (var.equals("pointColor")) {
							GraphData.get().getLine(numLines - 1)
									.setPointColor(parseColor(data, RGB.red), parseColor(data, RGB.green), parseColor(data, RGB.blue));
						} else if (var.equals("lineColor")) {
							GraphData.get().getLine(numLines - 1)
									.setLineColor(parseColor(data, RGB.red), parseColor(data, RGB.green), parseColor(data, RGB.blue));
						} else if (var.equals("errorBarColor")) {
							GraphData.get().getLine(numLines - 1)
							.setErrorBarColor(parseColor(data, RGB.red), parseColor(data, RGB.green), parseColor(data, RGB.blue));
						}
					}

					// check if this is the start of the main graph data
				} else if (line.equals("GENERAL GRAPH DATA")) {
					String var = "";
					String data = "";
					// read in the general graph data
					while (((line = inbuf.readLine()) != null) && !(line.equals("END OF GENERAL GRAPH DATA"))) {
						// set the current variable being operated on
						String[] stringSet = line.split("_#2DGrapher#_");
						var = stringSet[0].toString();

						// get the current variables data
						if (stringSet.length == 2)
							data = stringSet[1].toString();

						// store the graph data in the structure
						if (data != null) {
							if (var.equals("name")) {
								GraphData.get().setName(data.toString());
							} else if (var.equals("scaleX")) {
								GraphData.get().setScaleX(Integer.parseInt(data));
							} else if (var.equals("scaleY")) {
								GraphData.get().setScaleY(Integer.parseInt(data));
							} else if (var.equals("xFormat")) {
								GraphData.get().setXFormat(data.toString());
							} else if (var.equals("yFormat")) {
								GraphData.get().setYFormat(data.toString());
							} else if (var.equals("regFormat")) {
								GraphData.get().setRegFormat(data.toString());
							} else if (var.equals("xName")) {
								GraphData.get().setXName(data.toString());
							} else if (var.equals("yName")) {
								GraphData.get().setYName(data.toString());
							} else if (var.equals("hPadding")) {
								GraphData.get().setHPadding(Double.parseDouble(data.toString()));
							}
						}
					}
				}
			}
			// no more data, so close the stream
			dataInStream.close();

			// make sure the plot is redrawn with the new data
			GraphData.get().refresh();

			// no error occurred, and the data is in, so notify of success
			return true;

			// there was an error reading in the file
		} catch (Exception e) {
			System.err.println("File input error");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @description gets the index for the regression type data since they are
	 *              shown in random order
	 * @param regType
	 *            the type of regression to get the index for
	 * @param data
	 *            the string array of unordered regression data
	 * @return the index in the array for the given regression type
	 * @author Adam Knox
	 */
	private static int getRegTypeIndex(RegTypes regType, String[] data) {
		for (int i = 0; i < data.length; i++) {
			if (data[i].contains(regType.toString()))
				return i;
		}

		return -1;
	}

	/**
	 * @description convert Color.toString() text to the rgb components
	 * @param in
	 *            Color.toString() text
	 * @param rgb
	 *            RGB.red, RGB.green, or RGB.blue; whose value you want returned
	 * @return the integer color value for the specified color
	 * @author Adam Knox
	 */
	public static int parseColor(String in, RGB rgb) {
		// convert toString value to R, G, and B values
		in = in.substring(15);
		String[] rgbList = in.split(",");

		// get the requested item
		if (rgb == RGB.red) {
			return Integer.parseInt(rgbList[0].substring(2));
		} else if (rgb == RGB.green) {
			return Integer.parseInt(rgbList[1].substring(2));
		} else if (rgb == RGB.blue) {
			return Integer.parseInt(rgbList[2].substring(2, rgbList[2].length() - 1));
		}

		return -1;
	}

	/**
	 * @description test function
	 * @param args
	 * @author Adam Knox
	 */
	public static void main(String[] args) {
		String initialPlot;
		String finalPlot;

		// create plot
		// add some points
		GraphData.get().getLine(0).addPointOrdered(new DataPoint(3, 4, 1, 2, 3, 4));
		GraphData.get().getLine(0).addPointOrdered(new DataPoint(5, 3, 4, 3, 2, 1.5));
		GraphData.get().getLine(0).addPointOrdered(new DataPoint(3, 6, 4.4, 3.3, 2.2, 1.1));
		// run regressions
		GraphData.get().runRegression(0, RegTypes.linear);
		GraphData.get().runRegression(0, RegTypes.exponential);
		// set regression displayed data
		GraphData.get().getLine(0).setDisplayedRegItem(RegTypes.power, "stdev");
		GraphData.get().getLine(0).setDisplayedRegItem(RegTypes.power, "R^2");
		// change some colours
		GraphData.get().getLine(0).setPointColor(Color.red);
		GraphData.get().getLine(0).setLineColor(Color.green);
		GraphData.get().getLine(0).setErrorBarColor(Color.gray);

		// save to file
		initialPlot = GraphData.get().toString();
		SavePlot.savePlot(null, "ReadInPlotTest");
		System.out.println(initialPlot);

		// clear plot
		GraphData.get().resetGraph();

		// reopen plot
		ReadInPlot.Read("ReadInPlotTest");
		finalPlot = GraphData.get().toString();

		// look at the second data structure. doing an automated comparison
		// would be very time consuming because the
		// toString methods appear to display HashMap items in random order
		System.out.println("\n===================================================================================\n");
		System.out.println(finalPlot);
	}
}
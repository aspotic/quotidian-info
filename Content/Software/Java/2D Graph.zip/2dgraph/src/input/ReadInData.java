package input;

/**
 * @description reads data from a file that is placed into an existing data line
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import plotInstance.GraphData;

public class ReadInData {
	/**
	 * @description process every line of the project file
	 * @param delim
	 *            the delimiter used for finding columns
	 * @param xCol
	 *            the column containing the x values
	 * @param yCol
	 *            the column containing the y values
	 * @param xColErrL
	 *            the column containing the left error bar values
	 * @param xColErrR
	 *            the column containing the right error bar values
	 * @param yColErrT
	 *            the column containing the top error bar values
	 * @param yColErrB
	 *            the column containing the bottom error bar values
	 * @throws FileNotFoundException
	 * @author Amara
	 */
	public static void processLineByLine(File fFile, int lineIndex, String delim, int xCol,
			int yCol, int xColErrL, int xColErrR, int yColErrT, int yColErrB)
			throws FileNotFoundException {
		// Note that FileReader is used, not File, since File is not Closeable
		Scanner scanner = new Scanner(new FileReader(fFile));
		try {
			// first use a Scanner to get each line
			while (scanner.hasNextLine()) {
				processLine(lineIndex, scanner.nextLine(), delim, xCol, yCol,
						xColErrL, xColErrR, yColErrT, yColErrB);
			}
		} finally {
			// ensure the underlying stream is always closed
			// this only has any effect if the item passed to the Scanner
			// constructor implements Closeable (which it does in this case).
			scanner.close();
		}
	}

	/**
	 * @description process every line of the project file
	 * @param delim
	 *            the delimiter used for finding columns
	 * @param xCol
	 *            the column containing the values
	 * @param binSize
	 *            the range of values to put in a given bin
	 * @param binStartValue
	 *            the smallest point that will be put in the bins
	 * @throws FileNotFoundException
	 * @author Amara
	 */
	public static void processLineByLine(File fFile, int lineIndex, String delim, int xCol,
			int binSize, int binStartValue) throws FileNotFoundException {
		// Note that FileReader is used, not File, since File is not Closeable
		Scanner scanner = new Scanner(new FileReader(fFile));
		try {
			// create a linked list to store the data for analysis
			LinkedList<Double> data = new LinkedList<Double>();
			HashMap<Double, Integer> bins = new HashMap<Double, Integer>();

			// first use a Scanner to get each line
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine().trim();
				// use a second Scanner to parse the content of each line
				Scanner scanner2 = new Scanner(line);
				scanner2.useDelimiter(delim);

				// get the item from the row
				int i = 1;
				try {
					while (scanner2.hasNext()) {
						String val = scanner2.next();
						if (i == xCol) {
							try {
								data.add(Double.parseDouble(val));
							} catch (NumberFormatException e) {/*
																 * couldn't find
																 * a proper
																 * value
																 */
							}
						}
						i++;
					}
				} finally {
					scanner2.close();
				}
			}

			// sort the list
			Collections.sort(data);

			// find the smallest item
			int smallestNumLocation = 0;
			while (data.get(smallestNumLocation) < binStartValue) {
				smallestNumLocation++;
			}

			// setup the bins
			int numBins = 1;
			double curBinTop;
			double curBinBottom;
			double curBinMid;

			for (int i = smallestNumLocation; i < data.size();) {
				// set the current bin
				curBinTop = binSize * numBins + binStartValue;
				curBinBottom = curBinTop - binSize;
				curBinMid = (curBinTop - curBinBottom) / 2 + curBinBottom;

				// put the values in the bins
				bins.put(curBinMid, 0);
				while ((i < data.size()) && (data.get(i) < curBinTop)) {
					bins.put(curBinMid, (bins.get(curBinMid) + 1));
					i++;
				}
				numBins++;
			}

			// put the values in the plot
			for (int i = 0; i < bins.size(); i++) {
				double key = (double) (binStartValue + (binSize * (1 + 2 * i) / 2));
				GraphData.get().insertPointOrdered(lineIndex, key,
						bins.get(key), -1, -1, -1, -1);
			}

		} finally {
			// close the scanner
			scanner.close();
		}
	}

	/**
	 * @description processes the given data file line
	 * @param aLine
	 *            the line to process
	 * @param delim
	 *            the delimiter used for finding columns
	 * @param xCol
	 *            the column containing the x values
	 * @param yCol
	 *            the column containing the y values
	 * @param xColErrL
	 *            the column containing the left error bar values
	 * @param xColErrR
	 *            the column containing the right error bar values
	 * @param yColErrT
	 *            the column containing the top error bar values
	 * @param yColErrB
	 *            the column containing the bottom error bar values
	 * @author Adam Knox
	 */
	private static void processLine(int lineIndex, String aLine, String delim,
			int xCol, int yCol, int xColErrL, int xColErrR, int yColErrT,
			int yColErrB) {
		// use a second Scanner to parse the content of each line
		Scanner scanner = new Scanner(aLine);

		// This delimiter will be input by the user.
		scanner.useDelimiter(delim);

		// setup parsing variables
		boolean fail = false;
		int column = 1;
		double x = 0;
		double xErrL = 0;
		double xErrR = 0;
		double y = 0;
		double yErrT = 0;
		double yErrB = 0;

		// find the largest column used
		int largestColumn = Math.max(
				Math.max(xCol, yCol),
				Math.max(Math.max(xColErrL, xColErrR),
						Math.max(yColErrT, yColErrB)));
		// run the line parse
		while ((scanner.hasNext()) && (column <= largestColumn)) {
			// store the current scanner value
			String scannerVal = scanner.next().trim();

			// read in x
			if (column == xCol) {
				try {
					x = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					fail = true;
				}
			}

			// read in y
			if (column == yCol) {
				try {
					y = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					fail = true;
				}
			}

			// read in left x error
			if (column == xColErrL) {
				try {
					xErrL = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					xErrL = -1;
				}
			}

			// read in right x error
			if (column == xColErrR) {
				try {
					xErrR = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					xErrR = -1;
				}
			}

			// read in top y error
			if (column == yColErrT) {
				try {
					yErrT = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					yErrT = -1;
				}
			}

			// read in bottom y error
			if (column == yColErrB) {
				try {
					yErrB = Double.parseDouble(scannerVal);
				} catch (NumberFormatException e) {
					yErrB = -1;
				}
			}

			// note which column is being read next
			column++;
		}

		// put the discovered point into the structure
		if ((column > 1) && (!fail)) {
			GraphData.get().insertPointOrdered(lineIndex, x, y, xErrL, xErrR,
					yErrT, yErrB);
		}
	}
}

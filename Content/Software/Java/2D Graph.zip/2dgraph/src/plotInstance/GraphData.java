package plotInstance;

/**
 * @description this class contains a singleton Graph, and the functions needed to directly access it
 */
import container.Graph;

public class GraphData {
	// the instance of graph created
	private static final Graph INSTANCE = new Graph();

	/**
	 * @description gets the singleton item of type Graph
	 * @return the singleton item of type Graph
	 * @author Adam Knox
	 */
	public static Graph get() {
		return INSTANCE;
	}

	public static void main(String[] argv) {
		System.out.println(INSTANCE.toString());
	}

}
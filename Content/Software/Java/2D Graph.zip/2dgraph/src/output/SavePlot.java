package output;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import plotInstance.GraphData;

import enumerations.RegTypes;

/**
 * @description this class contains the functions needed to save a plot to a
 *              project file
 */
public class SavePlot {

	/**
	 * @description Outputs ie saves graph to file filename.
	 * @param filename
	 *            name of the file to save to
	 * @param graph
	 *            the graph to save
	 * @return true if successful
	 * @throws FileNotFoundException
	 * @author Amara
	 */
	public static void savePlot(File filePath, String filename) {
		// setup variables
		filename += ".2dg";
		FileOutputStream Output;
		PrintStream file;

		// attempt to create an output stream, and write the project data to
		// file
		try {
			Output = new FileOutputStream(filePath + "/" + filename);
			file = new PrintStream(Output);

			file.println(GraphData.get().toString());

			// if the write fails, then notify the user
		} catch (Exception e) {
			//System.out.println("Could not write file");
		}
	}

	/**
	 * @param args
	 * @author Amara
	 */
	public static void main(String[] args) {
		/*
		 * Testing with various inputs
		 */
		GraphData.get().insertPointSequential(0, 1, 2);
		GraphData.get().insertPointSequential(0, 1.5, 4);
		GraphData.get().insertPointSequential(0, 2, 6);
		GraphData.get().insertPointSequential(0, 2.5, 8);
		GraphData.get().insertPointSequential(0, 3, 10);
		GraphData.get().runRegression(0, RegTypes.linear);
		GraphData.get().runRegression(0, RegTypes.exponential);
		GraphData.get().runRegression(0, RegTypes.logarithmic);
		GraphData.get().runRegression(0, RegTypes.power);
		GraphData.get().runRegression(0, RegTypes.polynomial, 3);
		savePlot(null, "SavePlotTestResults");
	}
}

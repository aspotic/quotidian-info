package output;

/**
 * @description This class creates functionality to save a jpanel as an image file at a custom resolution
 */
import java.io.*;
import java.awt.*;

import javax.swing.*;
import javax.imageio.*;

import java.awt.image.*;

public class ExportPlot {
	/**
	 * @description saves a panel as an image
	 * @param plot
	 *            the panel to save
	 * @param name
	 *            the name to use to save the panel as (imge name)
	 * @param extension
	 *            the format to save the image in (png, jpg, ...)
	 * @param width
	 *            the width in pixels of the new image
	 * @param plotHeight
	 *            the height in pixels of the new image
	 * @author Adam Knox
	 */
	public static void exportPlot(JPanel plot, JPanel regData, JPanel legend,
			File folder, String name, String extension, int widthPlot,
			int widthReg, int legendHeight, int plotHeight) {
		// resize the panel to the requested dimensions
		plot.setPreferredSize(new Dimension(widthPlot, plotHeight));
		legend.setPreferredSize(new Dimension(widthPlot, legendHeight));
		regData.setPreferredSize(new Dimension(widthReg, plotHeight
				+ legendHeight));

		// create left Panel
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
		leftPanel.setPreferredSize(new Dimension(widthPlot, plotHeight
				+ legendHeight));
		leftPanel.add(plot);
		leftPanel.add(legend);

		// create master panel
		JPanel masterPanel = new JPanel();
		masterPanel.setLayout(new BoxLayout(masterPanel, BoxLayout.X_AXIS));
		masterPanel.setPreferredSize(new Dimension(widthReg + widthPlot,
				plotHeight + legendHeight));
		masterPanel.add(leftPanel);
		masterPanel.add(regData);

		// setup a JFrame to put the panel in, but run it in the background
		JFrame frame = new JFrame();
		frame.getContentPane().add(masterPanel);
		frame.pack();
		frame.setSize(widthReg + widthPlot, plotHeight + legendHeight);
		frame.setVisible(false);

		// create the image using the master panel
		BufferedImage image = new BufferedImage(widthReg + widthPlot,
				plotHeight + legendHeight, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = image.createGraphics();
		masterPanel.paint(g2);
		g2.dispose();

		// save the image to file
		try {
			ImageIO.write(image, extension, new File(folder + "/" + name + "."
					+ extension));
			// save failed, so notify user
		} catch (IOException ioe) {
			//System.out.println(ioe.getMessage());
		}
	}

	/**
	 * @description tests ExportPlot
	 * @param args
	 * @author Adam Knox
	 */
	public static void main(String[] args) {
		final JPanel panel1 = new JPanel();
		panel1.setBackground(Color.blue);
		panel1.add(new JLabel("This is a panel to save"));
		panel1.setSize(new Dimension(500, 500));
		panel1.setMinimumSize(new Dimension(500, 500));

		final JPanel panel2 = new JPanel();
		panel2.setBackground(Color.green);
		panel2.add(new JLabel("This is a second panel to save"));
		panel2.setSize(new Dimension(250, 700));
		panel2.setMinimumSize(new Dimension(250, 700));

		final JPanel panel3 = new JPanel();
		panel3.setBackground(Color.red);
		panel3.add(new JLabel("This is a third panel to save"));
		panel3.setSize(new Dimension(500, 200));
		panel3.setMinimumSize(new Dimension(500, 200));

		exportPlot(panel1, panel2, panel3, new File(
				"/Volumes/DATA/Documents/ARCHIVE/workspace/2dgraph"),
				"testimage2", "png", 500, 250, 200, 500);

		return;
	}
}

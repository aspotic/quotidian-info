import plotInstance.GraphData;

/**
 * @description Starts the program
 * @author Adam Knox
 */
public class run {
	public static void main(String[] args) {
		// display the main in window
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				GUI.MainWindow.createAndShowGUI(); // get the gui going
				GUI.MainWindow.createGraphPanel(); // make sure the window is
													// maked
				GraphData.get().resetGraph(); // set up default graph values
				GraphData.get().refresh(); // ensure the plot is shown with the
											// new values
			}
		});
	}
}

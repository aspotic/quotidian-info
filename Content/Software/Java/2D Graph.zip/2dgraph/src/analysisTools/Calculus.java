package analysisTools;

import java.util.HashMap;

import enumerations.RegTypes;

//used in unit tests
import container.DataPoint;
import container.DataSet;
import plotInstance.GraphData;

public class Calculus {
	/**
	 * @author Adam Knox
	 * @description finds the area under the regression fit
	 * @param regType
	 *            the type of regression the analysis is being done on
	 * @param coefficients
	 *            the function coefficients for this regression (with names
	 *            power, B0, B1, B2, ... for polynomial; B0, B1 for linear; and
	 *            A, B for other types)
	 * @param a
	 *            the starting limit for the integral
	 * @param b
	 *            the ending limit for the integral
	 * @return the area under the plot within the limits [a, b]
	 */
	public static Double Integral(RegTypes regType,
			HashMap<String, Double> coef, double a, double b) {
		/*** make sure to take care of special cases where A or B = 0 ***/
		/* do the proper calculation based on what equation type is being used */
		switch (regType) {
		// y = A*e^(B*x)
		case exponential:
			return ((coef.get("A") / coef.get("B")) * (Math.exp(Math.abs(coef
					.get("B") * b)) - Math.exp(Math.abs(coef.get("B") * a))));

			// y = A + B*ln|x|
		case logarithmic:
			return ((coef.get("A") * (b - a)) + (coef.get("B") * ((b * Math
					.log(b)) - (a * Math.log(a)) + a - b)));

			// y = A*x^B
		case power:
			return ((coef.get("A") / (coef.get("B") + 1)) * (Math.pow(b,
					(coef.get("B") + 1)) - Math.pow(a, (coef.get("B") + 1))));

			// y = B0 + B1*x
		case linear:
			return (coef.get("B0") * (b - a) + 0.5 * coef.get("B1")
					* ((b * b) - (a * a)));

			// y = B0 + B1*x + B2*x^2 + ... + Bn*x^n
		case polynomial:
			double result = 0.0;

			// get the value of each power, and add it to the total
			for (int i = 0; i <= coef.get("power").intValue(); i++) {
				result += ((coef.get("B" + i) / (i + 1)) * (Math
						.pow(b, (i + 1)) - Math.pow(a, (i + 1))));
			}

			return result;

			// a proper regression was not selected, so nothing can be done
		default:
			return null;
		}
	}

	/**
	 * @author Adam Knox
	 * @description finds change of the function at the given position
	 * @param regType
	 *            the type of regression the analysis is being done on
	 * @param coefficients
	 *            the function coefficients for this regression (with names B0,
	 *            B1, B2, ... for polynomial and linear; and with names A, B for
	 *            other types)
	 * @param p
	 *            the point at which to find the change in y
	 * @return the acceleration of y at point p
	 */
	public static Double Derivative(RegTypes regType,
			HashMap<String, Double> coef, double x) {
		/* do the proper calculation based on what equation type is being used */
		switch (regType) {
		// y = A*e^(B*x)
		case exponential:
			return (coef.get("A") * coef.get("B") * Math.exp(x * coef.get("B")));

			// y = A + B*ln|x|
		case logarithmic:
			return (coef.get("B") / x);

			// y = A*x^B
		case power:
			return (coef.get("A") * coef.get("B") * Math.pow(x,
					(coef.get("B") - 1)));

			// y = B0 + B1*x
		case linear:
			return coef.get("B1");

			// y = B0 + B1*x + B2*x^2 + ... + Bn*x^n
		case polynomial:
			double result = 0.0;

			// get the value of each power, and add it to the total
			for (int i = 1; i <= coef.get("power").intValue(); i++) {
				result += (i * coef.get("B" + i) * Math.pow(x, (i - 1)));
			}

			return result;

		default:
			return null;
		}
	}

	/**
	 * @author Adam Knox
	 * @description finds the rate of change of the function at the given
	 *              position
	 * @param regType
	 *            the type of regression the analysis is being done on
	 * @param coefficients
	 *            the function coefficients for this regression (with names B0,
	 *            B1, B2, ... for polynomial and linear; and with names A, B for
	 *            other types)
	 * @param p
	 *            the point at which to find the rate of change in y
	 * @return the acceleration of y at point p
	 */
	public static Double SecondDerivative(RegTypes regType,
			HashMap<String, Double> coef, double x) {
		/* do the proper calculation based on what equation type is being used */
		switch (regType) {
		// y = A*e^(B*x)
		case exponential:
			return (coef.get("A") * coef.get("B") * coef.get("B") * Math.exp(x
					* coef.get("B")));

			// y = A + B*ln|x|
		case logarithmic:
			return (-1 * (coef.get("B") / (x * x)));

			// y = A*x^B
		case power:
			return (coef.get("A") * coef.get("B") * (coef.get("B") - 1) * Math
					.pow(x, (coef.get("B") - 2)));

			// y = B0 + B1*x
		case linear:
			return 0.0;

			// y = B0 + B1*x + B2*x^2 + ... + Bn*x^n
		case polynomial:
			double result = 0.0;

			// get the value of each power, and add it to the total
			for (int i = 2; i <= coef.get("power").intValue(); i++) {
				result += ((i - 1) * i * coef.get("B" + i) * Math.pow(x,
						(i - 2)));
			}

			return result;

		default:
			return null;
		}
	}

	/**
	 * @author Adam Knox
	 * @description tests the functionality of the class
	 */
	public static void main(String[] args) {
		// /////////////////////////////////////////////////////////////////
		// //////////////// test model y = 4*x - 2 /////////////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("test model y = 4*x - 2\n");
		// Create temporary DataPoints
		DataSet datal = new DataSet();

		// add points
		datal.addPointOrdered(new DataPoint(1, 2));
		datal.addPointOrdered(new DataPoint(1.5, 4));
		datal.addPointOrdered(new DataPoint(2, 6));
		datal.addPointOrdered(new DataPoint(2.5, 8));
		datal.addPointOrdered(new DataPoint(3, 10));
		datal.addPointOrdered(new DataPoint(3.5, 12));
		datal.addPointOrdered(new DataPoint(4, 14));
		datal.addPointOrdered(new DataPoint(4.5, 16));
		datal.addPointOrdered(new DataPoint(5, 18));
		datal.addPointOrdered(new DataPoint(5.5, 20));

		// //////////////////Linear Regression Test////////////////////////
		HashMap<String, Double> reg;
		reg = Regression.Linear(datal);
		System.out.println("Linear Regression: y = ("
				+ GraphData.get().getXFormatted(reg.get("B1")) + "x) + ("
				+ GraphData.get().getXFormatted(reg.get("B0")) + ")");
		System.out.println("Integral on [1, 5.5]: "
				+ GraphData.get().getXFormatted(
						Calculus.Integral(RegTypes.linear, reg, 1, 5.5)));
		System.out.println("Derivative at 3: "
				+ GraphData.get().getXFormatted(
						Calculus.Derivative(RegTypes.linear, reg, 3)));
		System.out.println("Second Derivative at 4.5: "
				+ GraphData.get().getXFormatted(
						Calculus.SecondDerivative(RegTypes.linear, reg, 4.5)));
		System.out.println();

		// ////////////////Polynomial Regression Test//////////////////////
		reg = Regression.Polynomial(datal, 3);
		System.out.println("Polynomial Regression: y = ("
				+ GraphData.get().getXFormatted(reg.get("B3")) + "x^3) + ("
				+ GraphData.get().getXFormatted(reg.get("B2")) + "x^2) + ("
				+ GraphData.get().getXFormatted(reg.get("B1")) + "x) + ("
				+ GraphData.get().getXFormatted(reg.get("B0")) + ")");
		System.out.println("Integral on [1, 5.5]: "
				+ GraphData.get().getXFormatted(
						Calculus.Integral(RegTypes.polynomial, reg, 1, 5.5)));
		System.out.println("Derivative at 3: "
				+ GraphData.get().getXFormatted(
						Calculus.Derivative(RegTypes.polynomial, reg, 3)));
		System.out.println("Second Derivative at 4.5: "
				+ GraphData.get()
						.getXFormatted(
								Calculus.SecondDerivative(RegTypes.polynomial,
										reg, 4.5)));
		System.out.println();

		// ////////////////Power Regression Test//////////////////////
		reg = Regression.Power(datal);
		System.out.println("Power Regression: y = ("
				+ GraphData.get().getXFormatted(reg.get("A")) + ")*x^("
				+ GraphData.get().getXFormatted(reg.get("B")) + ")");
		System.out.println("Integral on [1, 5.5]: "
				+ GraphData.get().getXFormatted(
						Calculus.Integral(RegTypes.power, reg, 1, 5.5)));
		System.out.println("Derivative at 3: "
				+ GraphData.get().getXFormatted(
						Calculus.Derivative(RegTypes.power, reg, 3)));
		System.out.println("Second Derivative at 4.5: "
				+ GraphData.get().getXFormatted(
						Calculus.SecondDerivative(RegTypes.power, reg, 4.5)));
		System.out.println();

		// ////////////////Logarithmic Regression Test//////////////////////
		reg = Regression.Logarithmic(datal);
		System.out.println("Logarithmic Regression: y = "
				+ GraphData.get().getXFormatted(reg.get("A")) + " + "
				+ GraphData.get().getXFormatted(reg.get("B")) + "*ln(x)");
		System.out.println("Integral on [1, 5.5]: "
				+ GraphData.get().getXFormatted(
						Calculus.Integral(RegTypes.logarithmic, reg, 1, 5.5)));
		System.out.println("Derivative at 3: "
				+ GraphData.get().getXFormatted(
						Calculus.Derivative(RegTypes.logarithmic, reg, 3)));
		System.out.println("Second Derivative at 4.5: "
				+ GraphData.get().getXFormatted(
						Calculus.SecondDerivative(RegTypes.logarithmic, reg,
								4.5)));
		System.out.println();

		// ////////////////Exponential Regression Test//////////////////////
		reg = Regression.Exponential(datal);
		System.out.println("Exponential Regression: y = ("
				+ GraphData.get().getXFormatted(reg.get("A")) + ")*exp("
				+ GraphData.get().getXFormatted(reg.get("B")) + "*x)");
		System.out.println("Integral on [1, 5.5]: "
				+ GraphData.get().getXFormatted(
						Calculus.Integral(RegTypes.exponential, reg, 1, 5.5)));
		System.out.println("Derivative at 3: "
				+ GraphData.get().getXFormatted(
						Calculus.Derivative(RegTypes.exponential, reg, 3)));
		System.out.println("Second Derivative at 4.5: "
				+ GraphData.get().getXFormatted(
						Calculus.SecondDerivative(RegTypes.exponential, reg,
								4.5)));
		System.out.println();
	}
}

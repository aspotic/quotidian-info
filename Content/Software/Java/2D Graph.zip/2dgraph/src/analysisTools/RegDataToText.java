package analysisTools;

import java.util.HashMap;
import java.util.LinkedList;

import plotInstance.GraphData;
import enumerations.RegTypes;

public class RegDataToText {
	/**
	 * @description updates the displayed string for the specific regression
	 *              type.
	 * @param regType
	 * @param displayValues
	 * @param regData
	 * @author Adam Knox
	 */
	public static String findRegString(int lineNumber, RegTypes regType) {
		LinkedList<String> displayValues = GraphData.get().getLine(lineNumber)
				.getRegDisplayData(regType);
		HashMap<String, Double> regData = GraphData.get().getLine(lineNumber)
				.getRegData(regType);

		// dont do anything if no regression type was given
		if (regType == null)
			return "";

		// if no values were given to put into the string, then clear the string
		if (displayValues == null || regData == null) {
			return "";
		}

		// if no values should be displayed, then make sure none are displayed
		if (displayValues.size() == 0) {
			return "";
		}

		// name the regression data
		String setString = regType.toString() + " regression\n";

		// place each requested item in the string

		for (int i = 0; i < displayValues.size(); i++) {
			if (displayValues.get(i).equals("equation")) {
				setString += "equation: " + getEquation(regType, regData)
						+ "\n";
			} else if (displayValues.get(i).equals("integral")) {
				setString += displayValues.get(i)
						+ " on ["
						+ GraphData.get().getRegFormatted(
								regData.get("integral A"))
						+ ", "
						+ GraphData.get().getRegFormatted(
								regData.get("integral B"))
						+ "]: "
						+ GraphData.get().getRegFormatted(
								regData.get(displayValues.get(i))) + "\n";
			} else if (displayValues.get(i).equals("derivative")) {
				setString += displayValues.get(i)
						+ " at ["
						+ GraphData.get().getRegFormatted(
								regData.get("derivative A"))
						+ "]: "
						+ GraphData.get().getRegFormatted(
								regData.get(displayValues.get(i))) + "\n";
			} else if (displayValues.get(i).equals("second derivative")) {
				setString += displayValues.get(i)
						+ " at ["
						+ GraphData.get().getRegFormatted(
								regData.get("second derivative A"))
						+ "]: "
						+ GraphData.get().getRegFormatted(
								regData.get(displayValues.get(i))) + "\n";
			} else {
				setString += displayValues.get(i)
						+ ": "
						+ GraphData.get().getRegFormatted(
								regData.get(displayValues.get(i))) + "\n";
			}
		}

		return setString;
	}

	/**
	 * @description creates a string that contains a regression equation using
	 *              the associated coefficients
	 * @param regType
	 * @param regData
	 * @return returns the properly getRegFormatted equation
	 * @author Adam Knox
	 */
	private static String getEquation(RegTypes regType,
			HashMap<String, Double> regData) {

		// Linear Regression Equation
		if (regType == RegTypes.linear)
			return ("y = (" + GraphData.get().getRegFormatted(regData.get("B1"))
					+ "x) + ("
					+ GraphData.get().getRegFormatted(regData.get("B0")) + ")");

		// Polynomial Regression
		if (regType == RegTypes.polynomial) {
			String retString = "";

			if (regData.get("power") > 0) {
				retString += ("y = ("
						+ GraphData.get().getRegFormatted(regData.get("B0"))
						+ ") + ("
						+ GraphData.get().getRegFormatted(regData.get("B1")) + "x)");
			} else {
				retString += ("y = " + GraphData.get().getRegFormatted(
						regData.get("B0")));
			}

			for (int i = 2; i <= regData.get("power"); i++) {
				retString += " + ("
						+ GraphData.get().getRegFormatted(regData.get("B" + i))
						+ "x^" + i + ")";
			}

			return retString;
		}

		// Test Power Regression
		if (regType == RegTypes.power)
			return ("y = (" + GraphData.get().getRegFormatted(regData.get("A"))
					+ ")*x^(" + GraphData.get().getRegFormatted(regData.get("B")) + ")");

		// Test Logarithmic Regression
		if (regType == RegTypes.logarithmic)
			return ("y = " + GraphData.get().getRegFormatted(regData.get("A"))
					+ " + " + GraphData.get().getRegFormatted(regData.get("B")) + "*ln(x)");

		// Test Exponential Regression
		if (regType == RegTypes.exponential)
			return ("y = (" + GraphData.get().getRegFormatted(regData.get("A"))
					+ ")*exp("
					+ GraphData.get().getRegFormatted(regData.get("B")) + "*x)");

		// can't handle this regression type
		return null;
	}

	/**
	 * @description tests the Text class
	 * @param argv
	 * @return 0 for success, 1 for failure
	 * @author Adam Knox
	 */
	public static void main(String[] args) {
		/*
		 * //setup TextInstance //create regression structure DataLine data =
		 * new DataLine();
		 * 
		 * //create data points data.addPoint(new DataPoint(1, 2));
		 * data.addPoint(new DataPoint(1.5, 4)); data.addPoint(new DataPoint(2,
		 * 6)); data.addPoint(new DataPoint(2.5, 8)); data.addPoint(new
		 * DataPoint(3, 10)); data.addPoint(new DataPoint(3.5, 12));
		 * data.addPoint(new DataPoint(4, 14)); data.addPoint(new DataPoint(4.5,
		 * 16)); data.addPoint(new DataPoint(5, 18)); data.addPoint(new
		 * DataPoint(5.5, 20));
		 * 
		 * //create comparison list LinkedList<String> outputParams = new
		 * LinkedList<String> (); outputParams.add("equation");
		 * outputParams.add("var"); outputParams.add("stdev");
		 * outputParams.add("R^2"); outputParams.add("adj R^2");
		 * 
		 * //set strings TextInstance.updateRegString(RegTypes.linear,
		 * outputParams, Regression.Linear(data));
		 * TextInstance.updateRegString(RegTypes.polynomial, outputParams,
		 * Regression.Polynomial(data, 4));
		 * TextInstance.updateRegString(RegTypes.power, outputParams,
		 * Regression.Power(data));
		 * TextInstance.updateRegString(RegTypes.exponential, outputParams,
		 * Regression.Exponential(data));
		 * TextInstance.updateRegString(RegTypes.logarithmic, outputParams,
		 * Regression.Logarithmic(data));
		 * 
		 * 
		 * TextInstance.updateRegString(RegTypes.power, null,
		 * Regression.Power(data));
		 * 
		 * LinkedList<String> outputParams2 = new LinkedList<String> ();
		 * outputParams2.add("equation"); outputParams2.add("stdev");
		 * outputParams2.add("R^2"); outputParams2.add("adj R^2");
		 * 
		 * 
		 * TextInstance.updateRegString(RegTypes.linear, outputParams2,
		 * Regression.Linear(data));
		 * 
		 * 
		 * //display TextInstance System.out.println(TextInstance.toString());
		 */

	}
}

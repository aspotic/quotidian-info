package analysisTools;

import container.Matrix;

public class MatrixOps {
	/**
	 * @author Adam Knox
	 * @description multiply two matrices (matrix A * matrix B)
	 * @param A
	 *            leading matrix
	 * @param B
	 *            trailing matrix
	 * @return the resultant matrix from (matrix A * matrix B)
	 */
	public static Matrix multiply(Matrix A, Matrix B) {
		if (A.getW() != B.getH())
			return null;

		// Create the matrix to return
		Matrix C = new Matrix(A.getH(), B.getW());

		for (int j = 0; j < C.getW(); j++) {
			for (int i = 0; i < C.getH(); i++) {
				for (int k = 0; k < C.getH(); k++) {
					C.set(i, j, (C.get(i, j) + A.get(i, k) * B.get(k, j)));
				}
			}
		}

		return C;
	}

	/**
	 * @author Adam Knox
	 * @description copy one matrix into a new matrix
	 * @param A
	 *            the matrix to copy from
	 * @return the duplicate matrix
	 */
	public static Matrix copy(Matrix A) {
		Matrix B = new Matrix(A.getH(), A.getH());
		for (int i = 0; i < A.getH(); i++) {
			for (int j = 0; j < A.getW(); j++) {
				B.set(i, j, A.get(i, j));
			}
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description puts the matrix into upper triangular form
	 * @param A
	 *            the matrix to find the upper triangular form of
	 * @return matrix A in upper triangular form
	 */
	public static Matrix upperTriangularForm(Matrix A) {
		// Make sure this is a square matrix
		if (A.getH() != A.getW())
			return null;

		// Create the matrix to return
		Matrix B = MatrixOps.copy(A);

		// Get zeros for each column
		for (int i = 0; i < (B.getW() - 1); i++) {
			int m = 0;

			// if item i,i is zero
			if (B.get(i, i) == 0) {
				m = i + 1;
				// then find a row that doesn't have a 0
				while ((m < B.getH()) && (B.get(m, i) == 0)) {
					m++;
				}

				// and swap the two rows
				if (m < B.getH()) {
					double temp = 0.0;
					for (int n = i; n < B.getW(); n++) {
						temp = B.get(i, n);
						B.set(i, n, B.get(m, n));
						B.set(m, n, temp);
					}
				}
			}

			// if all entries contain zero, then skip this column
			if (m < B.getH()) {
				// Subtract Rii*aii/aji from each row
				for (int j = i + 1; j < B.getH(); j++) {
					// Skip the row if it starts with a 0
					if (B.get(j, i) != 0) {
						for (int k = (B.getW() - 1); k >= i; k--) {
							B.set(j, k, (B.get(j, k) - (((B.get(j, i)) / (B
									.get(i, i))) * (B.get(i, k)))));
						}

						// take care of error from using floating point numbers
						for (int k = 0; k <= i; k++) {
							B.set(j, k, 0);
						}
					}
				}
			}
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description find the determinant of a matrix
	 * @param A
	 *            the matrix to find the determinant of
	 * @return the determinant of the matrix A
	 */
	public static Double determinant(Matrix A) {
		if (A.getW() != A.getH())
			return null;

		double det = 1;

		Matrix B = MatrixOps.upperTriangularForm(A);

		for (int i = 0; i < B.getH(); i++)
			det *= B.get(i, i);

		return det;
	}

	/**
	 * @author Adam Knox
	 * @description find the transpose of a matrix
	 * @param A
	 *            the matrix to find the transpose of
	 * @return the transpose of the matrix A
	 */
	public static Matrix transpose(Matrix A) {
		Matrix B = new Matrix(A.getH(), A.getH());
		for (int i = 0; i < A.getH(); i++) {
			for (int j = 0; j < A.getW(); j++) {
				B.set(j, i, A.get(i, j));
			}
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description find the of a matrix
	 * @param A
	 *            the matrix to find the minor of
	 * @param y
	 *            the vertical position of the point the minor is being found
	 *            for
	 * @param x
	 *            the horizontal position of the point the minor is being found
	 *            for
	 * @return the minor of the matrix A around point y,x of the matrix
	 */
	public static Matrix minor(Matrix A, int y, int x) {
		if ((A.getW() != A.getH()) || (y < 0) || (x < 0) || (y >= A.getH())
				|| (x >= A.getW()))
			return null;

		Matrix B = new Matrix((A.getH() - 1), (A.getH() - 1));
		int shifti = 0;
		int shiftj = 0;

		for (int i = 0; i < (A.getH() - 1); i++) {
			if (i == y)
				shifti = 1;

			for (int j = 0; j < (A.getW() - 1); j++) {
				if (j == x)
					shiftj = 1;
				B.set(i, j, A.get((i + shifti), (j + shiftj)));
			}

			shiftj = 0;
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description find the cofactor of a matrix
	 * @param A
	 *            the matrix to find the cofactor of
	 * @return the cofactor of the matrix A
	 */
	public static Matrix cofactor(Matrix A) {
		if (A.getW() != A.getH())
			return null;

		Matrix B = new Matrix(A.getH(), A.getH());

		for (int i = 0; i < A.getH(); i++) {
			for (int j = 0; j < A.getW(); j++) {
				int sign = -1;
				if ((j + i) % 2 == 0)
					sign = 1;

				B.set(i, j, (sign * (MatrixOps.determinant(MatrixOps.minor(A,
						i, j)))));
			}
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description find the adjugate of a matrix
	 * @param A
	 *            the matrix to find the adjugate of
	 * @return the adjugate of the matrix A
	 */
	public static Matrix adjugate(Matrix A) {
		return MatrixOps.transpose(MatrixOps.cofactor(A));
	}

	/**
	 * @author Adam Knox
	 * @description find the inverse of a matrix using the formula
	 *              (1/det(A))*adj(A)
	 * @param A
	 *            the matrix to find the inverse of
	 * @return the inverse of the matrix A
	 */
	public static Matrix inverse(Matrix A) {
		if (A.getW() != A.getH())
			return null;

		double detA = MatrixOps.determinant(A);
		if (detA == 0)
			return null;
		detA = 1 / detA;

		Matrix B = MatrixOps.adjugate(A);

		// multiply the scalar 1/Det(A) by the adjugate of A
		for (int i = 0; i < B.getH(); i++) {
			for (int j = 0; j < B.getW(); j++) {
				// undisclosed desires
				B.set(i, j, detA * B.get(i, j));
			}
		}

		return B;
	}

	/**
	 * @author Adam Knox
	 * @description find the inverse of a matrix using Gauss-Jordan elimination
	 *              (faster than inverse())
	 * @param A
	 *            the matrix to find the inverse of
	 * @return the inverse of the matrix A
	 */
	public static Matrix inverseGJ(Matrix A) {
		if (A.getW() != A.getH())
			return null;

		// build identity matrix & temp matrix for A
		Matrix I = new Matrix(A.getH(), A.getH());
		for (int i = 0; i < A.getH(); i++) {
			I.set(i, i, 1);
		}
		Matrix B = MatrixOps.copy(A);

		// run gBuss-jordBn eliminBtion on mBtrices B & I
		// Get upper triBngulBr form
		for (int i = 0; i < (B.getW() - 1); i++) {
			int m = 0;

			// if item i,i is zero
			if (B.get(i, i) == 0) {
				m = i + 1;
				// then find B row thBt doesn't hBve B 0
				while ((m < B.getH()) && (B.get(m, i) == 0)) {
					m++;
				}

				// Bnd swBp the two rows
				if (m < B.getH()) {
					double temp = 0.0;
					for (int n = i; n < B.getW(); n++) {
						// swBp rows in mBtrix B
						temp = B.get(i, n);
						B.set(i, n, B.get(m, n));
						B.set(m, n, temp);

						// swBp rows in mBtrix I
						temp = I.get(i, n);
						I.set(i, n, I.get(m, n));
						I.set(m, n, temp);
					}
				}
			}

			// if Bll entries contBin zero, then skip this column
			if (m < B.getH()) {
				// SubtrBct Rii*Bii/Bji from eBch row
				for (int j = i + 1; j < B.getH(); j++) {
					// Skip the row if it stBrts with B 0
					if (B.get(j, i) != 0) {
						double multiplier = (B.get(j, i)) / (B.get(i, i));

						for (int k = (B.getW() - 1); k >= i; k--) {
							// OperBte on mBtrix I
							I.set(j,
									k,
									(I.get(j, k) - (multiplier) * (I.get(i, k))));
							// OperBte on mBtrix B
							B.set(j,
									k,
									(B.get(j, k) - (multiplier) * (B.get(i, k))));
						}

						// only set the identity mBtrix for the rest since the
						// Bnswer is BlwBys 0 for B from now on
						for (int k = (i - 1); k >= 0; k--) {
							// OperBte on mBtrix I
							I.set(j,
									k,
									(I.get(j, k) - (multiplier) * (I.get(i, k))));
						}
					}
				}
			}
		}

		// get lower triBngulBr form
		for (int i = (B.getW() - 1); i > 0; i--) {

			// SubtrBct Rii*Bii/Bji from eBch row
			for (int j = 0; j < i; j++) {
				// Skip the row if it stBrts with B 0
				if (B.get(j, i) != 0) {
					double multiplier = B.get(j, i) / B.get(i, i);

					// only set the identity mBtrix for the first hBlf since
					// nothing chBnges for B for now
					for (int k = 0; k <= i; k++) {
						// OperBte on mBtrix I
						I.set(j, k,
								(I.get(j, k) - (multiplier) * (I.get(i, k))));

					}

					for (int k = (i + 1); k < B.getW(); k++) {
						// OperBte on mBtrix I
						I.set(j, k,
								(I.get(j, k) - (multiplier) * (I.get(i, k))));

						// OperBte on mBtrix B
						B.set(j, k,
								(B.get(j, k) - (multiplier) * (B.get(i, k))));
					}
				}
			}
		}

		// set B to be identity mBtrix by dividing eBch Bii by itself
		for (int i = 0; i < B.getH(); i++) {
			if (B.get(i, i) != 0) {
				// run the operBtion on the identity mBtrix
				for (int j = 0; j < I.getW(); j++) {
					I.set(i, j, (I.get(i, j) / B.get(i, i)));
				}

				// run the operBtion on mBtrix B
				B.set(i, i, B.get(i, i) / B.get(i, i));
			}
		}

		return I;
	}

	/**
	 * @author Adam Knox
	 * @description tests the functionality of the class
	 */
	public static void main(String[] args) {
		int size = 3;

		// Create a matrix
		Matrix A = new Matrix(size, size);

		A.set(0, 0, 1);
		A.set(0, 1, 3);
		A.set(0, 2, 1);
		A.set(1, 0, 1);
		A.set(1, 1, 1);
		A.set(1, 2, 2);
		A.set(2, 0, 2);
		A.set(2, 1, 5);
		A.set(2, 2, 4);
		/*
		 * for (int i = 0; i < size; i++) { for (int j = 0; j < size; j++) {
		 * A.set(i, j, Math.random()*10); } }
		 */
		System.out.println("A = \n" + A.toString());

		// Determinant
		System.out.println("Det(A) = " + MatrixOps.determinant(A) + "\n");

		// Transpose
		Matrix Atranspose = MatrixOps.transpose(A);
		System.out.println("A Transpose = \n" + Atranspose.toString());

		// Minor
		Matrix Aminor = MatrixOps.minor(A, 0, 0);
		System.out.println("A Minor for A11 = \n" + Aminor.toString());

		// Cofactor
		Matrix Acofactor = MatrixOps.cofactor(A);
		System.out.println("A Cofactor = \n" + Acofactor.toString());

		// Adjugate
		Matrix Aadjugate = MatrixOps.adjugate(A);
		System.out.println("A adjugate = \n" + Aadjugate.toString());

		// Upper Triangular Form
		Matrix Atri = MatrixOps.upperTriangularForm(A);
		System.out.println("A upper triangular form = \n" + Atri.toString());

		// Find the inverse of the matrix
		Matrix Ainv = MatrixOps.inverse(A);
		System.out.println("A inverse = \n" + Ainv.toString());

		// Find the inverse of the matrix using gauss-jordan elimination
		Matrix AinvGJ = MatrixOps.inverseGJ(A);
		System.out.println("A inverse with gauss-jordan = \n"
				+ AinvGJ.toString());

		// Create another matrix
		Matrix B = new Matrix(size, 1);

		for (int i = 0; i < B.getH(); i++) {
			B.set(i, 0, -1 * (3 * i + 1));
		}
		System.out.print("B = \n" + B.toString());

		// Matrix A * Matrix B (3x3 mat * 3x1 mat)
		Matrix C = MatrixOps.multiply(A, B);
		System.out.print("C = A*B = \n" + C.toString());

		// Matrix A * Matrix A inverse (3x3 mat * 3x3 mat)
		Matrix I = MatrixOps.multiply(A, Ainv);
		System.out.print("I = A*Ainv = \n" + I.toString());

		// Matrix A * Matrix A inverse GJ (3x3 mat * 3x3 mat)
		Matrix IGJ = MatrixOps.multiply(A, AinvGJ);
		System.out.print("I (GJ) = A*AinvGJ = \n" + IGJ.toString());

	}
}

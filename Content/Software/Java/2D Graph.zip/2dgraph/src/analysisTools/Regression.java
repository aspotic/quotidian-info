package analysisTools;

import java.lang.Math;
import java.util.HashMap;

import container.DataSet;
import container.DataPoint;
import container.Matrix;
import enumerations.RegTypes;
//used in unit tests
import plotInstance.GraphData;

public class Regression {
	/**
	 * @author Adam Knox
	 * @param regType
	 *            the type of regression to perform
	 * @param data
	 *            the data to perform the regression on
	 * @param power
	 *            the polynomial power, only used for polynomial regression
	 * @return
	 */
	public static HashMap<String, Double> Run(RegTypes regType, DataSet data, int power) {
		if (regType.equals(RegTypes.linear)) {
			return Linear(data);

		} else if (regType.equals(RegTypes.polynomial)) {
			return Polynomial(data, power);

		} else if (regType.equals(RegTypes.exponential)) {
			return Exponential(data);

		} else if (regType.equals(RegTypes.logarithmic)) {
			return Logarithmic(data);

		} else if (regType.equals(RegTypes.power)) {
			return Power(data);

		}

		return null;
	}

	/**
	 * @author Adam Knox
	 * @param regType
	 *            the type of regression to perform
	 * @param data
	 *            the data to perform the regression on
	 * @return
	 */
	public static HashMap<String, Double> Run(RegTypes regType, DataSet data) {
		if (regType.equals(RegTypes.linear)) {
			return Linear(data);

		} else if (regType.equals(RegTypes.exponential)) {
			return Exponential(data);

		} else if (regType.equals(RegTypes.logarithmic)) {
			return Logarithmic(data);

		} else if (regType.equals(RegTypes.power)) {
			return Power(data);

		}

		return null;
	}

	/**
	 * @author Adam Knox
	 * @description find the mean of the y values in the data set
	 * @return mean of y values from the data set
	 */
	public static double mean(DataSet data) {
		int n = 0;
		double cY;
		double yAvg = 0.0;
		double sumOfY = 0.0;

		// Start traversing the list from the top of it
		for (int i = 0; i < data.size(); i++) {
			// get they value of the current DataPoint
			cY = data.get(i).getY();
			// Calculate sum of x values
			sumOfY += cY;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		return yAvg;
	}

	/**
	 * @author Adam Knox
	 * @description does a linear regression fit for y = B0 + B1*x on the data
	 *              set, and finds the variance, standard deviation, coefficient
	 *              of determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains B0, B1, var, stdev, R^2,
	 *         and adv R^2
	 */
	public static HashMap<String, Double> Linear(DataSet data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double B0;
		double B1;

		double SSe; // Residual Sum of Squares

		double variance; // variance
		double stdev; // standard deviation

		double Rsquared; // Coefficient of Determination
		double adjRsquared = 0; // Adjusted Coefficient of Determination

		int n = 0;
		int p = 1;
		double Sxx = 0;
		double Sxy = 0;
		double SSt = 0;
		double yAvg = 0;
		double xAvg = 0;
		double sumOfY = 0;
		double sumOfX = 0;

		// Start traversing the list from the top of it
		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get they value of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// Calculate sum of x and y values
			sumOfY += cY;
			sumOfX += cX;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y and x values
		yAvg = sumOfY / n;
		xAvg = sumOfX / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate Sxx, which is the sum of (xi - xAvg)(xi - xAvg)
			Sxx += (cX - xAvg) * (cX - xAvg);

			// Calculate Sxy, which is the sum of (xi - xAvg)(yi - yAvg)
			Sxy += (cX - xAvg) * (cY - yAvg);

			// Calculate SSt
			SSt += (cY - yAvg) * (cY - yAvg);
		}

		// Calculate Regression Coefficients
		B1 = Sxy / Sxx;
		B0 = yAvg - B1 * xAvg;

		// Calculate Residual Sum of Squares (SSe) & Regression Sum of Squares
		// (SSr)
		SSe = 0;
		// SSr = 0;
		for (int i = 0; i < data.size(); i++) {
			double yHat;

			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate yHat for this DataPoint
			yHat = B0 + B1 * cX;

			// Calculate SSe
			SSe += (cY - yHat) * (cY - yHat);
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		retStruct.put("B0", B0);
		retStruct.put("B1", B1);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);
		retStruct.put("power", 1.0);

		// Return the string
		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a polynomial regression fit for y=B0 + B1*x + B2*x^2 +
	 *              ... on the data set, and finds the variance, standard
	 *              deviation, coefficient of determination, and adjusted
	 *              coefficient of determination
	 * @param int power; the order of the polynomial
	 * @return HashMap<String, Double> that contains B0, B1, B2, ..., var,
	 *         stdev, R^2, and adv R^2
	 */
	public static HashMap<String, Double> Polynomial(DataSet data, int power) {
		power++;

		double cX;
		double cY;

		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = power - 1;
		
		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();

			// Calculate sum of x and y values
			sumOfY += cY;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate SSt
			SSt += (cY - yAvg) * (cY - yAvg);
		}

		// Create map
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		// Create matrices
		Matrix multiples = new Matrix((2 * power), 1);
		Matrix Bvalues = new Matrix(power, 1);
		Matrix equalsMatrix = new Matrix(power, 1);
		Matrix systemMatrix = new Matrix(power, power);

		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Populate the matrix that contains what the system is equal to &
			// the first half of the multiples matrix
			for (int j = 0; j < power; j++) {
				multiples.set(j, 0, (multiples.get(j, 0) + Math.pow(cX, j)));
				equalsMatrix.set(j, 0, (equalsMatrix.get(j, 0) + cY * Math.pow(cX, j)));
			}

			// Populate the rest of the multiples
			for (int j = power; j < (power * 2); j++) {
				multiples.set(j, 0, (multiples.get(j, 0) + Math.pow(cX, j)));
			}
		}

		// Set up the system of equations
		for (int i = 0; i < power; i++) {
			for (int j = 0; j < power; j++) {
				systemMatrix.set(i, j, multiples.get((i + j), 0));
			}
		}

		// Get the result matrix
		Bvalues = MatrixOps.multiply(MatrixOps.inverseGJ(systemMatrix), equalsMatrix);

		// Calculate Residual Sum of Squares (SSe) & Regression Sum of Squares
		// (SSr)
		for (int i = 0; i < data.size(); i++) {
			double yHat;

			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate yHat for this DataPoint
			yHat = 0;
			for (int j = 0; j < Bvalues.getH(); j++) {
				yHat += Bvalues.get(j, 0) * Math.pow(cX, j);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// put coefficients and error results in return struct
		for (int i = 0; i < power; i++) {
			retStruct.put("B" + i, Bvalues.get(i, 0));
		}
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);
		retStruct.put("power", (double) (power - 1));

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a power regression fit for y=A*x^B on the data set, and
	 *              finds the variance, standard deviation, coefficient of
	 *              determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Power(DataSet data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat;

		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOflnX = 0;
		double sumOflnY = 0;
		double sumOflnXlnY = 0;
		double sumOflnXlnX = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate sum of x and y values
				sumOfY += cY;
				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate SSt
				SSt += (cY - yAvg) * (cY - yAvg);
				sumOflnX += Math.log(cX);
				sumOflnY += Math.log(cY);
				sumOflnXlnY += Math.log(cX) * Math.log(cY);
				sumOflnXlnX += Math.log(cX) * Math.log(cX);
			}
		}

		// calculate the coefficients
		b = (n * sumOflnXlnY - sumOflnX * sumOflnY) / (n * sumOflnXlnX - sumOflnX * sumOflnX);
		a = (sumOflnY - (b * sumOflnX)) / n;

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate yHat for this DataPoint
				yHat = Math.exp(a) * Math.pow(cX, b);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A*x^B; B=b, A=e^a

		retStruct.put("A", Math.exp(a));
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a logarithmic regression fit for y=A + B*ln(x) on the
	 *              data set, and finds the variance, standard deviation,
	 *              coefficient of determination, and adjusted coefficient of
	 *              determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Logarithmic(DataSet data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat = 0;
		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOflnX = 0;
		double sumOflnXy = 0;
		double sumOflnXlnX = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if (cX != 0) {
				// Calculate sum of x and y values
				sumOfY += cY;

				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if (cX != 0) {
				SSt += (cY - yAvg) * (cY - yAvg);
				sumOflnX += Math.log(cX);
				sumOflnXlnX += Math.log(cX) * Math.log(cX);
				sumOflnXy += Math.log(cX) * cY;
			}
		}

		// calculate the coefficients
		b = (n * sumOflnXy - sumOflnX * sumOfY) / (n * sumOflnXlnX - sumOflnX * sumOflnX);
		a = (sumOfY - (b * sumOflnX)) / n;

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if (cX != 0) {
				// Calculate yHat for this DataPoint
				yHat = a + b * Math.log(cX);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A + B*ln(x); A = a; B = b
		retStruct.put("A", a);
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a power regression fit for y=A*e^(Bx) on the data set,
	 *              and finds the variance, standard deviation, coefficient of
	 *              determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Exponential(DataSet data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat = 0;
		double SSe = 0;
		double variance = 0;
		double stdev = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOfxy = 0;
		double sumOfxylnY = 0;
		double sumOflnYy = 0;
		double sumOfxxy = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate sum of x and y values
				sumOfY += cY;

				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Start traversing the list from the top of it
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate SSt
				SSt += (cY - yAvg) * (cY - yAvg);

				sumOfxy += cX * cY;
				sumOfxylnY += cX * cY * Math.log(cY);
				sumOflnYy += cY * Math.log(cY);
				sumOfxxy += cX * cX * cY;
			}
		}

		// calculate the coefficients
		a = (sumOfxxy * sumOflnYy - sumOfxy * sumOfxylnY) / (sumOfY * sumOfxxy - sumOfxy * sumOfxy);
		b = (sumOfY * sumOfxylnY - sumOfxy * sumOflnYy) / (sumOfY * sumOfxxy - sumOfxy * sumOfxy);

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate yHat for this DataPoint
				yHat = Math.exp(a) * Math.exp(cX * b);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A*e^(B*x); A = exp(a); B = b
		retStruct.put("A", Math.exp(a));
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description tests the functionality of the class
	 */
	public static void main(String[] args) {
		// /////////////////////////////////////////////////////////////////
		// //////////////// test model y = 4*x - 2 /////////////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("test model y = 4*x - 2\n");
		// Create temporary DataPoints
		DataSet datal = new DataSet();

		// add points
		datal.addPointOrdered(new DataPoint(1, 2));
		datal.addPointOrdered(new DataPoint(1.5, 4));
		datal.addPointOrdered(new DataPoint(2, 6));
		datal.addPointOrdered(new DataPoint(2.5, 8));
		datal.addPointOrdered(new DataPoint(3, 10));
		datal.addPointOrdered(new DataPoint(3.5, 12));
		datal.addPointOrdered(new DataPoint(4, 14));
		datal.addPointOrdered(new DataPoint(4.5, 16));
		datal.addPointOrdered(new DataPoint(5, 18));
		datal.addPointOrdered(new DataPoint(5.5, 20));

		// Test Linear Regression
		HashMap<String, Double> linReg;
		linReg = Regression.Linear(datal);

		System.out.println("Linear Regression Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(linReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(linReg.get("B0"))
				+ ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(linReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(linReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(linReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(linReg.get("stdev")));
		System.out.println();

		// Test Polynomial Regression
		HashMap<String, Double> polReg;
		polReg = Regression.Polynomial(datal, 3);

		System.out.println("Polynomial Regression, power 3 Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(polReg.get("B3")) + "x^3) + (" + GraphData.get().getXFormatted(polReg.get("B2"))
				+ "x^2) + (" + GraphData.get().getXFormatted(polReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(polReg.get("B0")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(polReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(polReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(polReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(polReg.get("stdev")));
		System.out.println();

		// Test Power Regression
		HashMap<String, Double> powReg;
		powReg = Regression.Power(datal);

		System.out.println("Power Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(powReg.get("A")) + ")*x^(" + GraphData.get().getXFormatted(powReg.get("B")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(powReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(powReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(powReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(powReg.get("stdev")));
		System.out.println();

		// Test Logarithmic Regression
		HashMap<String, Double> logReg;
		logReg = Regression.Logarithmic(datal);

		System.out.println("Logarithmic Regression");
		System.out.println("y = " + GraphData.get().getXFormatted(logReg.get("A")) + " + " + GraphData.get().getXFormatted(logReg.get("B"))
				+ "*ln(x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(logReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(logReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(logReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(logReg.get("stdev")));
		System.out.println();

		// Test Exponential Regression
		HashMap<String, Double> expReg;
		expReg = Regression.Exponential(datal);

		System.out.println("Exponential Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(expReg.get("A")) + ")*exp(" + GraphData.get().getXFormatted(expReg.get("B"))
				+ "*x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(expReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(expReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(expReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(expReg.get("stdev")));
		System.out.println("\n\n");

		// /////////////////////////////////////////////////////////////////

		// /////////////////////////////////////////////////////////////////
		// /////////////// test model y = 3*x^2 + 2*x - 1 //////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("\n\ntest model y = 3*x^2 + 2*x - 1\n");
		// Create temporary DataPoints
		DataSet datap = new DataSet();

		// add points
		datap.addPointOrdered(new DataPoint(1, 4));
		datap.addPointOrdered(new DataPoint(1.5, 8.75));
		datap.addPointOrdered(new DataPoint(2, 15));
		datap.addPointOrdered(new DataPoint(2.5, 22.75));
		datap.addPointOrdered(new DataPoint(3, 32));
		datap.addPointOrdered(new DataPoint(3.5, 42.75));
		datap.addPointOrdered(new DataPoint(4, 55));
		datap.addPointOrdered(new DataPoint(4.5, 68.75));
		datap.addPointOrdered(new DataPoint(5, 84)); // 84
		datap.addPointOrdered(new DataPoint(5.5, 100.75));

		// Test Linear Regression
		linReg = Regression.Linear(datap);

		System.out.println("Linear Regression Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(linReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(linReg.get("B0"))
				+ ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(linReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(linReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(linReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(linReg.get("stdev")));
		System.out.println();

		// Test Polynomial Regression
		polReg = Regression.Polynomial(datap, 3);

		System.out.println("Polynomial Regression, power 3 Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(polReg.get("B3")) + "x^3) + (" + GraphData.get().getXFormatted(polReg.get("B2"))
				+ "x^2) + (" + GraphData.get().getXFormatted(polReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(polReg.get("B0")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(polReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(polReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(polReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(polReg.get("stdev")));
		System.out.println();

		// Test Power Regression
		powReg = Regression.Power(datap);

		System.out.println("Power Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(powReg.get("A")) + ")*x^(" + GraphData.get().getXFormatted(powReg.get("B")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(powReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(powReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(powReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(powReg.get("stdev")));
		System.out.println();

		// Test Logarithmic Regression
		logReg = Regression.Logarithmic(datap);

		System.out.println("Logarithmic Regression");
		System.out.println("y = " + GraphData.get().getXFormatted(logReg.get("A")) + " + " + GraphData.get().getXFormatted(logReg.get("B"))
				+ "*ln(x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(logReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(logReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(logReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(logReg.get("stdev")));
		System.out.println();

		// Test Exponential Regression
		expReg = Regression.Exponential(datap);

		System.out.println("Exponential Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(expReg.get("A")) + ")*exp(" + GraphData.get().getXFormatted(expReg.get("B"))
				+ "*x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(expReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(expReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(expReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(expReg.get("stdev")));
		System.out.println("\n\n");

		// /////////////////////////////////////////////////////////////////

		// /////////////////////////////////////////////////////////////////
		// /////////////// test model y = 5*x^3 //////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("\n\ntest model y = 5*x^3\n");
		// Create temporary DataPoints
		DataSet datapo = new DataSet();

		// add points
		datapo.addPointOrdered(new DataPoint(1, 5));
		datapo.addPointOrdered(new DataPoint(1.5, 16.88));
		datapo.addPointOrdered(new DataPoint(2, 40));
		datapo.addPointOrdered(new DataPoint(2.5, 78.13));
		datapo.addPointOrdered(new DataPoint(3, 135));
		datapo.addPointOrdered(new DataPoint(3.5, 214.38));
		datapo.addPointOrdered(new DataPoint(4, 320));
		datapo.addPointOrdered(new DataPoint(4.5, 455.63));
		datapo.addPointOrdered(new DataPoint(5, 625));
		datapo.addPointOrdered(new DataPoint(5.5, 831.88));

		// Test Linear Regression
		linReg = Regression.Linear(datapo);

		System.out.println("Linear Regression Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(linReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(linReg.get("B0"))
				+ ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(linReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(linReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(linReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(linReg.get("stdev")));
		System.out.println();

		// Test Polynomial Regression
		polReg = Regression.Polynomial(datapo, 3);

		System.out.println("Polynomial Regression, power 3 Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(polReg.get("B3")) + "x^3) + (" + GraphData.get().getXFormatted(polReg.get("B2"))
				+ "x^2) + (" + GraphData.get().getXFormatted(polReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(polReg.get("B0")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(polReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(polReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(polReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(polReg.get("stdev")));
		System.out.println();

		// Test Power Regression
		powReg = Regression.Power(datapo);

		System.out.println("Power Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(powReg.get("A")) + ")*x^(" + GraphData.get().getXFormatted(powReg.get("B")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(powReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(powReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(powReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(powReg.get("stdev")));
		System.out.println();

		// Test Logarithmic Regression
		logReg = Regression.Logarithmic(datapo);

		System.out.println("Logarithmic Regression");
		System.out.println("y = " + GraphData.get().getXFormatted(logReg.get("A")) + " + " + GraphData.get().getXFormatted(logReg.get("B"))
				+ "*ln(x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(logReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(logReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(logReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(logReg.get("stdev")));
		System.out.println();

		// Test Exponential Regression
		expReg = Regression.Exponential(datapo);

		System.out.println("Exponential Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(expReg.get("A")) + ")*exp(" + GraphData.get().getXFormatted(expReg.get("B"))
				+ "*x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(expReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(expReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(expReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(expReg.get("stdev")));
		System.out.println("\n\n");

		// /////////////////////////////////////////////////////////////////

		// /////////////////////////////////////////////////////////////////
		// /////////////// test model y = 4 + 5*ln(x) //////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("\n\ntest model y = 4 + 5*ln(x)\n");
		// Create temporary DataPoints
		DataSet datalo = new DataSet();

		// add points
		datalo.addPointOrdered(new DataPoint(1, 4));
		datalo.addPointOrdered(new DataPoint(1.5, 6.03));
		datalo.addPointOrdered(new DataPoint(2, 7.47));
		datalo.addPointOrdered(new DataPoint(2.5, 8.58));
		datalo.addPointOrdered(new DataPoint(3, 9.49));
		datalo.addPointOrdered(new DataPoint(3.5, 10.26));
		datalo.addPointOrdered(new DataPoint(4, 10.93));
		datalo.addPointOrdered(new DataPoint(4.5, 11.52));
		datalo.addPointOrdered(new DataPoint(5, 12.05));
		datalo.addPointOrdered(new DataPoint(5.5, 12.52));

		// Test Linear Regression
		linReg = Regression.Linear(datalo);

		System.out.println("Linear Regression Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(linReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(linReg.get("B0"))
				+ ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(linReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(linReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(linReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(linReg.get("stdev")));
		System.out.println();

		// Test Polynomial Regression
		polReg = Regression.Polynomial(datalo, 3);

		System.out.println("Polynomial Regression, power 3 Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(polReg.get("B3")) + "x^3) + (" + GraphData.get().getXFormatted(polReg.get("B2"))
				+ "x^2) + (" + GraphData.get().getXFormatted(polReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(polReg.get("B0")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(polReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(polReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(polReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(polReg.get("stdev")));
		System.out.println();

		// Test Power Regression
		powReg = Regression.Power(datalo);

		System.out.println("Power Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(powReg.get("A")) + ")*x^(" + GraphData.get().getXFormatted(powReg.get("B")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(powReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(powReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(powReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(powReg.get("stdev")));
		System.out.println();

		// Test Logarithmic Regression
		logReg = Regression.Logarithmic(datalo);

		System.out.println("Logarithmic Regression");
		System.out.println("y = " + GraphData.get().getXFormatted(logReg.get("A")) + " + " + GraphData.get().getXFormatted(logReg.get("B"))
				+ "*ln(x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(logReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(logReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(logReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(logReg.get("stdev")));
		System.out.println();

		// Test Exponential Regression
		expReg = Regression.Exponential(datalo);

		System.out.println("Exponential Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(expReg.get("A")) + ")*exp(" + GraphData.get().getXFormatted(expReg.get("B"))
				+ "*x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(expReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(expReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(expReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(expReg.get("stdev")));
		System.out.println("\n\n");

		// /////////////////////////////////////////////////////////////////

		// /////////////////////////////////////////////////////////////////
		// /////////////// test model y = 6*exp(0.15*x) //////////////////
		// /////////////////////////////////////////////////////////////////
		System.out.println("\n\ntest model y = 6*exp(0.15*x)\n");
		// Create temporary DataPoints
		DataSet datae = new DataSet();

		// add points
		datae.addPointOrdered(new DataPoint(1, 6.97));
		datae.addPointOrdered(new DataPoint(1.5, 7.51));
		datae.addPointOrdered(new DataPoint(2, 8.1));
		datae.addPointOrdered(new DataPoint(2.5, 8.73));
		datae.addPointOrdered(new DataPoint(3, 9.41));
		datae.addPointOrdered(new DataPoint(3.5, 10.14));
		datae.addPointOrdered(new DataPoint(4, 10.93));
		datae.addPointOrdered(new DataPoint(4.5, 11.78));
		datae.addPointOrdered(new DataPoint(5, 12.7));
		datae.addPointOrdered(new DataPoint(5.5, 13.69));

		// Test Linear Regression
		linReg = Regression.Linear(datae);

		System.out.println("Linear Regression Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(linReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(linReg.get("B0"))
				+ ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(linReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(linReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(linReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(linReg.get("stdev")));
		System.out.println();

		// Test Polynomial Regression
		polReg = Regression.Polynomial(datae, 3);

		System.out.println("Polynomial Regression, power 3 Results");
		System.out.println("y = (" + GraphData.get().getXFormatted(polReg.get("B3")) + "x^3) + (" + GraphData.get().getXFormatted(polReg.get("B2"))
				+ "x^2) + (" + GraphData.get().getXFormatted(polReg.get("B1")) + "x) + (" + GraphData.get().getXFormatted(polReg.get("B0")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(polReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(polReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(polReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(polReg.get("stdev")));
		System.out.println();

		// Test Power Regression
		powReg = Regression.Power(datae);

		System.out.println("Power Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(powReg.get("A")) + ")*x^(" + GraphData.get().getXFormatted(powReg.get("B")) + ")");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(powReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(powReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(powReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(powReg.get("stdev")));
		System.out.println();

		// Test Logarithmic Regression
		logReg = Regression.Logarithmic(datae);

		System.out.println("Logarithmic Regression");
		System.out.println("y = " + GraphData.get().getXFormatted(logReg.get("A")) + " + " + GraphData.get().getXFormatted(logReg.get("B"))
				+ "*ln(x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(logReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(logReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(logReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(logReg.get("stdev")));
		System.out.println();

		// Test Exponential Regression
		expReg = Regression.Exponential(datae);

		System.out.println("Exponential Regression");
		System.out.println("y = (" + GraphData.get().getXFormatted(expReg.get("A")) + ")*exp(" + GraphData.get().getXFormatted(expReg.get("B"))
				+ "*x)");
		System.out.println("R^2 = " + GraphData.get().getXFormatted(expReg.get("R^2")));
		System.out.println("adjusted R^2 = " + GraphData.get().getXFormatted(expReg.get("adj R^2")));
		System.out.println("variance = " + GraphData.get().getXFormatted(expReg.get("var")));
		System.out.println("standard deviation = " + GraphData.get().getXFormatted(expReg.get("stdev")));
		System.out.println("\n\n");
	}
}
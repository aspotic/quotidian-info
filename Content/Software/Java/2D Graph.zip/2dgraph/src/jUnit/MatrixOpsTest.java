package jUnit;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import analysisTools.MatrixOps;

import container.Matrix;

/**
 * @author dwp726(integration with JUnit) ark043 (test cases) Testing the
 *         operations associated with matrices. Most of the functions return
 *         matrices, so expected outputs are associated with toString values.
 */
public class MatrixOpsTest {
	Matrix A, B;

	@Before
	public void setUp() throws Exception {
		int size = 3;

		// Create a matrix
		A = new Matrix(size, size);

		A.set(0, 0, 1);
		A.set(0, 1, 3);
		A.set(0, 2, 1);
		A.set(1, 0, 1);
		A.set(1, 1, 1);
		A.set(1, 2, 2);
		A.set(2, 0, 2);
		A.set(2, 1, 5);
		A.set(2, 2, 4);

		B = new Matrix(size, 1);

		for (int i = 0; i < B.getH(); i++) {
			B.set(i, 0, -1 * (3 * i + 1));
		}
	}

	@Test
	public void testMultiply() {
		assertEquals("-20.0 \n-19.0 \n-50.0 \n\n", MatrixOps.multiply(A, B).toString());

		// System.out.print("C = A*B = \n" + C.toString());
		/*
		 * C = A*B = -20.0 -19.0 -50.0
		 */
	}

	@Test
	public void testUpperTriangularForm() {
		// System.out.println("A upper triangular form = \n" + Atri.toString());
		assertEquals("1.0 3.0 1.0 \n0.0 -2.0 1.0 \n0.0 0.0 1.5 \n\n", MatrixOps.upperTriangularForm(A).toString());
		/*
		 * 1.0 3.0 1.0 0.0 -2.0 1.0 0.0 0.0 1.5
		 */
	}

	@Test
	public void testDeterminant() {
		assertEquals(MatrixOps.determinant(A).toString(), "-3.0");
	}

	@Test
	public void testTranspose() {
		assertEquals(("1.0 1.0 2.0 \n3.0 1.0 5.0 \n1.0 2.0 4.0 \n\n"), MatrixOps.transpose(A).toString());
		/*
		 * 1.0 1.0 2.0 3.0 1.0 5.0 1.0 2.0 4.0
		 */

	}

	@Test
	public void testMinor() {
		assertEquals("1.0 2.0 \n5.0 4.0 \n\n", MatrixOps.minor(A, 0, 0).toString());
		/*
		 * 1.0 2.0 5.0 4.0
		 */
	}

	@Test
	public void testCofactor() {
		assertEquals("-6.0 -0.0 3.0 \n-6.999999999999999 2.0 1.0 \n5.0 -1.0 -2.0 \n\n", MatrixOps.cofactor(A).toString());
		/*
		 * -6.0 -0.0 3.0 -6.999999999999999 2.0 1.0 5.0 -1.0 -2.0
		 */
	}

	@Test
	public void testAdjugate() {
		assertEquals("-6.0 -6.999999999999999 5.0 \n-0.0 2.0 -1.0 \n3.0 1.0 -2.0 \n\n", MatrixOps.adjugate(A).toString());
		/*
		 * -6.0 -6.999999999999999 5.0 -0.0 2.0 -1.0 3.0 1.0 -2.0
		 */
	}

	@Test
	public void testInverse() {
		assertEquals(
				"2.0 2.333333333333333 -1.6666666666666665 \n0.0 -0.6666666666666666 0.3333333333333333 \n-1.0 -0.3333333333333333 0.6666666666666666 \n\n",
				MatrixOps.inverse(A).toString());
		/*
		 * 2.0 2.333333333333333 -1.6666666666666665 0.0 -0.6666666666666666
		 * 0.3333333333333333 -1.0 -0.3333333333333333 0.6666666666666666
		 */
	}

	@Test
	public void testInverseGJ() {
		assertEquals(
				"2.0 2.3333333333333335 -1.6666666666666665 \n-0.0 -0.6666666666666666 0.3333333333333333 \n-1.0 -0.3333333333333333 0.6666666666666666 \n\n",
				MatrixOps.inverseGJ(A).toString());
		/*
		 * 2.0 2.3333333333333335 -1.6666666666666665 -0.0 -0.6666666666666666
		 * 0.3333333333333333 -1.0 -0.3333333333333333 0.6666666666666666
		 */
	}

}

package jUnit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import container.DataPoint;

public class DataPointTest {
	static DataPoint testPoint1;
	static DataPoint testPoint2;
	static DataPoint testPoint3;
	static DataPoint testPoint4;
	static DataPoint testPoint5;

	@BeforeClass
	public static void setUp() {
		testPoint1 = new DataPoint(3.333, 33.333);
		testPoint2 = new DataPoint(4.333, 44.333);
		testPoint3 = new DataPoint(5.333, 55.333);
		testPoint4 = new DataPoint(6.333, 66.333);
		testPoint5 = new DataPoint(7.333, 77.333);
	}

	public void testDataPointDoubleDouble() {

		assertNotNull(testPoint1);
		assertNotNull(testPoint2);
		assertNotNull(testPoint3);
		assertNotNull(testPoint4);
		assertNotNull(testPoint5);

	}

	@Test
	public void testGetX() {
		assertEquals(testPoint1.getX(), 3.333, .01);
		assertEquals(testPoint2.getX(), 4.333, .01);
		assertEquals(testPoint3.getX(), 5.333, .01);
		assertEquals(testPoint4.getX(), 6.333, .01);
		assertEquals(testPoint5.getX(), 7.333, .01);

	}

	@Test
	public void testGetY() {
		assertEquals(testPoint1.getY(), 33.333, .01);
		assertEquals(testPoint2.getY(), 44.333, .01);
		assertEquals(testPoint3.getY(), 55.333, .01);
		assertEquals(testPoint4.getY(), 66.333, .01);
		assertEquals(testPoint5.getY(), 77.333, .01);

	}

	@Test
	public void testSetX() {
		testPoint1.setX(1);
		assertEquals(testPoint1.getX(), 1, .01);
		testPoint1.setX(2);
		assertEquals(testPoint1.getX(), 2, .01);
		testPoint1.setX(3);
		assertEquals(testPoint1.getX(), 3, .01);
		testPoint1.setX(4);
		assertEquals(testPoint1.getX(), 4, .01);

	}

	@Test
	public void testSetY() {
		testPoint1.setY(1);
		assertEquals(testPoint1.getY(), 1, .01);
		testPoint1.setY(2);
		assertEquals(testPoint1.getY(), 2, .01);
		testPoint1.setY(3);
		assertEquals(testPoint1.getY(), 3, .01);
		testPoint1.setY(4);
		assertEquals(testPoint1.getY(), 4, .01);
	}

	@Test
	public void testEqualsObject() {
		DataPoint revTestPoint1 = new DataPoint(1, 5);

		assertTrue(revTestPoint1.equals(new DataPoint(1, 5)));
		assertFalse(revTestPoint1.equals(new DataPoint(2, 5)));
		assertFalse(revTestPoint1.equals(new DataPoint(1, 6)));

		DataPoint revTestPoint2 = new DataPoint(44, 99);

		assertTrue(revTestPoint2.equals(new DataPoint(44, 99)));
		assertFalse(revTestPoint2.equals(new DataPoint(2, 99)));
		assertFalse(revTestPoint2.equals(new DataPoint(44, 6)));

	}

}

package jUnit;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import analysisTools.Regression;

import plotInstance.GraphData;

import container.DataSet;
import container.DataPoint;

/**
 * @author dwp726(integration with JUnit) ark043 (test cases) Runs the testing
 *         for regression formulas.
 */
public class RegressionTest {
	DataSet datal;

	@Before
	public void setUp() throws Exception {
		datal = new DataSet();

		// add points
		datal.addPointOrdered(new DataPoint(1, 2));
		datal.addPointOrdered(new DataPoint(1.5, 4));
		datal.addPointOrdered(new DataPoint(2, 6));
		datal.addPointOrdered(new DataPoint(2.5, 8));
		datal.addPointOrdered(new DataPoint(3, 10));
		datal.addPointOrdered(new DataPoint(3.5, 12));
		datal.addPointOrdered(new DataPoint(4, 14));
		datal.addPointOrdered(new DataPoint(4.5, 16));
		datal.addPointOrdered(new DataPoint(5, 18));
		datal.addPointOrdered(new DataPoint(5.5, 20));
	}

	@Test
	public void testMean() {
		// fail("Not yet implemented");
	}

	@Test
	public void testLinear() {
		HashMap<String, Double> linReg;
		linReg = Regression.Linear(datal);

		assertEquals("4.0", GraphData.get().getXFormatted(linReg.get("B1")));
		assertEquals("-2.0", GraphData.get().getXFormatted(linReg.get("B0")));
		assertEquals("1.0", GraphData.get().getXFormatted(linReg.get("adj R^2")));
		assertEquals("0.0", GraphData.get().getXFormatted(linReg.get("var")));
		assertEquals("0.0", GraphData.get().getXFormatted(linReg.get("stdev")));

		/*
		 * Linear Regression Results y = (4.0x) + (-2.0) R^2 = 1.0 adjusted R^2
		 * = 1.0 variance = 0.0 standard deviation = 0.0
		 */
	}

	@Test
	public void testPolynomial() {
		HashMap<String, Double> polReg;
		polReg = Regression.Polynomial(datal, 3);

		assertEquals("0.0", GraphData.get().getXFormatted(polReg.get("B3")));
		assertEquals("-0.0", GraphData.get().getXFormatted(polReg.get("B2")));
		assertEquals("4.0", GraphData.get().getXFormatted(polReg.get("B1")));
		assertEquals("-2.0", GraphData.get().getXFormatted(polReg.get("B0")));
		assertEquals("1.0", GraphData.get().getXFormatted(polReg.get("R^2")));
		assertEquals("1.0", GraphData.get().getXFormatted(polReg.get("adj R^2")));
		assertEquals("0.0", GraphData.get().getXFormatted(polReg.get("var")));
		assertEquals("0.0", GraphData.get().getXFormatted(polReg.get("stdev")));

		/*
		 * Polynomial Regression, power 3 Results y = (0.0x^3) + (-0.0x^2) +
		 * (4.0x) + (-2.0) R^2 = 1.0 adjusted R^2 = 1.0 variance = 0.0 standard
		 * deviation = 0.0
		 */

	}

	@Test
	public void testPower() {
		HashMap<String, Double> powReg;
		powReg = Regression.Power(datal);

		assertEquals("2.2", GraphData.get().getXFormatted(powReg.get("A")));
		assertEquals("1.3", GraphData.get().getXFormatted(powReg.get("B")));
		assertEquals("1.0", GraphData.get().getXFormatted(powReg.get("R^2")));
		assertEquals("1.0", GraphData.get().getXFormatted(powReg.get("adj R^2")));
		assertEquals("0.4", GraphData.get().getXFormatted(powReg.get("var")));
		assertEquals("0.6", GraphData.get().getXFormatted(powReg.get("stdev")));
		/*
		 * Power Regression y = (2.2)*x^(1.3) R^2 = 1.0 adjusted R^2 = 1.0
		 * variance = 0.4 standard deviation = 0.6
		 */
	}

	@Test
	public void testLogarithmic() {
		HashMap<String, Double> logReg;
		logReg = Regression.Logarithmic(datal);

		assertEquals("-0.2", GraphData.get().getXFormatted(logReg.get("A")));
		assertEquals("10.6", GraphData.get().getXFormatted(logReg.get("B")));
		assertEquals("0.9", GraphData.get().getXFormatted(logReg.get("R^2")));
		assertEquals("0.9", GraphData.get().getXFormatted(logReg.get("adj R^2")));
		assertEquals("2.2", GraphData.get().getXFormatted(logReg.get("var")));
		assertEquals("1.5", GraphData.get().getXFormatted(logReg.get("stdev")));

		/*
		 * Logarithmic Regression y = -0.2 + 10.6*ln(x) R^2 = 0.9 adjusted R^2 =
		 * 0.9 variance = 2.2 standard deviation = 1.5
		 */
	}

	@Test
	public void testExponential() {
		HashMap<String, Double> expReg;
		expReg = Regression.Exponential(datal);

		assertEquals("2.9", GraphData.get().getXFormatted(expReg.get("A")));
		assertEquals("0.4", GraphData.get().getXFormatted(expReg.get("B")));
		assertEquals("0.9", GraphData.get().getXFormatted(expReg.get("R^2")));
		assertEquals("0.9", GraphData.get().getXFormatted(expReg.get("adj R^2")));
		assertEquals("2.2", GraphData.get().getXFormatted(expReg.get("var")));
		assertEquals("1.5", GraphData.get().getXFormatted(expReg.get("stdev")));
		/*
		 * y = (2.9)*exp(0.4*x) R^2 = 0.9 adjusted R^2 = 0.9 variance = 2.2
		 * standard deviation = 1.5
		 */
	}

}

package jUnit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import container.Matrix;

public class MatrixTest {
	static Matrix testMatrix;

	@BeforeClass
	public static void setUp() {

		testMatrix = new Matrix(3, 3);

		// Display the created matrix
		System.out.print(testMatrix.toString());
	}

	@Test
	public void testMatrix() {
		assertNotNull(testMatrix);

	}

	@Test
	public void testGetW() {
		assertEquals(3, testMatrix.getW());
	}

	@Test
	public void testGetH() {
		assertEquals(3, testMatrix.getH());

	}

	@Test
	public void testSet() {
		// Create a matrix
		/*
		 * 1 2 3 4 5 6 7 8 9
		 */
		for (int i = 0; i < testMatrix.getH(); i++) {
			for (int j = 0; j < testMatrix.getW(); j++) {
				testMatrix.set(i, j, (j + 3 * i + 1));
			}
		}
	}

	@Test
	public void testGet() {
		assertEquals(1.0, testMatrix.get(0, 0), .01);
		assertEquals(2.0, testMatrix.get(0, 1), .01);
		assertEquals(3.0, testMatrix.get(0, 2), .01);
		assertEquals(4.0, testMatrix.get(1, 0), .01);
		assertEquals(5.0, testMatrix.get(1, 1), .01);
		assertEquals(6.0, testMatrix.get(1, 2), .01);
		assertEquals(7.0, testMatrix.get(2, 0), .01);
		assertEquals(8.0, testMatrix.get(2, 1), .01);
		assertEquals(9.0, testMatrix.get(2, 2), .01);
	}

	@Test
	public void testAddRow() {
		testMatrix.addRow();
		assertEquals(4, testMatrix.getH());

		System.out.print(testMatrix.toString());

		testMatrix.addRow();
		assertEquals(5, testMatrix.getH());

		testMatrix.addRow();
		assertEquals(6, testMatrix.getH());

		testMatrix.addRow();
		assertEquals(7, testMatrix.getH());

		testMatrix.addRow();
		assertEquals(8, testMatrix.getH());

	}

	@Test
	public void testAddCol() {

		testMatrix.addCol();
		assertEquals(4, testMatrix.getW());
		testMatrix.addCol();
		assertEquals(5, testMatrix.getW());
		testMatrix.addCol();
		assertEquals(6, testMatrix.getW());
		testMatrix.addCol();
		assertEquals(7, testMatrix.getW());
		testMatrix.addCol();
		assertEquals(8, testMatrix.getW());
	}

}

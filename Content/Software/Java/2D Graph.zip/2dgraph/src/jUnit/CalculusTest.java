package jUnit;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import analysisTools.Calculus;
import analysisTools.Regression;

import plotInstance.GraphData;

import container.DataSet;
import container.DataPoint;
import enumerations.RegTypes;

/**
 * @author dwp726(integration with JUnit) ark043 (test cases) Tests the area
 *         calculations of a graph plot. Mainly the Integral, Derivative and
 *         SecondDerivative Functions
 */
public class CalculusTest {
	DataSet datal;
	HashMap<String, Double> reg;

	@Before
	public void setUp() throws Exception {
		datal = new DataSet();

		// add points
		datal.addPointOrdered(new DataPoint(1, 2));
		datal.addPointOrdered(new DataPoint(1.5, 4));
		datal.addPointOrdered(new DataPoint(2, 6));
		datal.addPointOrdered(new DataPoint(2.5, 8));
		datal.addPointOrdered(new DataPoint(3, 10));
		datal.addPointOrdered(new DataPoint(3.5, 12));
		datal.addPointOrdered(new DataPoint(4, 14));
		datal.addPointOrdered(new DataPoint(4.5, 16));
		datal.addPointOrdered(new DataPoint(5, 18));
		datal.addPointOrdered(new DataPoint(5.5, 20));
	}

	@Test
	public void testLinear() {

		reg = Regression.Linear(datal);

		assertEquals("4.0", GraphData.get().getXFormatted(reg.get("B1")));
		assertEquals("-2.0", GraphData.get().getXFormatted(reg.get("B0")));
		assertEquals("49.5", GraphData.get().getXFormatted(Calculus.Integral(RegTypes.linear, reg, 1, 5.5)));
		assertEquals("4.0", GraphData.get().getXFormatted(Calculus.Derivative(RegTypes.linear, reg, 3)));
		assertEquals("0.0", GraphData.get().getXFormatted(Calculus.SecondDerivative(RegTypes.linear, reg, 4.5)));
		/*
		 * Linear Regression: y = (4.0x) + (-2.0) Integral on [1, 5.5]: 49.5
		 * Derivative at 3: 4.0 Second Derivative at 4.5: 0.0
		 */
	}

	@Test
	public void testPolynomial() {
		reg = Regression.Polynomial(datal, 3);

		assertEquals("0.0", GraphData.get().getXFormatted(reg.get("B3")));
		assertEquals("-0.0", GraphData.get().getXFormatted(reg.get("B2")));
		assertEquals("4.0", GraphData.get().getXFormatted(reg.get("B1")));
		assertEquals("-2.0", GraphData.get().getXFormatted(reg.get("B0")));
		assertEquals("49.5", GraphData.get().getXFormatted(Calculus.Integral(RegTypes.polynomial, reg, 1, 5.5)));
		assertEquals("4.0", GraphData.get().getXFormatted(Calculus.Derivative(RegTypes.polynomial, reg, 3)));
		assertEquals("-0.0", GraphData.get().getXFormatted(Calculus.SecondDerivative(RegTypes.polynomial, reg, 4.5)));
		/*
		 * Polynomial Regression: y = (0.0x^3) + (-0.0x^2) + (4.0x) + (-2.0)
		 * Integral on [1, 5.5]: 49.5 Derivative at 3: 4.0 Second Derivative at
		 * 4.5: -0.0
		 */
	}

	@Test
	public void testPower() {
		reg = Regression.Power(datal);

		assertEquals("2.2", GraphData.get().getXFormatted(reg.get("A")));
		assertEquals("1.3", GraphData.get().getXFormatted(reg.get("B")));
		assertEquals("49.5", GraphData.get().getXFormatted(Calculus.Integral(RegTypes.power, reg, 1, 5.5)));
		assertEquals("4.2", GraphData.get().getXFormatted(Calculus.Derivative(RegTypes.power, reg, 3)));
		assertEquals("0.3", GraphData.get().getXFormatted(Calculus.SecondDerivative(RegTypes.power, reg, 4.5)));
		/*
		 * Power Regression: y = (2.2)*x^(1.3) Integral on [1, 5.5]: 49.5
		 * Derivative at 3: 4.2 Second Derivative at 4.5: 0.3
		 */
	}

	@Test
	public void testLogarithmic() {
		reg = Regression.Logarithmic(datal);

		assertEquals("-0.2", GraphData.get().getXFormatted(reg.get("A")));
		assertEquals("10.6", GraphData.get().getXFormatted(reg.get("B")));
		assertEquals("50.8", GraphData.get().getXFormatted(Calculus.Integral(RegTypes.logarithmic, reg, 1, 5.5)));
		assertEquals("3.5", GraphData.get().getXFormatted(Calculus.Derivative(RegTypes.logarithmic, reg, 3)));
		assertEquals("-0.5", GraphData.get().getXFormatted(Calculus.SecondDerivative(RegTypes.logarithmic, reg, 4.5)));
		/*
		 * Logarithmic Regression: y = -0.2 + 10.6*ln(x) Integral on [1, 5.5]:
		 * 50.8 Derivative at 3: 3.5 Second Derivative at 4.5: -0.5
		 */
	}

	@Test
	public void testExponential() {
		reg = Regression.Exponential(datal);

		assertEquals("2.9", GraphData.get().getXFormatted(reg.get("A")));
		assertEquals("0.4", GraphData.get().getXFormatted(reg.get("B")));
		assertEquals("48.8", GraphData.get().getXFormatted(Calculus.Integral(RegTypes.exponential, reg, 1, 5.5)));
		assertEquals("3.3", GraphData.get().getXFormatted(Calculus.Derivative(RegTypes.exponential, reg, 3)));
		assertEquals("2.2", GraphData.get().getXFormatted(Calculus.SecondDerivative(RegTypes.exponential, reg, 4.5)));
		/*
		 * Exponential Regression: y = (2.9)*exp(0.4*x) Integral on [1, 5.5]:
		 * 48.8 Derivative at 3: 3.3 Second Derivative at 4.5: 2.2
		 */
	}
}

package jUnit;

import org.junit.*;

import container.DataPoint;
import container.Graph;

/**
 * 
 * @author ral940
 */
public class GraphTest {

	Graph testGraph;

	@Before
	public void setUp() throws Exception {
		testGraph = new Graph();
	}

	@Test
	public void testGetSetScaleX() {
		testGraph.setScaleX(5);

		Assert.assertEquals(5, testGraph.getScaleX());
	}

	@Test
	public void testGetSetScaleY() {
		testGraph.setScaleY(3);
		Assert.assertEquals(3, testGraph.getScaleY());
	}

	@Test
	public void testGetSetName() {
		testGraph.setName("Test");
		Assert.assertEquals("Test", testGraph.getName());
	}

	@Test
	public void testGetSetXName() {
		testGraph.setXName("Test X");
		Assert.assertEquals("Test X", testGraph.getXName());
	}

	@Test
	public void testGetSetYName() {
		testGraph.setYName("Test Y");
		Assert.assertEquals("Test Y", testGraph.getYName());
	}

	@Test
	public void testGetSetXFormat() {
		testGraph.setXFormat("X Format");
		;
		Assert.assertEquals("X Format", testGraph.getXFormat());
	}

	@Test
	public void testGetSetYFormat() {
		testGraph.setYFormat("Y Format");
		;
		Assert.assertEquals("Y Format", testGraph.getYFormat());
	}

	@Test
	public void testGetXFormatted() {
		Assert.assertEquals("2.2", testGraph.getXFormatted(2.2));
	}

	@Test
	public void testGetYFormatted() {
		Assert.assertEquals("3.8", testGraph.getYFormatted(3.8));
	}

	@Test
	public void testAddNumLines() {
		// Test addNewLine
		testGraph.addNewLine();
		testGraph.addNewLine();
		testGraph.addNewLine();

		Assert.assertEquals(4, testGraph.numLines());
	}

	@Test
	public void testGetLine() {
		DataPoint p1 = new DataPoint(2, 2, 1, 1, 0, 0);
		DataPoint p2 = new DataPoint(1.0, 6.0);
		DataPoint p3 = new DataPoint(5, 9);

		testGraph.addNewLine();
		testGraph.addNewLine();
		testGraph.addNewLine();

		// Testing addPointOrdered (with and without error)
		testGraph.getLine(2).addPointOrdered(p1);
		testGraph.getLine(2).addPointOrdered(p2);
		testGraph.getLine(2).addPointOrdered(p3);

		Assert.assertEquals("[(1.0,{0.0,0.0},6.0,{0.0,0.0}) , (2.0,{1.0,1.0},2.0,{0.0,0.0}) , " + "(5.0,{0.0,0.0},9.0,{0.0,0.0}) ]", testGraph
				.getLine(2).getData().toString());
	}

	

	@Test
	public void testDeleteLine() {
		testGraph.addNewLine();
		testGraph.addNewLine();
		testGraph.addNewLine();

		testGraph.deleteLine(0);

		Assert.assertEquals(3, testGraph.numLines());
	}

	@Test
	public void testDeleteThisLine() {
		DataPoint p1 = new DataPoint(2.5, 5.0, 0.0, 0.1, 2.0, 0.0);
		DataPoint p2 = new DataPoint(0, 0);
		DataPoint p3 = new DataPoint(5, 8);

		testGraph.addNewLine();
		testGraph.addNewLine();
		testGraph.addNewLine();


		// Testing addPointSequential (with and without error)
		testGraph.insertPointSequential(2, p1.getX(), p1.getY());
		testGraph.insertPointSequential(2, p2.getX(), p2.getY());
		testGraph.insertPointSequential(2, p3.getX(), p3.getY());

		Assert.assertEquals("[(2.5,{0.0,0.1},5.0,{2.0,0.0}) , (0.0,{0.0,0.0},0.0,{0.0,0.0}) , " + "(5.0,{0.0,0.0},8.0,{0.0,0.0}) ]", testGraph.getLine(2).getData().toString());

		testGraph.deleteLine(2);
		Assert.assertEquals("[]", testGraph.getLine(1).getData().toString());
	}

	@Test
	public void testRemovePoint() {
		DataPoint p1 = new DataPoint(2, 2, 1, 1, 0, 0);
		DataPoint p2 = new DataPoint(1.0, 6.0);
		DataPoint p3 = new DataPoint(5, 9);

		testGraph.addNewLine();

		testGraph.insertPointOrdered(1, p1.getX(), p1.getY());
		testGraph.insertPointOrdered(1, p2.getX(), p2.getY());
		testGraph.insertPointOrdered(1, p3.getX(), p3.getY());

		Assert.assertEquals("[(1.0,{0.0,0.0},6.0,{0.0,0.0}) , (2.0,{1.0,1.0},2.0,{0.0,0.0}) , " + "(5.0,{0.0,0.0},9.0,{0.0,0.0}) ]", testGraph
				.getLine(1).getData().toString());

		testGraph.removePoint(1, 1);

		Assert.assertEquals("[(1.0,{0.0,0.0},6.0,{0.0,0.0}) , " + "(5.0,{0.0,0.0},9.0,{0.0,0.0}) ]", testGraph.getLine(1).getData().toString());
	}
}

package jUnit;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.BeforeClass;
import org.junit.Test;

import container.DataPoint;
import container.DataSet;

import enumerations.RegTypes;

public class DataSetTest {
	static DataSet testLine;

	@BeforeClass
	public static void setUp() {
		testLine = new DataSet();

	}

	@Test
	public void testDataLine() {
		assertNotNull(testLine);

	}

	@Test
	public void testGetName() {
		testLine.setName("GraphBot");
		assertEquals(testLine.getName(), "GraphBot");
	}

	@Test
	public void testAddPointOrdered() {

		testLine.addPointOrdered(new DataPoint(1, 11));
		assertEquals(1, testLine.size());
		assertEquals(1, testLine.get(1, 11).getX(), .01);

		testLine.addPointOrdered(new DataPoint(2, 22));
		assertEquals(2, testLine.size());
		assertEquals(2, testLine.get(2, 22).getX(), .01);

		testLine.addPointOrdered(new DataPoint(5, 55));
		assertEquals(3, testLine.size());
		assertEquals(5, testLine.get(5, 55).getX(), .01);

		testLine.addPointOrdered(new DataPoint(4, 44));
		assertEquals(4, testLine.size());
		assertEquals(4, testLine.get(4, 44).getX(), .01);

		testLine.addPointOrdered(new DataPoint(3, 33));
		assertEquals(5, testLine.size());
		assertEquals(3, testLine.get(3, 33).getX(), .01);

	}

	@Test
	public void testGetDoubleDouble() {

		assertEquals(1, testLine.get(1, 11).getX(), .01);
		assertEquals(2, testLine.get(2, 22).getX(), .01);
		assertEquals(3, testLine.get(3, 33).getX(), .01);
		assertEquals(4, testLine.get(4, 44).getX(), .01);
		assertEquals(5, testLine.get(5, 55).getX(), .01);

	}

	@Test
	public void testRemoveDoubleDouble() {

		int beforeLineSize = testLine.size();

		assertTrue(testLine.remove(1, 11));
		assertEquals(testLine.size(), beforeLineSize - 1);

		assertTrue(testLine.remove(2, 22));
		assertEquals(testLine.size(), beforeLineSize - 2);

		assertTrue(testLine.remove(3, 33));
		assertEquals(testLine.size(), beforeLineSize - 3);

		assertTrue(testLine.remove(4, 44));
		assertEquals(testLine.size(), beforeLineSize - 4);

		assertTrue(testLine.remove(5, 55));
		assertEquals(testLine.size(), beforeLineSize - 5);
	}

	@Test
	public void testAddPointSequential() {

		testLine.addPointSequential(new DataPoint(1, 11));
		System.out.println(testLine.size());
		System.out.println(testLine.getPointAt(0));
		assertEquals(1, testLine.size());

		testLine.addPointSequential(new DataPoint(2, 22));
		System.out.println(testLine.size());
		System.out.println(testLine.getPointAt(1));
		assertEquals(2, testLine.size());

		testLine.addPointSequential(new DataPoint(3, 33));
		System.out.println(testLine.size());
		System.out.println(testLine.getPointAt(2));
		assertEquals(3, testLine.size());

		testLine.addPointSequential(new DataPoint(4, 44));
		System.out.println(testLine.size());
		System.out.println(testLine.getPointAt(3));
		assertEquals(4, testLine.size());

		testLine.addPointSequential(new DataPoint(5, 55));
		System.out.println(testLine.size());
		System.out.println(testLine.getPointAt(4));
		assertEquals(5, testLine.size());

	}

	@Test
	public void testGetInt() {
		assertEquals(1, testLine.get(0).getX(), .01);
		assertEquals(2, testLine.get(1).getX(), .01);
		assertEquals(3, testLine.get(2).getX(), .01);
		assertEquals(4, testLine.get(3).getX(), .01);
		assertEquals(5, testLine.get(4).getX(), .01);
	}

	@Test
	public void testRemoveInt() {
		int beforeLineSize = testLine.size();

		assertEquals(1, testLine.remove(0).getX(), .01);
		assertEquals(testLine.size(), beforeLineSize - 1);

		assertEquals(2, testLine.remove(0).getX(), .01);
		assertEquals(testLine.size(), beforeLineSize - 2);

		assertEquals(3, testLine.remove(0).getX(), .01);
		assertEquals(testLine.size(), beforeLineSize - 3);

		assertEquals(4, testLine.remove(0).getX(), .01);
		assertEquals(testLine.size(), beforeLineSize - 4);

		assertEquals(5, testLine.remove(0).getX(), .01);
		assertEquals(testLine.size(), beforeLineSize - 5);
	}

	@Test
	public void testEmpty() {
		testLine.addPointSequential(new DataPoint(1, 11));
		assertEquals(1, testLine.size());
		System.out.println(testLine.getPointAt(0));

		testLine.addPointSequential(new DataPoint(2, 22));
		assertEquals(2, testLine.size());
		System.out.println(testLine.getPointAt(1));

		testLine.addPointSequential(new DataPoint(3, 33));
		assertEquals(3, testLine.size());
		System.out.println(testLine.getPointAt(2));

		testLine.addPointSequential(new DataPoint(4, 44));
		assertEquals(4, testLine.size());
		System.out.println(testLine.getPointAt(3));

		testLine.addPointSequential(new DataPoint(5, 55));
		assertEquals(5, testLine.size());
		System.out.println(testLine.getPointAt(4));

		testLine.empty();
		System.out.println(testLine.size());
		assertEquals(0, testLine.size());

	}


	@Test
	public void testAddRegDataItem() {

		testLine.addRegDataItem(RegTypes.polynomial, "1", 34);
		testLine.addRegDataItem(RegTypes.polynomial, "2", 35);
		testLine.addRegDataItem(RegTypes.polynomial, "3", 36);
		testLine.addRegDataItem(RegTypes.polynomial, "4", 37);
		testLine.addRegDataItem(RegTypes.polynomial, "5", 38);

	}

	@Test
	public void testSetDisplayedRegItem() {
		testLine.setDisplayedRegItem(RegTypes.polynomial, "1");
		testLine.setDisplayedRegItem(RegTypes.polynomial, "2");
		testLine.setDisplayedRegItem(RegTypes.polynomial, "3");
		testLine.setDisplayedRegItem(RegTypes.polynomial, "4");

	}

	@Test
	public void testRemoveDisplayedRegItem() {
		testLine.removeDisplayedRegItem(RegTypes.polynomial, "2");

	}

	@Test
	public void testGetLineColor() {
		testLine.setLineColor(Color.red);
		assertEquals(Color.red, testLine.getLineColor());
		testLine.setLineColor(Color.blue);
		assertEquals(Color.blue, testLine.getLineColor());
		testLine.setLineColor(Color.black);
		assertEquals(Color.black, testLine.getLineColor());
	}

	@Test
	public void testSetLineColorColor() {
		testLine.setLineColor(Color.red);
		assertEquals(Color.red, testLine.getLineColor());
		testLine.setLineColor(Color.blue);
		assertEquals(Color.blue, testLine.getLineColor());
		testLine.setLineColor(Color.black);
		assertEquals(Color.black, testLine.getLineColor());
	}

	@Test
	public void testIsLineVisible() {
		testLine.setLineVisible(false);
		assertFalse(testLine.isLineVisible());
		testLine.setLineVisible(true);
		assertTrue(testLine.isLineVisible());
	}

}

package enumerations;

/**
 * @author Adam Knox
 * @description these are the types of regressions available
 */
public enum RegTypes {
	linear, polynomial, exponential, logarithmic, power;

	public static RegTypes fromOrdinal(int ordinal) {
		if (ordinal == 0)
			return RegTypes.linear;
		else if (ordinal == 1)
			return RegTypes.polynomial;
		else if (ordinal == 2)
			return RegTypes.exponential;
		else if (ordinal == 3)
			return RegTypes.logarithmic;
		else if (ordinal == 4)
			return RegTypes.power;

		return null;
	}
}

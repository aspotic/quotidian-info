package enumerations;

/**
 * @author Adam Knox
 * @description these are the types of calculus operations that can be done
 */
public enum CalcTypes {
	integral, derivative, secondDerivative
}

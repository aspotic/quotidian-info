package enumerations;

/**
 * @author Adam Knox
 * @description these are the options for RGB colors
 */
public enum RGB {
	red, green, blue
}

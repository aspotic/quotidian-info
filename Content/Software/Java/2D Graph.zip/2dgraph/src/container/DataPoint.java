package container;
/**
 * @description Basic DataPoint class Contains error bars and has 2D coordinates x and y
 * @author Amara Daal
 */
import plotInstance.GraphData;

public class DataPoint {
	private double x = 0;
	private double y = 0;
	private double errorNorth = 0;
	private double errorSouth = 0;
	private double errorEast = 0;
	private double errorWest = 0;

	/**
	 * Creates a new DataPoint
	 * 
	 * @param newX
	 *            x value
	 * @param newY
	 *            y value
	 */
	public DataPoint(double newX, double newY) {
		x = newX;
		y = newY;
		GraphData.get().refresh();
	}

	/**
	 * @description Creates a new DataPoint with every value
	 * @param newX
	 *            x value
	 * @param newY
	 *            y value
	 * @param eastError
	 *            the left error bar value
	 * @param westError
	 *            the right error bar value
	 * @param northError
	 *            the upper error bar value
	 * @param southError
	 *            the lower error bar value
	 * @author Adam Knox
	 */
	public DataPoint(double newX, double newY, double eastError,
			double westError, double northError, double southError) {
		x = newX;
		y = newY;
		errorNorth = northError;
		errorSouth = southError;
		errorEast = eastError;
		errorWest = westError;
		GraphData.get().refresh();
	}

	/**
	 * @description sets the x value of datapoint to gotX
	 * @param gotX
	 * @return true if set
	 * @author Amara Daal
	 */
	public boolean setX(double gotX) {
		this.x = gotX;
		GraphData.get().refresh();
		return true;
	}

	/**
	 * @description sets the y value of datapoint to gotY
	 * @param gotY
	 * @return true if set
	 * @author Amara Daal
	 */
	public boolean setY(double gotY) {
		this.y = gotY;
		GraphData.get().refresh();
		return true;
	}

	/**
	 * @description gets x value of datapoint
	 * @return the value of x
	 * @author Amara Daal
	 */
	public double getX() {
		return x;
	}

	/**
	 * @description gets y value of datapoint
	 * @return the value of y
	 * @author Amara Daal
	 */
	public double getY() {
		return y;
	}

	/**
	 * 
	 * @description gets the error bar length to the east of datapoint
	 * @return the length
	 * @author Amara Daal
	 */
	public double getErrorEast() {
		return errorEast;
	}

	/**
	 * @description gets the error bar length to the North of datapoint
	 * @return the length
	 * @author Amara Daal
	 */
	public double getErrorNorth() {
		return errorNorth;
	}

	/**
	 * @description gets the error bar length to the West of datapoint
	 * @return the length
	 * @author Amara Daal
	 */
	public double getErrorWest() {
		return errorWest;
	}

	/**
	 * @description gets the error bar length to the South of datapoint
	 * @return the length
	 * @author Amara Daal
	 */
	public double getErrorSouth() {
		return errorSouth;
	}

	/**
	 * @description to String DataPoint
	 * @author Adam Knox
	 */
	public String toString() {
		//prints out the datapoint info to a string
		String rtnString = "(" + x + ",{" + errorEast + "," + errorWest + "},"
				+ y + ",{" + errorNorth + "," + errorSouth + "}) ";
		return rtnString;
	}
}

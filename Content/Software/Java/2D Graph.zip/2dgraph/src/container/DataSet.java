package container;

import java.awt.Color;

import java.util.HashMap;
import java.util.LinkedList;

import analysisTools.RegDataToText;

import plotInstance.GraphData;
import enumerations.CalcTypes;
import enumerations.RegTypes;

/**
 * DataLine Class Contains a Linked list of DataPoints, performs functions on
 * DataPoints. Has a regression Data associated with itself which keeps track of
 * its regression statistics.
 */
public class DataSet {
	// A list of all the points in the data set
	private LinkedList<DataPoint> data = new LinkedList<DataPoint>();
	// Contains the string of data to display below the plot for this line
	private String regString = ""; 
	// Contains the regression data for each regression method
	private HashMap<RegTypes, HashMap<String, Double>> regData = new HashMap<RegTypes, HashMap<String, Double>>();
	// Contains the items the user wants displayed for each regression method
	private HashMap<RegTypes, LinkedList<String>> regDisplayedData = new HashMap<RegTypes, LinkedList<String>>();
	// The color of the lines connection each point
	private Color lineColor = Color.black; 
	// The thickness of the lines connection each point
	private int lineThickness = 1; 
	// Visibility of the lines connecting each point
	private boolean lineVisible = true; 
	// The color of all data points
	private Color pointColor = Color.black; 
	// The size of all data points
	private int pointThickness = 3; 
	// Visibility all data points
	private boolean pointVisible = true; 
	// The color of the error bars
	private Color errorBarColor = Color.black; 
	// The thickness of the error bars
	private int errorBarThickness = 1; 
	// The visibility of the x error bar
	private boolean xErrorVisible = true; 
	// The visibility of the y error bar
	private boolean yErrorVisible = true; 
	// sets whether or not to show the cross hare bars for the error
	private boolean showErrorCrossHairs = true; 
	// sets whether or not to show the box bars for the error
	private boolean showErrorBox = true; 
	// The name of this line, used in the legend
	private String lineName = "New Data Set"; 

	
	/**
	 * @description constructor
	 * @author Adam Knox
	 */
	public DataSet() {
		// add lists and hash maps for each regression type
		for (RegTypes regType : RegTypes.values()) {
			regData.put(regType, new HashMap<String, Double>());
			regDisplayedData.put(regType, new LinkedList<String>());
		}

		data = new LinkedList<DataPoint>();
	}

	/**
	 * @description gets the size of the data list
	 * @author Adam Knox
	 * @return the size of the data list
	 */
	public int getDataSize() {
		return data.size();
	}

	/**
	 * @author Adam Knox
	 * @param index
	 *            the item index
	 * @return the data point
	 */
	public DataPoint getPointAt(int index) {
		return data.get(index);
	}

	/**
	 * @description gets the name of the data set
	 * @return the name of the line
	 * @author Adam Knox
	 */
	public String getName() {
		return lineName;
	}

	/**
	 * @description updates the regression string for the given line
	 * @param value
	 *            the index of the line to update
	 * @author Adam Knox
	 */
	public void updateRegString(int lineNumber) {
		int numEntries = 0;
		for (RegTypes regType : RegTypes.values()) {
			numEntries += regDisplayedData.get(regType).size();
		}

		if (numEntries > 0) {
			regString = lineName + " Results\n";
			regString += "------\n";

			for (RegTypes regType : RegTypes.values()) {
				String next = RegDataToText.findRegString(lineNumber, regType);
				if (next != null) {
					if (next != "") {
						regString += next + "------\n";
					}
				}
			}

			// update the plot text
			GraphData.get().updatePlotText();
		} else {
			regString = "";
		}

	}

	/**
	 * @description sets the regression string to the given value
	 * @param value
	 *            the value to set the regression string to
	 * @author Adam Knox
	 */
	public void setRegString(String newRegString) {
		regString = newRegString;

		// update the plot text
		GraphData.get().updatePlotText();
	}

	/**
	 * @description returns the current regression string for this line
	 * @return the regression string for this line
	 * @author Adam Knox
	 */
	public String getRegString() {
		return regString;
	}

	/**
	 * @description sets a regression stat to be displayed
	 * @param regType
	 *            the regression to show the stat for
	 * @param values
	 *            the stat to show
	 * @author Adam Knox
	 */
	public void setDisplayedRegItem(RegTypes regType, String value) {
		// put the value in the list of things to display if it isn't already
		if (regDisplayedData.get(regType) == null) {
			regDisplayedData.get(regType).add(value);
		} else {
			if (regDisplayedData.get(regType).contains(value)) {
				return;
			} else {
				regDisplayedData.get(regType).add(value);
			}

		}
	}

	/**
	 * @description remove a regression stat from being shown
	 * @param regType
	 *            the regression method to hide the stat for
	 * @param values
	 *            the name of the stat to remove
	 * @author Adam Knox
	 */
	public void removeDisplayedRegItem(RegTypes regType, String value) {
		// put the value in the list of things to display if it isn't already
		if (regDisplayedData.get(regType).contains(value)) {
			regDisplayedData.get(regType).remove(value);
		}
	}

	/**
	 * @description puts the regression data structure into the object
	 * @param regType
	 *            the type of regression the data is for
	 * @param values
	 *            the set of data
	 * @author Adam Knox
	 */
	public void setRegData(RegTypes regType, HashMap<String, Double> values) {
		regData.put(regType, values);
	}

	/**
	 * @description puts the regression data item into the object
	 * @param regType
	 *            the type of regression the data is for
	 * @param title
	 *            the variable name to use
	 * @param value
	 *            the value of the variable
	 * @author Adam Knox
	 */
	public void addRegDataItem(RegTypes regType, String title, double value) {
		regData.get(regType).put(title, value);
	}

	/**
	 * @description gets the set of regression stats to be displayed for the
	 *              method
	 * @param regType
	 *            the regression method
	 * @return the list of regression stats to display for the regression method
	 * @author Adam Knox
	 */
	public LinkedList<String> getRegDisplayData(RegTypes regType) {
		return regDisplayedData.get(regType);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * @description gets the actual regression data
	 * @param regType
	 *            the method to get the data for
	 * @return the regression data
	 * @author Adam Knox
	 */
	public HashMap<String, Double> getRegData(RegTypes regType) {
		return regData.get(regType);
	}


	/**
	 * @description sets a calcus item to be shown for the regression
	 * @param calcType
	 *            the calculus operation being done
	 * @param regType
	 *            the regression this is for
	 * @param value
	 *            the integras value
	 * @param pointA
	 *            the point the derivative is done at
	 * @author Adam Knox
	 */
	public void setCalcData(CalcTypes calcType, RegTypes regType, double value, double pointA) {
		if (calcType == CalcTypes.derivative) {
			regData.get(regType).put("derivative A", pointA);
			regData.get(regType).put("derivative", value);
		} else if (calcType == CalcTypes.secondDerivative) {
			regData.get(regType).put("second derivative A", pointA);
			regData.get(regType).put("second derivative", value);
		}
	}

	/**
	 * @description sets a calculus item to be shown for the regression
	 * @param calcType
	 *            the calculus operation being done
	 * @param regType
	 *            the regression this is for
	 * @param value
	 *            the integras value
	 * @param pointA
	 *            the left limit of integration
	 * @param pointB
	 *            the right limit of integration
	 * @author Adam Knox
	 */
	public void setCalcData(CalcTypes calcType, RegTypes regType, double value, double pointA, double pointB) {
		if (calcType == CalcTypes.integral) {
			regData.get(regType).put("integral B", pointB);
			regData.get(regType).put("integral A", pointA);
			regData.get(regType).put("integral", value);
		} else if (calcType == CalcTypes.derivative) {
			regData.get(regType).put("derivative A", pointA);
			regData.get(regType).put("derivative", value);
		} else if (calcType == CalcTypes.secondDerivative) {
			regData.get(regType).put("second derivative A", pointA);
			regData.get(regType).put("second derivative", value);
		}
	}



	/**
	 * @description Add DataPoint to DataLine in a sorted order
	 * @param p
	 *            DataPoint to add
	 * @author Ricky Lays
	 */
	public void addPointOrdered(DataPoint p) {
		if (getData().size() == 0) {
			getData().addFirst(p);
			return;
		}

		for (int i = 0; i < getData().size(); i++) {
			if (p.getX() < getData().get(i).getX()) {
				getData().add(i, p);
				return;
			} else if (p.getX() == getData().get(i).getX()) {
				if (p.getY() <= getData().get(i).getY()) {
					getData().add(i, p);
					return;
				} else {
					getData().add(i + 1, p);
					return;
				}
			}
		}

		getData().addLast(p);
	}

	/**
	 * @description Add Point in sequential order ie unsorted one after the
	 *              other
	 * @param p
	 *            DataPoint to store in the DataLine
	 * @author Amara Daal
	 */
	public void addPointSequential(DataPoint p) {

		this.data.add(p);

	}

	/**
	 * @description Removes DataPoint based on its x and y value
	 * @param x
	 *            Value to match
	 * @param y
	 *            Value to match
	 * @return true if x&y matched and DataPoint removed
	 * @author Amara Daal
	 */
	public boolean remove(double x, double y) {
		DataPoint temp = new DataPoint(x, y);

		if (getData().contains(temp)) {
			getData().remove(temp);
			return true;
		}
		return false;

	}

	/*
	 * public void addPoint(DataPoint point) { data.add(data.size(), point); }
	 */

	/**
	 * @description Size of Dataline
	 * @return the size of Dataline
	 * @author Amara Daal
	 */
	public int size() {
		return getData().size();
	}

	/**
	 * @description Removes DataPoint based on the index in Dataline
	 * @param index
	 *            the location inside DataLine
	 * @return the removed DataPoint
	 * @author Amara Daal
	 */
	public DataPoint remove(int index) {
		return getData().remove(index);
	}

	/**
	 * @description Gets the DataPoint based on the index in Dataline
	 * @param index
	 *            index the location inside DataLine
	 * @return the removed DataPoint
	 * @author Amara Daal
	 */
	public DataPoint get(int index) {
		return getData().get(index);
	}

	/**
	 * @description Removes all DataPoints in DataLine
	 * @return true if DataLine is empty
	 * @author Amara Daal
	 */
	public boolean empty() {

		/* Iterate through this specific dataline printing out all points */

		while (this.data.size() != 0) {
			this.data.remove();

		}
		return true;
	}

	/**
	 * @description Gets DataPoint based on x&y value
	 * @param x
	 *            Value to be matched
	 * @param y
	 *            Value to be matched
	 * @return the DataPoint matching x&y
	 * @author Amara Daal
	 */
	public DataPoint get(double x, double y) {
		DataPoint temp = new DataPoint(x, y);

		for (int i = 0; i < getData().size(); i++) {
			if (getData().get(i).equals(temp)) {
				return getData().get(i);
			}
		}

		return null;
	}

	/**
	 * @description displays DataLine in string format
	 * @return DataLine in string format
	 * @author Adam Knox
	 */
	public String toString() {
		// initialise anything that is null
		if (lineName == null) {
			lineName = "";
		}

		if (regData == null) {
			regData = new HashMap<RegTypes, HashMap<String, Double>>();
		}

		if (regDisplayedData == null) {
			regDisplayedData = new HashMap<RegTypes, LinkedList<String>>();
		}

		if (lineColor == null) {
			lineColor = Color.black;
		}

		if (pointColor == null) {
			pointColor = Color.black;
		}

		if (errorBarColor == null) {
			errorBarColor = Color.black;
		}

		if (regString == null) {
			regString = "";
		}

		String rtString = "START OF DATALINE\n";

		// get title
		rtString += "lineName_#2DGrapher#_\n" + lineName + "\nendLineName_#2DGrapher#_\n";

		/* Get the data points for the line */
		rtString += "points_#2DGrapher#_";
		if (this.getData().size() > 0) {
			for (int i = 0; i < this.getData().size(); i++) {
				rtString += this.get(i).toString();
			}
		}
		rtString += "\n";

		/* get regression data */
		rtString += "regDisplayedData_#2DGrapher#_" + regDisplayedData.toString() + "\n";
		rtString += "regData_#2DGrapher#_" + regData.toString() + "\n";

		/* get line data */
		rtString += "lineColor_#2DGrapher#_" + lineColor.toString() + "\n";
		rtString += "lineThickness_#2DGrapher#_" + lineThickness + "\n";
		rtString += "lineVisible_#2DGrapher#_" + lineVisible + "\n";

		/* get point data */
		rtString += "pointColor_#2DGrapher#_" + pointColor.toString() + "\n";
		rtString += "pointThickness_#2DGrapher#_" + pointThickness + "\n";
		rtString += "pointVisible_#2DGrapher#_" + pointVisible + "\n";

		/* get error bar data */
		rtString += "errorBarColor_#2DGrapher#_" + errorBarColor.toString() + "\n";
		rtString += "errorBarThickness_#2DGrapher#_" + errorBarThickness + "\n";
		rtString += "xErrorVisible_#2DGrapher#_" + xErrorVisible + "\n";
		rtString += "yErrorVisible_#2DGrapher#_" + yErrorVisible + "\n";

		/* get text data */
		rtString += "regString_#2DGrapher#_\n" + regString + "\nendRegString_#2DGrapher#_\n";

		rtString += "END OF DATALINE\n\n";
		return rtString;
	}

	/**
	 * @description Color Getter
	 * @return Color of Line
	 * @author Amara Daal
	 */
	public Color getLineColor() {
		return lineColor;
	}

	/**
	 * @description Set the Line color of the current line
	 * @param lineColor
	 * @author Amara Daal
	 */
	public void setLineColor(Color lineColor) {
		this.lineColor = lineColor;
		GraphData.get().refresh();
	}

	/**
	 * @description Line thickness Getter
	 * @return lineThickness
	 * @author Amara Daal
	 */
	public int getLineThickness() {
		return lineThickness;
	}

	/**
	 * @description Line Thickness Setter
	 * @param lineThickness
	 * @author Amara Daal
	 */
	public void setLineThickness(int lineThickness) {
		this.lineThickness = lineThickness;
		GraphData.get().refresh();
	}

	/**
	 * @description LineVisible Getter
	 * @return true if line is visible
	 * @author Adam Knox
	 */
	public boolean isLineVisible() {
		return lineVisible;
	}

	/**
	 * @description LineVisible Setter
	 * @param lineVisible
	 * @author Adam Knox
	 */
	public void setLineVisible(boolean lineVisible) {
		this.lineVisible = lineVisible;
		GraphData.get().refresh();
	}

	/**
	 * @description sets whether or not x error bars are visible for this line
	 * @param xErrorVisible
	 * @author Adam Knox
	 */
	public void setXErrorVisible(boolean xErrorVisible) {
		this.xErrorVisible = xErrorVisible;
		GraphData.get().refresh();
	}

	/**
	 * @description sets whether or not y error bars are visible for this line
	 * @param yErrorVisible
	 * @author Adam KnoxError bar thickness
	 */
	public void setYErrorVisible(boolean yErrorVisible) {
		this.yErrorVisible = yErrorVisible;
		GraphData.get().refresh();
	}

	/**
	 * @description Gets Point colour
	 * @return pointColour
	 * @author Adam Knox
	 */
	public Color getPointColor() {
		return pointColor;
	}

	/**
	 * @description PointColor Setter
	 * @param pointColor
	 * @author Adam Knox
	 */
	public void setPointColor(Color pointColor) {
		this.pointColor = pointColor;
		GraphData.get().refresh();
	}

	/**
	 * @description Point Thickness Getter
	 * @return point thickness
	 * @author Adam Knox
	 */
	public int getPointThickness() {
		return pointThickness;
	}

	/**
	 * @description Point Thickness
	 * @param pointThickness
	 * @author Adam Knox
	 */
	public void setPointThickness(int pointThickness) {
		this.pointThickness = pointThickness;
		GraphData.get().refresh();
	}

	/**
	 * @description sets the thickness of error bars on this line
	 * @param errorBarThickness
	 * @author Adam Knox
	 */
	public void setErrorBarThickness(int errorBarThickness) {
		this.errorBarThickness = errorBarThickness;
		GraphData.get().refresh();
	}

	/**
	 * PointVisible Getter
	 * 
	 * @return true if the point should be visible
	 */
	public boolean isPointVisible() {
		return pointVisible;
	}

	/**
	 * Point Visible Setter
	 * 
	 * @param pointVisible
	 *            true sets Point visible false sets to invisible
	 */
	public void setPointVisible(boolean pointVisible) {
		this.pointVisible = pointVisible;
		GraphData.get().refresh();
	}

	/**
	 * @description sets the point color
	 * @param R
	 *            red
	 * @param G
	 *            green
	 * @param B
	 *            blue
	 * @author Adam Knox
	 */
	public void setPointColor(int R, int G, int B) {
		this.pointColor = new Color(R, G, B);
		GraphData.get().refresh();
	}

	/**
	 * @description sets the line color
	 * @param R
	 *            red
	 * @param G
	 *            green
	 * @param B
	 *            blue
	 * @author Adam Knox
	 */
	public void setLineColor(int R, int G, int B) {
		this.lineColor = new Color(R, G, B);
		GraphData.get().refresh();
	}

	/**
	 * @description sets the error bar color
	 * @param R
	 *            red
	 * @param G
	 *            green
	 * @param B
	 *            blue
	 * @author Adam Knox
	 */
	public void setErrorBarColor(int R, int G, int B) {
		this.errorBarColor = new Color(R, G, B);
		GraphData.get().refresh();
	}

	/**
	 * @description sets the error bar color
	 * @param color
	 *            the color to use
	 * @author Adam Knox
	 */
	public void setErrorBarColor(Color color) {
		this.errorBarColor = color;
		GraphData.get().refresh();
	}

	/**
	 * Line name Setter
	 * 
	 * @param lineName
	 * @author Adam Knox
	 */
	public void setName(String lineName) {
		this.lineName = lineName;
		GraphData.get().refresh();
	}



	/**
	 * @description gets Data linked list of DataLine
	 * @return data linked list
	 * @author Adam Knox
	 */
	public LinkedList<DataPoint> getData() {
		if (data != null)
			return data;
		else
			return null;
	}

	/**
	 * Color Getter
	 * 
	 * @return color of error bar
	 * @author Adam Knox
	 */
	public Color getErrorBarColor() {
		return errorBarColor;
	}

	/**
	 * @description Error bar visibility indicator
	 * @return x error invisible
	 * @author Adam Knox
	 */
	public boolean isXErrorVisible() {
		return xErrorVisible;
	}

	/**
	 * @description Error bar visibility indicator
	 * @return y error invisible
	 * @author Adam Knox
	 */
	public boolean isYErrorVisible() {
		return yErrorVisible;
	}

	/**
	 * @description Error bar thickness Getter
	 * @return Error bar thickness
	 * @author Adam Knox
	 */
	public int getErrorBarThickness() {
		return errorBarThickness;
	}

	/**
	 * @description Show error cross hairs setter
	 * @param showErrorCrossHairs
	 *            true if visible false if invisible
	 * @author Adam Knox
	 */
	public void setShowErrorCrossHairs(boolean showErrorCrossHairs) {
		this.showErrorCrossHairs = showErrorCrossHairs;
	}

	/**
	 * @description Getter if cross hairs visible or not
	 * @return true if visible false if not
	 * @author Adam Knox
	 */
	public boolean isShowErrorCrossHairs() {
		return showErrorCrossHairs;
	}

	/**
	 * @description Setter Error box
	 * @param showErrorBox
	 *            true if visible false if not
	 * @author Adam Knox
	 */
	public void setShowErrorBox(boolean showErrorBox) {
		this.showErrorBox = showErrorBox;
	}

	/**
	 * @description Getter show Error box
	 * @return true if visible false if not
	 */
	public boolean isShowErrorBox() {
		return showErrorBox;
	}

	public static void main(String[] args) {
		DataSet myline = new DataSet();
		myline.addPointOrdered(new DataPoint(1, 11));

		myline.addPointOrdered(new DataPoint(5, 55));
		myline.addPointOrdered(new DataPoint(3, 33));
		myline.addPointOrdered(new DataPoint(2, 22));
		myline.addPointOrdered(new DataPoint(4, 44));

		System.out.println(myline.toString());

	}

}

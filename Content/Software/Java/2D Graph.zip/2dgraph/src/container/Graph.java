package container;
/**
 * @description Main Graph entity to be manipulated
 */
import java.text.DecimalFormat;
import java.util.*;

import GUI.MainWindow;
import analysisTools.Calculus;
import analysisTools.Regression;
import enumerations.CalcTypes;
import enumerations.RegTypes;

public class Graph {
	// GRAPH VARIABLES
	private boolean refresh;

	private int scaleX;
	private int scaleY;

	private String name;

	private String xName;
	private String xFormat;

	private String yName;
	private String yFormat;

	private String regFormat;
	// contains the text currently displayed below the plot
	private String plotText; 
	// list of currently existing data lines
	private LinkedList<DataSet> lines;

	private DecimalFormat xNotation;
	private DecimalFormat yNotation;
	private DecimalFormat regNotation;

	private double hPadding;

	// CONSTRUCTOR
	/**
	 * @description constructor
	 */
	public Graph() {
		resetGraph();
	}
	
	
	/**
	 * @description creates a line depicting a regression equation
	 * @param index the line the regression is done on
	 * @param regType the type of regression to plot the equation for
	 * @param order if a polynomial, then the polynomial order, otherwise anything
	 */
	public void createRegSet(int index, RegTypes regType, int order) {
		// find the unusable points
		int shift = 0;
		int zeroSet = 0;
		for (int i = 0; i < this.getLine(index).size(); i++) {
			if ((this.getLine(index).get(i).getX() == 0)
					|| (this.getLine(index).get(i).getY() == 0)) {
				zeroSet = 1;
				shift++;
			}
		}

		boolean run = false;
		// run the regression so that an equation is available
		if (regType == RegTypes.polynomial) {
			this.runRegression(index, regType, order);
			run = true;

			// make sure unusable points don't allow the plot to run.
			// since polynomial can handle one point at (0, y), we use
			// zeroShift to account for this
			if (this.getLine(index).size() < 2 + shift - zeroSet) {
				run = false;
			}
		} else {
			this.runRegression(index, regType);
			run = true;

			// make sure unusable points don't allow the plot to run. since
			// linear can handle one point at (0, y), we use zeroShift to
			// account for this
			if (regType != RegTypes.linear)
				zeroSet = 0;

			if (this.getLine(index).size() < 2 + shift - zeroSet) {
				run = false;
			}
		}

		if (run) {

			// find an available name
			String name = "";
			if (regType == RegTypes.polynomial) {
				name = "order " + order + " polynomial regression on "
						+ this.getLine(index).getName();
			} else {
				name = regType.toString()+ " regression on " + this.getLine(index).getName();
			}

			String finalName = name;
			int count = 1;
			for (int i = 0; i < this.numLines(); i++) {
				if (this.getLine(i).getName().equals(finalName)) {
					finalName = name + " dup";
					count++;
					i = 0;
				}
			}

			// add a new data set
			MainWindow.lineInfoWindow.addLine(finalName);
			HashMap<String, Double> regData;

			// get the proper set of regression data
			if (regType == RegTypes.linear) {
				regData = this.getLine(index).getRegData(RegTypes.linear);
			} else if (regType == RegTypes.logarithmic) {
				regData = this.getLine(index).getRegData(RegTypes.logarithmic);
			} else if (regType == RegTypes.polynomial) {
				regData = this.getLine(index).getRegData(RegTypes.polynomial);
			} else if (regType == RegTypes.exponential) {
				regData = this.getLine(index).getRegData(RegTypes.exponential);
			} else {
				regData = this.getLine(index).getRegData(RegTypes.power);
			}

			// populate the data set with points
			for (int i = 0; i < this.getLine(index).getDataSize(); i++) {
				double x = this.getLine(index).get(i).getX();
				double y = 0;

				// use the proper formula according to the proper regression
				// for finding the points
				if (regType == RegTypes.linear) {
					y = regData.get("B0") + x * regData.get("B1");

					// plot the point
					DataPoint point = new DataPoint(x, y);
					this.getLine(this.numLines() - 1).addPointOrdered(point);

				} else if (regType == RegTypes.logarithmic) {
					if (x > 0) {
						y = regData.get("A") + Math.log(x) * regData.get("B");

						// plot the point
						DataPoint point = new DataPoint(x, y);
						this.getLine(this.numLines() - 1).addPointOrdered(point);
					}

				} else if (regType == RegTypes.polynomial) {

					if (regData.get("power") > 0) {
						y += regData.get("B0") + regData.get("B1") * x;
					} else {
						y += regData.get("B0");
					}

					for (int j = 2; j <= regData.get("power"); j++) {
						y += regData.get("B" + j) * Math.pow(x, j);
					}

					// plot the point
					DataPoint point = new DataPoint(x, y);
					this.getLine(this.numLines() - 1).addPointOrdered(point);

				} else if (regType == RegTypes.exponential) {
					y = regData.get("A") * Math.exp(x * regData.get("B"));

					// plot the point
					DataPoint point = new DataPoint(x, y);
					this.getLine(this.numLines() - 1).addPointOrdered(point);

				} else if (regType == RegTypes.power) {
					y = regData.get("A") * Math.pow(x, regData.get("B"));

					// plot the point
					DataPoint point = new DataPoint(x, y);
					this.getLine(this.numLines() - 1).addPointOrdered(point);

				}
			}
		}
	}
	
	
	

	/**
	 * @description cleans out all the existing data in Graph, and puts the
	 *              default values back in
	 * @author Adam Knox
	 */
	public void resetGraph() {
		// reset the plot name
		name = "Graph Title";

		// reset the y axis
		yName = "y";
		scaleY = 11;
		yFormat = "#0.0";

		// reset the x axis
		xName = "x";
		scaleX = 11;
		xFormat = "#0.0";
		
		regFormat = "0.00E0";

		// clear the text below the plot
		plotText = "";

		// re-initialise the lines
		lines = new LinkedList<DataSet>();
		lines.add(new DataSet());

		// reset notation
		xNotation = new DecimalFormat();
		yNotation = new DecimalFormat();
		regNotation = new DecimalFormat();
		xNotation.applyLocalizedPattern(xFormat);
		yNotation.applyLocalizedPattern(yFormat);
		regNotation.applyLocalizedPattern(regFormat);

		hPadding = 60;

		// refresh the data to show the now empty graph
		refresh = true;
	}

	/**
	 * @description runs the requested regression on the requested data, and
	 *              updates Graph with the new information
	 * @param lineNumber
	 *            lineNumber the line to run the regression on
	 * @param regType
	 *            regType the regression method to run
	 * @param power
	 *            the power of the polynomial
	 * @author Adam Knox
	 */
	public void runRegression(int lineNumber, RegTypes regType, int power) {
		if ((regType == RegTypes.polynomial) && (lineNumber >= 0) && (lineNumber < lines.size())) {
			// run the new regression
			HashMap<String, Double> newRegData;	
			newRegData = Regression.Run(regType, this.getLine(lineNumber), power);

			// remove the old coefficient values, but only if the regression has
			// previously been run
			if (this.getLine(lineNumber).getRegData(regType).get("power") != null) {
				for (int i = 0; i <= this.getLine(lineNumber).getRegData(regType).get("power"); i++) {
					this.getLine(lineNumber).getRegData(regType).remove("B" + i);
				}
			}

			// add the new coefficient values
			for (int i = 0; i <= newRegData.get("power"); i++) {
				this.getLine(lineNumber).getRegData(regType).put("B" + i, newRegData.get("B" + i));
			}

			// add the new analysis values
			this.getLine(lineNumber).getRegData(regType).put("power", newRegData.get("power"));
			this.getLine(lineNumber).getRegData(regType).put("stdev", newRegData.get("stdev"));
			this.getLine(lineNumber).getRegData(regType).put("var", newRegData.get("var"));
			this.getLine(lineNumber).getRegData(regType).put("R^2", newRegData.get("R^2"));
			this.getLine(lineNumber).getRegData(regType).put("adj R^2", newRegData.get("adj R^2"));

			// refresh output string with the new data
			this.getLine(lineNumber).updateRegString(lineNumber);
		} else  if ((regType != RegTypes.polynomial) && (lineNumber >= 0) && (lineNumber < lines.size())) {
			runRegression(lineNumber, regType);
		}
	}

	/**
	 * @description runs the requested regression on the requested data, and
	 *              updates Graph with the new information
	 * @param lineNumber
	 *            the line to run the regression on
	 * @param regType
	 *            the regression method to run
	 * @author Adam Knox
	 */
	public void runRegression(int lineNumber, RegTypes regType) {
		if ((regType != RegTypes.polynomial) && (lineNumber >= 0) && (lineNumber < lines.size())) {
			// run the new regression
			HashMap<String, Double> newRegData;
			newRegData = Regression.Run(regType, this.getLine(lineNumber));

			// update the regression data
			if (regType == RegTypes.linear) {
				this.getLine(lineNumber).getRegData(regType).put("B0", newRegData.get("B0"));
				this.getLine(lineNumber).getRegData(regType).put("B1", newRegData.get("B1"));
			} else {
				this.getLine(lineNumber).getRegData(regType).put("A", newRegData.get("A"));
				this.getLine(lineNumber).getRegData(regType).put("B", newRegData.get("B"));
			}

			this.getLine(lineNumber).getRegData(regType).put("stdev", newRegData.get("stdev"));
			this.getLine(lineNumber).getRegData(regType).put("var", newRegData.get("var"));
			this.getLine(lineNumber).getRegData(regType).put("R^2", newRegData.get("R^2"));
			this.getLine(lineNumber).getRegData(regType).put("adj R^2", newRegData.get("adj R^2"));

			// refresh output string with the new data
			this.getLine(lineNumber).updateRegString(lineNumber);
		}
	}

	/**
	 * @description runs the requested calculus operation on the requested data,
	 *              and updates Graph with the new information
	 * @param lineNumber
	 *            the line to run the operation on
	 * @param regType
	 *            the regression method to run
	 * @param calcType
	 *            the operation to run
	 * @param pointA
	 *            the point to run the operation on
	 * @author Adam Knox
	 */
	public void showCalculus(int lineNumber, RegTypes regType, CalcTypes calcType, double pointA) {
		this.runRegression(lineNumber, regType);
		if (calcType == CalcTypes.derivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Derivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "derivative");
		} else if (calcType == CalcTypes.secondDerivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.SecondDerivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "second derivative");
		}
	}

	/**
	 * @description runs the requested calculus operation on the requested data,
	 *              and updates Graph with the new information
	 * @param lineNumber
	 *            the line to run the operation on
	 * @param regType
	 *            the regression method to run
	 * @param calcType
	 *            the operation to run
	 * @param pointA
	 *            the starting point
	 * @param pointB
	 *            the ending point
	 * @author Adam Knox
	 */
	public void showCalculus(int lineNumber, RegTypes regType, CalcTypes calcType, double pointA, double pointB) {
		this.runRegression(lineNumber, regType);
		if (calcType == CalcTypes.derivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Derivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "derivative");
		} else if (calcType == CalcTypes.secondDerivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.SecondDerivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "second derivative");
		} else if (calcType == CalcTypes.integral) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Integral(regType, this.getLine(lineNumber).getRegData(regType), pointA, pointB), pointA, pointB);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "integral");
		}
	}

	/**
	 * @description runs the requested calculus operation on the requested data,
	 *              and updates Graph with the new information
	 * @param lineNumber
	 *            the line to run the operation on
	 * @param regType
	 *            the regression method to run
	 * @param calcType
	 *            the operation to run
	 * @param order
	 *            the polynomial order
	 * @param pointA
	 *            the point to run the operation on
	 * @author Adam Knox
	 */
	public void showCalculus(int lineNumber, RegTypes regType, CalcTypes calcType, int order, double pointA) {
		this.runRegression(lineNumber, regType, order);
		if (calcType == CalcTypes.derivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Derivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "derivative");
		} else if (calcType == CalcTypes.secondDerivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.SecondDerivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "second derivative");
		}
	}

	/**
	 * @description runs the requested calculus operation on the requested data,
	 *              and updates Graph with the new information
	 * @param lineNumber
	 *            the line to run the operation on
	 * @param regType
	 *            the regression method to run
	 * @param calcType
	 *            the operation to run
	 * @param order
	 *            the polynomial order
	 * @param pointA
	 *            the starting point
	 * @param pointB
	 *            the ending point
	 * @author Adam Knox
	 */
	public void showCalculus(int lineNumber, RegTypes regType, CalcTypes calcType, int order, double pointA, double pointB) {
		this.runRegression(lineNumber, regType, order);
		if (calcType == CalcTypes.derivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Derivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "derivative");
		} else if (calcType == CalcTypes.secondDerivative) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.SecondDerivative(regType, this.getLine(lineNumber).getRegData(regType), pointA), pointA);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "second derivative");
		} else if (calcType == CalcTypes.integral) {
			// add the calculus data to the line
			this.getLine(lineNumber).setCalcData(calcType, regType,
					Calculus.Integral(regType, this.getLine(lineNumber).getRegData(regType), pointA, pointB), pointA, pointB);
			// add the calculus item to the display list
			this.showRegItem(lineNumber, regType, "integral");
		}
	}

	/**
	 * @description hides the requested calculus item
	 * @param lineNumber
	 *            the index of the line to operate on
	 * @param regType
	 *            the regression method to operate on
	 * @param calcType
	 *            the calculus method to hide
	 * @author Adam Knox
	 */
	public void hideCalculus(int lineNumber, RegTypes regType, CalcTypes calcType) {
		// remove the calculus item from the display list
		if (calcType == CalcTypes.derivative)
			this.getLine(lineNumber).removeDisplayedRegItem(regType, "derivative");
		else if (calcType == CalcTypes.secondDerivative)
			this.getLine(lineNumber).removeDisplayedRegItem(regType, "second derivative");
		else if (calcType == CalcTypes.integral)
			this.getLine(lineNumber).removeDisplayedRegItem(regType, "integral");
	}

	/**
	 * @description hides the requested regression item
	 * @param lineNumber
	 *            the index of the line to operate on
	 * @param regType
	 *            the regression method to operate on
	 * @param value
	 *            the name of the stat to remove
	 * @author Adam Knox
	 */
	public void hideRegItem(int lineNumber, RegTypes regType, String value) {
		// remove the item from the display list
		this.getLine(lineNumber).removeDisplayedRegItem(regType, value);
	}
	
	
	

	/**
	 * @description shows the requested regression item
	 * @param lineNumber
	 *            the index of the line to operate on
	 * @param regType
	 *            the regression method to operate on
	 * @param value
	 *            the name of the stat to show
	 * @author Adam Knox
	 */
	public void showRegItem(int lineNumber, RegTypes regType, String value) {
		// adds the item to the display list
		this.getLine(lineNumber).setDisplayedRegItem(regType, value);
	}

	// REFRESHING THE PLOT
	/**
	 * @author Adam Knox
	 * @description called if data in Graph has been updated, and the plot image
	 *              needs refreshing
	 */
	public void refresh() {
		refresh = true;
	}

	/**
	 * @author Adam Knox
	 * @description called if the plot image has been refreshed
	 */
	public void refreshed() {
		refresh = false;
	}

	/**
	 * @author Adam Knox
	 * @description used to check if the plot needs refreshing
	 * @return true if the plot needs refreshing, false if it doesn't
	 */
	public boolean refreshStatus() {
		return refresh;
	}

	// OPERATE ON SCALE
	/**
	 * @description returns the scale of the x axis
	 * @return the scale of the x axis
	 * @author Adam Knox
	 */
	public int getScaleX() {
		return scaleX;
	}

	/**
	 * @description sets the scale of the x axis
	 * @param newScaleX
	 *            the scale to set the x axis to
	 * @author Amara
	 */
	public void setScaleX(int newScaleX) {
		scaleX = newScaleX;
		refresh(); // data has changed, so refresh the plot
	}

	/**
	 * @description gets the scale of the y axis
	 * @return the scale of the y axis
	 * @author Amara
	 */
	public int getScaleY() {
		return scaleY;
	}

	/**
	 * @description sets the scale of the y axis
	 * @param newScaleY
	 *            the scale to set the y axis to
	 * @author Amara
	 */
	public void setScaleY(int newScaleY) {
		scaleY = newScaleY;
		refresh(); // data has changed, so refresh the plot
	}

	// OPERATE ON PLOT NAME
	/**
	 * @description Sets the name of graph
	 * @param gotName
	 *            name of the graph
	 * @author Amara
	 */
	public void setName(String gotName) {
		name = gotName;
		refresh(); // data has changed, so refresh the plot
	}

	/**
	 * @description gets the name of the graph
	 * @return the name of the graph
	 * @author Adam Knox
	 */
	public String getName() {
		return name;
	}

	// OPERATE ON AXIS NAMES
	/**
	 * @description Sets the name of horizontal axis
	 * @param gotName
	 *            name to be set to
	 * @author Amara
	 */
	public void setXName(String gotName) {
		xName = gotName;
		refresh(); // data has changed, so refresh the plot
	}

	/**
	 * @description gets the name of the horizontal axis
	 * @return the name of horizontal axis
	 * @author Amara
	 */
	public String getXName() {
		return xName;
	}

	/**
	 * @description Sets the name of vertical axis
	 * @param gotName
	 *            nome of axis
	 * @author Amara
	 */
	public void setYName(String gotName) {
		yName = gotName;
		refresh(); // data has changed, so refresh the plot
	}

	/**
	 * @description gets the name of the vertical axis
	 * @return the name of vertical axis
	 * @author Amara
	 */
	public String getYName() {
		return yName;
	}

	// OPERATE ON AXIS NOTATIONS
	/**
	 * @description Sets notation of the x axis numbers
	 * @param gotFormat
	 *            format of each data point to print
	 * @author Adam Knox
	 */
	public void setXFormat(String gotFormat) {
		xFormat = gotFormat;
		xNotation.applyLocalizedPattern(xFormat);
	}

	/**
	 * @description Sets notation of y axis numbers
	 * @param gotFormat
	 *            format of each data point to print
	 * @author Adam Knox
	 */
	public void setYFormat(String gotFormat) {
		yFormat = gotFormat;
		yNotation.applyLocalizedPattern(yFormat);
	}

	/**
	 * @description gets the notation of x axis numbers
	 * @return the notation of x axis numbers
	 * @author Adam Knox
	 */
	public String getXFormat() {
		return xFormat;
	}

	/**
	 * @description gets the notation of y axis numbers
	 * @return the notation of y axis numbers
	 * @author Adam Knox
	 */
	public String getYFormat() {
		return yFormat;
	}

	/**
	 * @description formats the double using the x axis notation
	 * @param unformattedVal
	 *            the unformatted double
	 * @return the formatted value
	 * @author Adam Knox
	 */
	public String getXFormatted(double unformattedVal) {
		return xNotation.format(unformattedVal);
	}

	/**
	 * @description formats the double using the y axis notation
	 * @param unformattedVal
	 *            the unformatted double
	 * @return the formatted value
	 * @author Adam Knox
	 */
	public String getYFormatted(double unformattedVal) {
		return yNotation.format(unformattedVal);
	}
	
	/**
	 * @description formats the double using the regression text notation
	 * @param unformattedVal
	 *            the unformatted double
	 * @return the formatted value
	 * @author Adam Knox
	 */
	public String getRegFormatted(double unformattedVal) {
		return regNotation.format(unformattedVal);
	}

	/**
	 * @description gets the notation of regression numbers
	 * @return the notation of regression numbers
	 * @author Adam Knox
	 */
	public String getRegFormat() {
		return regFormat;
	}
	
	/**
	 * @description Sets notation of regression numbers
	 * @param gotFormat
	 *            format of each regression number
	 * @author Adam Knox
	 */
	public void setRegFormat(String regFormat) {
		this.regFormat = regFormat;
		regNotation.applyLocalizedPattern(this.regFormat);
		refresh();
	}

	// OPERATE ON PLOT TEXT
	/**
	 * @description sets the text to be displayed below the plot
	 * @author Adam Knox
	 */
	public void updatePlotText() {
		// update the text displayed below the graph with the updated material
		plotText = "";
		for (int i = 0; i < lines.size(); i++) {
			// update each line
			if (!(lines.get(i).getRegString().equals(""))) {
				plotText += lines.get(i).getRegString();
				plotText += "================\n";
			}
		}

		refresh(); // data has changed, so refresh the plot
	}

	/**
	 * @description gets the text that should be displayed below the plot
	 * @return the text that should be displayed below the plot
	 * @author Adam Knox
	 */
	public String getPlotText() {
		return plotText;
	}

	/**
	 * @author Adam Knox
	 * @description sets the plots horizontal padding
	 * @param d
	 *            the plots horizontal padding
	 */
	public void setHPadding(double d) {
		this.hPadding = d;
	}

	/**
	 * @author Adam Knox
	 * @description gets the plots horizontal padding
	 * @return the plots horizontal padding
	 */
	public double getHPadding() {
		return hPadding;
	}

	// OPERATE ON LINES
	/**
	 * @description returns the number of data lines in the plot
	 * @return the number of lines in existence
	 * @author Adam Knox
	 */
	public int numLines() {
		return lines.size();
	}



	/**
	 * @description returns the line found in the index of lines
	 * @param index
	 *            the line index
	 * @return returns found dataset
	 * @author Amara
	 */
	public DataSet getLine(int index) {

		return this.lines.get(index);
	}

	/**
	 * @description Adds a new line
	 * @author Amara
	 */
	public void addNewLine() {
		lines.add(new DataSet());
	}


	/**
	 * @description deletes a line
	 * @param index
	 *            the index of the line
	 * @return true if the line was deleted, false if it wasn't
	 * @author Amara
	 */
	public boolean deleteLine(int index) {

		try {
			lines.remove(index);
		} catch (Exception e) {

			return false;
		}
		return true;
	}


	// OPERATE ON POINTS IN THE SELECTED LINE
	/**
	 * @description Inserts x,y point into the graph's current line
	 * @param setIndex the index of the line to put the point in
	 * @param gotX
	 *            the x value of the point to insert
	 * @param gotY
	 *            the y value of the point to insert
	 * @author Amara
	 */
	public void insertPointSequential(int setIndex, double gotX, double gotY) {
		DataPoint newPoint = new DataPoint(gotX, gotY);
		lines.get(setIndex).addPointSequential(newPoint);
	}

	/**
	 * @description Inserts a point using the point position, and error bar data
	 * @param setIndex the index of the line to put the point in
	 * @param gotX
	 *            the x value of the point to insert
	 * @param gotY
	 *            the y value of the point to insert
	 * @author Adam Knox
	 */
	public void insertPointSequential(int setIndex, double gotX, double gotY, double eastError, double westError, double northError, double southError) {
		DataPoint newPoint = new DataPoint(gotX, gotY, eastError, westError, northError, southError);
		lines.get(setIndex).addPointSequential(newPoint);
	}

	/**
	 * @description Inserts x,y point into the graph's current line
	 * @param setIndex
	 *            the index of the line to add the points to
	 * @param gotX
	 *            the x value of the point to insert
	 * @param gotY
	 *            the y value of the point to insert
	 * @author Amara
	 */
	public void insertPointOrdered(int setIndex, double gotX, double gotY) {
		DataPoint newPoint = new DataPoint(gotX, gotY);
		lines.get(setIndex).addPointOrdered(newPoint);
	}

	/**
	 * @description Inserts a point using the point position, and error bar data
	 * @param setIndex
	 *            the index of the line to add the points to
	 * @param gotX
	 *            the x value of the point to insert
	 * @param gotY
	 *            the y value of the point to insert
	 * @author Adam Knox
	 */
	public void insertPointOrdered(int setIndex, double gotX, double gotY, double eastError, double westError, double northError, double southError) {
		DataPoint newPoint = new DataPoint(gotX, gotY, eastError, westError, northError, southError);
		lines.get(setIndex).addPointOrdered(newPoint);
	}

	/**
	 * @description Removes DataPoint from a given line
	 * @param setIndex
	 *            the line to remove the point form
	 * @param pointIndex
	 *            the location of the data point to be removed
	 * @return null if out of bounds of line else data point
	 * @author Adam Knox
	 */
	public DataPoint removePoint(int setIndex, int pointIndex) {
		if (this.lines.get(setIndex).size() <= pointIndex || 0 > pointIndex) {
			//System.out.println("array index out of bounds: " + pointIndex + " Size of graph: " + this.lines.get(setIndex).size());
			return null;
		}

		DataPoint removedPoint;
		removedPoint = this.lines.get(setIndex).remove(pointIndex);

		return removedPoint;
	}


	// TO STRING
	/**
	 * @author Adam Knox
	 * @description Returns string representation of all data in Graph
	 * @return the string containing all the data in Graph
	 */
	public String toString() {
		String rtString = "";

		/*
		 * Iterate through every dataset in lines list printing out all
		 * datasets
		 */

		if (lines.size() > 0) {
			for (int i = 0; i < lines.size(); i++) {
				rtString += lines.get(i).toString();
			}
		}

		// if any variables are null, then initialise them to contain nothing
		if (name == null) {
			name = "";
		}

		if (xFormat == null) {
			xFormat = "#0.0";
		}

		if (yFormat == null) {
			yFormat = "#0.0";
		}

		if (xName == null) {
			xName = "";
		}

		if (yName == null) {
			yName = "";
		}

		if (plotText == null) {
			plotText = "";
		}

		// get all the general graph data
		rtString += "GENERAL GRAPH DATA\n";
		rtString += "name_#2DGrapher#_" + name + "\n";
		rtString += "refresh_#2DGrapher#_" + refresh + "\n";
		rtString += "scaleX_#2DGrapher#_" + scaleX + "\n";
		rtString += "scaleY_#2DGrapher#_" + scaleY + "\n";
		rtString += "hPadding_#2DGrapher#_" + hPadding + "\n";
		rtString += "xFormat_#2DGrapher#_" + xFormat + "\n";
		rtString += "yFormat_#2DGrapher#_" + yFormat + "\n";
		rtString += "regFormat_#2DGrapher#_" + regFormat + "\n";
		rtString += "xName_#2DGrapher#_" + xName + "\n";
		rtString += "yName_#2DGrapher#_" + yName + "\n";
		rtString += "plotText_#2DGrapher#_" + plotText + "\n";
		rtString += "END OF GENERAL GRAPH DATA";

		return rtString;
	}
	
	
	
	/**
	 * @description Testing function
	 * @param args
	 */
	public static void main(String[] args) {
		Graph myGraph = new Graph();

		myGraph.insertPointSequential(0, 1, 11);
		myGraph.insertPointSequential(0, 2, 22);
		myGraph.insertPointSequential(0, 3, 33);
		myGraph.insertPointSequential(0, 4, 44);
		myGraph.insertPointSequential(0, 5, 55);
		myGraph.insertPointSequential(0, 6, 66);

		System.out.println(myGraph.toString());

		while (myGraph.getLine(0).size() > 0) {
			System.out.println("Removed: " + myGraph.removePoint(0, 0).toString());
		}

		System.out.println(myGraph.toString());
	}
}

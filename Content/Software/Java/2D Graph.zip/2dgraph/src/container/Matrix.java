package container;

/**
 * @description this is a data structure that simulates a matrix
 */
import java.util.LinkedList;

public class Matrix {
	private int w; // width of the matrix
	private int h; // height of the matrix
	private LinkedList<LinkedList<Double>> matrix; // matrix data points

	/**
	 * @author Adam Knox
	 * @description creates a new zero matrix of size newH, newW
	 * @param int newH the initial height of the new matrix
	 * @param int newW the initial width of the new matrix
	 */
	public Matrix(int newH, int newW) {
		matrix = new LinkedList<LinkedList<Double>>();

		for (int i = 0; i < newH; i++) {
			this.addRow();
		}

		for (int i = 0; i < newW; i++) {
			this.addCol();
		}
	}

	/**
	 * @author Adam Knox
	 * @description inserts a new row of zeros at the bottom of the matrix
	 */
	public void addRow() {
		// Add the row
		matrix.add(new LinkedList<Double>());

		// Fill the row with 0s
		for (int i = 0; i < w; i++) {
			matrix.get(h).add(0.0);
		}
		h++;
	}

	/**
	 * @author Adam Knox
	 * @description inserts a new column of zeros on the right side of the
	 *              matrix
	 * @WARNING: if the size of the matrix is 0x0, then addRow() must be called
	 *           before addCol()
	 */
	public void addCol() {
		for (int i = 0; i < h; i++) {
			matrix.get(i).add(0.0);
		}
		w++;
	}

	/**
	 * @author Adam Knox
	 * @description sets a point in the matrix to the required value
	 * @param y
	 *            vertical matrix position
	 * @param x
	 *            horizontal matrix position
	 * @param val
	 *            value to enter into the matrix
	 */
	public void set(int y, int x, double val) {
		matrix.get(y).set(x, val);
	}

	/**
	 * @author Adam Knox
	 * @description gets the value at a point in the matrix
	 * @param y
	 *            vertical matrix position
	 * @param x
	 *            horizontal matrix position
	 * @return the value at the point y,x in the matrix
	 */
	public double get(int y, int x) {
		return matrix.get(y).get(x);
	}

	/**
	 * @author Adam Knox
	 * @description outputs the matrix
	 */
	public String toString() {
		String retString = new String();
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				double item = matrix.get(y).get(x);
				retString += (item + " ");
			}
			retString += "\n";
		}
		retString += "\n";
		return retString;
	}

	/**
	 * @author Adam Knox
	 * @description gets the width of the matrix
	 * @return the matrix width
	 */
	public int getW() {
		return w;
	}

	/**
	 * @author Adam Knox
	 * @description gets the height of the matrix
	 * @return the matrix height
	 */
	public int getH() {
		return h;
	}

	/**
	 * @author Adam Knox
	 * @description tests the functionality of the class
	 */
	public static void main() {

		// Create a matrix
		/*
		 * 1 2 3 4 5 6 7 8 9
		 */

		Matrix A = new Matrix(3, 3);

		for (int i = 0; i < A.getH(); i++) {
			for (int j = 0; j < A.getW(); j++) {
				A.set(i, j, (j + 3 * i + 1));
			}
		}

		// Display the created matrix
		System.out.print(A.toString());
	}
}

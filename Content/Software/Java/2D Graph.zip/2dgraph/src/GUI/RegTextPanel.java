package GUI;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Printout for the Statistic Analysis. Below display panel.
 */
public class RegTextPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	public RegTextPanel() {
		this.setLayout(new GridLayout(1, 1));
		repaint();
	}

	public void repaint() {
		this.removeAll();

		JEditorPane jEditorPane = new JEditorPane();
		jEditorPane.setText(Controller.getGraph().getPlotText());

		jEditorPane.setPreferredSize(new Dimension(MainWindow.COLWIDTH - 10, jEditorPane.getHeight()));

		JScrollPane jScrollPane = new JScrollPane(jEditorPane);

		jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		jScrollPane.setVisible(true);

		this.add(jScrollPane);
		this.revalidate();
	}
}

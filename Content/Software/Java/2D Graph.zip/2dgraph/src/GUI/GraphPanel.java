package GUI;

import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.util.HashMap;

import javax.swing.*;

import plotInstance.GraphData;

/**
 * 
 * @author amd397 GraphPanel class displays a graphical representation of the
 *         plotted points and their respective datalines.
 */
public class GraphPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	// the padding on the left and right of the panel
	private double hPad = GraphData.get().getHPadding();
	// the padding on the top and bottom of the panel
	private final int VPAD = 50;

	// the fonts of the text displayed in the graph panel
	private Font font;
	private Font titleFont;
	private Font axisFont;

	// default values for the displayed graph data text
	private String titleX = Controller.getGraph().getXName();
	private String titleY = Controller.getGraph().getYName();
	private String titleGraph = Controller.getGraph().getName();

	// the set of the two smallest points in the set of all lines. used for
	// scaling
	private double minX = Double.MAX_VALUE;
	private double minY = Double.MAX_VALUE;

	// the set of the two largest points in the set of all lines. used for
	// scaling
	private double maxX = 0;
	private double maxY = 0;

	// spanX = maxX-minX; spanY = maxY-minY
	private double spanX = 0;
	private double spanY = 0;

	// the increment between ticks on the axes
	private double xInc;
	private double yInc;

	// the value of the origin ticks
	private double firstX;
	private double firstY;

	// the width and height of the display area
	private int panelWidth;
	private int panelHeight;

	// this Graphics2D instance
	private Graphics2D mainGraph;

	// Dictate the number of ticks on each axis
	private int numXTicks = Controller.getGraph().getScaleX();
	private int numYTicks = Controller.getGraph().getScaleY();
	// The length of each tick
	private static int TICK_LEN = 3;

	/**
	 * Constructor
	 * 
	 * @description initialises everything needed to run the plot dispaly
	 */
	public GraphPanel() {
		font = new Font("lucida sans regular", Font.PLAIN, 16);
		titleFont = new Font("times new roman", Font.BOLD, 16);
		axisFont = new Font("lucida sans regular", Font.PLAIN, 16);
		setBackground(Color.white);
	}

	/**
	 * @description gets the min, max, and span of y for the given data line
	 * @param lineNum
	 *            the number of the data line to get the data for
	 * @return the min, max, and span of y for the given data line
	 * @author amd397
	 */
	private void getDataValsY(int lineNum) {
		// runs through each point in the line
		for (int j = 0; j < Controller.getGraph().getLine(lineNum).size(); j++) {
			// check if the current point contains the smallest y value ever
			// found
			if (Controller.getGraph().getLine(lineNum).get(j).getY() < this.minY)
				this.minY = Controller.getGraph().getLine(lineNum).get(j).getY();

			// check if the current point contains the largest y value ever
			// found
			if (Controller.getGraph().getLine(lineNum).get(j).getY() > this.maxY)
				this.maxY = Controller.getGraph().getLine(lineNum).get(j).getY();
		}

		// calculate the new span using any updated variables
		this.spanY = this.maxY - this.minY;
	}

	/**
	 * @description gets the min, max, and span of x for the given data line
	 * @param lineNum
	 *            the number of the data line to get the data for
	 * @return the min, max, and span of x for the given data line
	 * @author amd397
	 */
	private void getDataValsX(int lineNum) {
		// runs through each point in the line
		for (int j = 0; j < Controller.getGraph().getLine(lineNum).size(); j++) {
			// check if the current point contains the smallest x value ever
			// found
			if (Controller.getGraph().getLine(lineNum).get(j).getX() < this.minX)
				this.minX = Controller.getGraph().getLine(lineNum).get(j).getX();

			// check if the current point contains the largest x value ever
			// found
			if (Controller.getGraph().getLine(lineNum).get(j).getX() > this.maxX)
				this.maxX = Controller.getGraph().getLine(lineNum).get(j).getX();
		}

		// calculate the new span using any updated variables
		this.spanX = maxX - minX;
	}

	public void refresh() {
		this.repaint();
	}

	/**
	 * @description paints the graph
	 * @param g
	 *            what to paint on
	 * @author Adam Knox /amd397
	 */
	protected void paintComponent(Graphics g) {
		// reset min and max so that resize can handle removal of points
		minX = Double.MAX_VALUE;
		minY = Double.MAX_VALUE;
		maxX = 0;
		maxY = 0;

		hPad = GraphData.get().getHPadding();
		titleX = Controller.getGraph().getXName();
		titleY = Controller.getGraph().getYName();
		titleGraph = Controller.getGraph().getName();
		numXTicks = Controller.getGraph().getScaleX();
		numYTicks = Controller.getGraph().getScaleY();

		// Render Graph
		super.paintComponent(g);
		mainGraph = (Graphics2D) g;
		mainGraph.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		mainGraph.setFont(font);
		FontRenderContext frc = mainGraph.getFontRenderContext();

		// Only repaint parts of the graph if at least 2 points exist
		boolean pointsExist = false;
		for (int i = 0; i < Controller.getGraph().numLines(); i++) {
			if (Controller.getGraph().getLine(i).size() >= 2) {
				pointsExist = true;
				i = Controller.getGraph().numLines();
			}
		}

		// set the panel size
		this.panelWidth = getWidth();
		this.panelHeight = getHeight();

		// set x and y spacing for axis ticks
		this.xInc = ((panelWidth - hPad - VPAD) / (numXTicks - 1));
		this.yInc = (panelHeight - 2 * VPAD) / (numYTicks - 1);

		// Calculate Dimension and span of Graph
		if (pointsExist == true) {
			for (int lineNum = 0; lineNum < Controller.getGraph().numLines(); lineNum++) {
				getDataValsY(lineNum);
				getDataValsX(lineNum);
			}
			// Not enough points, so fake a span
		} else {
			minX = 0;
			maxX = 10;
			minY = 0;
			maxY = 10;
			spanX = 10;
			spanY = 10;
		}

		// set X and Y tick spacings
		double xScale = (this.spanX / (numXTicks - 1));
		double yScale = (this.spanY / (numYTicks - 1));

		// Y AXIS
		// Draw Y-axis tick marks and associated labels
		mainGraph.draw(new Line2D.Double(hPad, VPAD, hPad, panelHeight - VPAD));
		double x1 = hPad, y1 = VPAD, x2 = hPad - TICK_LEN, y2;
		String text;
		LineMetrics lm;
		double xs, ys, textWidth, height;

		for (int j = 0; j < numYTicks; j++) {
			// Draw the tick line
			mainGraph.draw(new Line2D.Double(x1, y1, x2, y1));
			y1 += yInc;
			// Draw the tick's label
			text = String.valueOf(Controller.getGraph().getYFormatted(this.maxY - (j * yScale)));
			textWidth = font.getStringBounds(text, frc).getWidth();
			lm = font.getLineMetrics(text, frc);
			height = lm.getAscent();
			xs = hPad - textWidth - 7;
			ys = VPAD + (j * yInc) + height / 2;
			mainGraph.drawString(text, (float) xs, (float) ys);
		}
		// store the value the first y tick is at
		firstY = this.maxY - (numYTicks - 1) * yScale;

		// Draw the y-axis title
		mainGraph.setFont(axisFont);

		textWidth = font.getStringBounds(titleY, frc).getWidth();
		lm = font.getLineMetrics(titleY, frc);
		height = lm.getAscent();
		xs = height;
		ys = VPAD + (numYTicks / 2) * yInc + textWidth / 2;
		// draw the yTitle vertically
		label_line(mainGraph, (float) xs, (float) ys, -Math.PI / 2, titleY);
		mainGraph.setFont(font);

		// X AXIS
		// Draw X-axis tick marks and associated labels
		mainGraph.draw(new Line2D.Double(hPad, panelHeight - VPAD, panelWidth - VPAD, panelHeight - VPAD));

		x1 = hPad;
		y1 = panelHeight - VPAD;
		y2 = y1 + TICK_LEN;
		ys = panelHeight - VPAD;
		for (int j = 0; j < numXTicks; j++) {
			// Draw the tick line
			mainGraph.draw(new Line2D.Double(x1, y1, x1, y2));
			x1 += xInc;

			// Draw the tick's label
			text = String.valueOf(Controller.getGraph().getXFormatted(this.minX + (j * xScale))); // j
																								// +
																								// 1
			textWidth = font.getStringBounds(text, frc).getWidth();
			lm = font.getLineMetrics(text, frc);
			height = lm.getHeight();
			xs = hPad + j * xInc - textWidth / 2;
			mainGraph.drawString(text, (float) xs, (float) (ys + height));
		}

		// store the value the first x tick is at
		firstX = this.minX;

		// Draw the x-axis title
		mainGraph.setFont(axisFont);
		textWidth = font.getStringBounds(titleX, frc).getWidth();
		lm = font.getLineMetrics(titleX, frc);
		height = lm.getHeight();
		xs = (hPad + (numXTicks / 2) * xInc - textWidth / 2);
		mainGraph.drawString(titleX, (float) xs, (float) (ys + 2 * height));

		// GRAPH
		// Draw the graph title above the plot
		mainGraph.setFont(titleFont);
		textWidth = font.getStringBounds(titleGraph, frc).getWidth();
		lm = font.getLineMetrics(titleGraph, frc);
		height = lm.getHeight();
		xs = (hPad + (numXTicks / 2) * xInc - textWidth / 2);
		ys = VPAD - 20;
		mainGraph.drawString(titleGraph, (float) xs, (float) ys);
		mainGraph.setFont(font);

		// Draw each line
		for (int lineNum = 0; lineNum < Controller.getGraph().numLines(); lineNum++) {
			plotData(mainGraph, lineNum);
		}

	}

	// From
	// http://www.velocityreviews.com/forums/t139758-vertical-draw-text-not-working-in-graphics2d.html
	private void label_line(Graphics g, double x, double y, double theta, String label) {
		Graphics2D g2D = (Graphics2D) g;

		// Create a rotation transformation for the font.
		AffineTransform fontAT = new AffineTransform();

		// get the current font
		Font theFont = g2D.getFont();

		// Derive a new font using a rotatation transform
		fontAT.rotate(theta);
		Font theDerivedFont = theFont.deriveFont(fontAT);

		// set the derived font in the Graphics2D context
		g2D.setFont(theDerivedFont);

		// Render a string using the derived font
		g2D.drawString(label, (int) x, (int) y);

		// put the original font back
		g2D.setFont(theFont);
	}

	/**
	 * @description plots the points for the given line number in the given
	 *              panel
	 * @param mainGraph
	 *            the panel to put the points in
	 * @param lineNum
	 *            the line number to use for accessing the points
	 * @author Adam Knox
	 */
	public void plotData(Graphics2D mainGraph, int lineNum) {
		double xPoint, yPoint;
		int j = 0;

		// set the current scale for distance between two points
		double yScale = (((panelHeight - 2 * VPAD) / this.spanY));
		double xScale = (((panelWidth - hPad - VPAD) / this.spanX));

		// create structure to store locations to draw the objects
		HashMap<String, Double> pointLocations = new HashMap<String, Double>();

		// get all of the point locations
		for (j = 0; j < Controller.getGraph().getLine(lineNum).size(); j++) {
			// shift points to start from proper location on screen
			xPoint = -1 * firstX * xScale + hPad;
			yPoint = (panelHeight - VPAD + firstY * yScale);

			// set point with adjustment
			xPoint += Controller.getGraph().getLine(lineNum).get(j).getX() * xScale;
			yPoint -= Controller.getGraph().getLine(lineNum).get(j).getY() * yScale;

			// draw the point
			pointLocations.put(j + ":x", xPoint);
			pointLocations.put(j + ":y", yPoint);
		}

		// draw error bars
		for (j = 0; j < Controller.getGraph().getLine(lineNum).size(); j++) {
			drawErrorBar(lineNum, j, pointLocations.get(j + ":x"), pointLocations.get(j + ":y"), xScale, yScale);
		}

		// draw lines
		if (Controller.getGraph().getLine(lineNum).isLineVisible()) {
			for (j = 1; j < Controller.getGraph().getLine(lineNum).size(); j++) {
				drawLineConnectPts(lineNum, pointLocations.get(j + ":x"), pointLocations.get(j + ":y"), pointLocations.get((j - 1) + ":x"),
						pointLocations.get((j - 1) + ":y"));
			}
		}

		// draw points
		if (Controller.getGraph().getLine(lineNum).isPointVisible()) {
			for (j = 0; j < Controller.getGraph().getLine(lineNum).size(); j++) {
				drawPoint(lineNum, pointLocations.get(j + ":x"), pointLocations.get(j + ":y"));
			}
		}

	}

	/**
	 * Draw Line between Points ie connect Points
	 * 
	 * @param lineNum
	 *            number to associate with
	 * @param x1
	 *            point
	 * @param y1
	 *            point
	 * @param xPrev
	 *            previous point
	 * @param yPrev
	 *            previous point
	 * @author amd397
	 */
	public void drawLineConnectPts(int lineNum, double x1, double y1, double xPrev, double yPrev) {
		Line2D.Double lineToDraw;
		mainGraph.setStroke(new BasicStroke(Controller.getGraph().getLine(lineNum).getLineThickness()));
		mainGraph.setColor(Controller.getGraph().getLine(lineNum).getLineColor());
		lineToDraw = new Line2D.Double(x1, y1, xPrev, yPrev);
		mainGraph.draw(lineToDraw);

	}

	/**
	 * Draw graphical point representation
	 * 
	 * @param lineNum
	 *            number to associate with
	 * @param x1
	 *            point
	 * @param y1
	 *            point
	 * @author amd397
	 */

	public void drawPoint(int lineNum, double x1, double y1) {
		// Plotting Points (Draw a single point )
		mainGraph.setColor(Controller.getGraph().getLine(lineNum).getPointColor());
		mainGraph.setStroke(new BasicStroke(Controller.getGraph().getLine(lineNum).getPointThickness()));

		Ellipse2D.Double singlePoint = new Ellipse2D.Double(x1 - (Controller.getGraph().getLine(lineNum).getPointThickness() / 2), y1
				- (Controller.getGraph().getLine(lineNum).getPointThickness() / 2), Controller.getGraph().getLine(lineNum).getPointThickness(),
				Controller.getGraph().getLine(lineNum).getPointThickness());
		// this.setToolTipText(text)

		mainGraph.draw(singlePoint);

		mainGraph.fill(singlePoint);
	}

	/**
	 * Draw Error bars
	 * 
	 * @param point
	 *            number in the line
	 * @param lineNum
	 *            number to associate with
	 * @param x1
	 *            point
	 * @param y1
	 *            point
	 * @param xScale
	 *            x scale
	 * @param yScale
	 *            y scale
	 */
	public void drawErrorBar(int lineNum, int point, double x1, double y1, double xScale, double yScale) {
		// set error bar characteristics
		mainGraph.setStroke(new BasicStroke(Controller.getGraph().getLine(lineNum).getErrorBarThickness()));
		mainGraph.setColor(Controller.getGraph().getLine(lineNum).getErrorBarColor());

		double nLen = Controller.getGraph().getLine(lineNum).getData().get(point).getErrorNorth();
		double sLen = Controller.getGraph().getLine(lineNum).getData().get(point).getErrorSouth();
		double eLen = Controller.getGraph().getLine(lineNum).getData().get(point).getErrorEast();
		double wLen = Controller.getGraph().getLine(lineNum).getData().get(point).getErrorWest();

		// Draw bars for vertical errors
		if (Controller.getGraph().getLine(lineNum).isYErrorVisible()) {
			// Draw Northern Error Bar
			if (nLen >= 0) {
				// Draw cross hares
				if (Controller.getGraph().getLine(lineNum).isShowErrorCrossHairs()) {
					Line2D.Double errorNorth = new Line2D.Double(x1, y1, x1, (y1 - yScale * nLen));
					mainGraph.draw(errorNorth);
				}

				// Draw Box
				if (Controller.getGraph().getLine(lineNum).isShowErrorBox()) {
					if (eLen > 0) {
						Line2D.Double errorNorthTL = new Line2D.Double((x1 - xScale * eLen), (y1 - yScale * nLen), x1, (y1 - yScale * nLen));
						mainGraph.draw(errorNorthTL);
					}
					if (wLen > 0) {
						Line2D.Double errorNorthTR = new Line2D.Double(x1, (y1 - yScale * nLen), (x1 + xScale * wLen), (y1 - yScale * nLen));
						mainGraph.draw(errorNorthTR);
					}
				}
			}

			// Draw Southern Error Bar
			if (sLen >= 0) {
				// Draw cross hares
				if (Controller.getGraph().getLine(lineNum).isShowErrorCrossHairs()) {
					Line2D.Double errorSouth = new Line2D.Double(x1, y1, x1, (y1 + yScale * sLen));
					mainGraph.draw(errorSouth);
				}

				// Draw Box
				if (Controller.getGraph().getLine(lineNum).isShowErrorBox()) {
					if (eLen > 0) {
						Line2D.Double errorNorthTL = new Line2D.Double((x1 - xScale * eLen), (y1 + yScale * sLen), x1, (y1 + yScale * sLen));
						mainGraph.draw(errorNorthTL);
					}
					if (wLen > 0) {
						Line2D.Double errorNorthTR = new Line2D.Double(x1, (y1 + yScale * sLen), (x1 + xScale * wLen), (y1 + yScale * sLen));
						mainGraph.draw(errorNorthTR);
					}
				}
			}
		}

		// Draw bars for horizontal errors
		if (Controller.getGraph().getLine(lineNum).isXErrorVisible()) {
			// Draw Error East
			if (eLen >= 0) {
				// Draw cross hares
				if (Controller.getGraph().getLine(lineNum).isShowErrorCrossHairs()) {
					Line2D.Double errorEast = new Line2D.Double(x1, y1, (x1 - xScale * eLen), y1);
					mainGraph.draw(errorEast);
				}

				// Draw Box
				if (Controller.getGraph().getLine(lineNum).isShowErrorBox()) {
					if (nLen > 0) {
						Line2D.Double errorEastTL = new Line2D.Double((x1 - xScale * eLen), (y1 - yScale * nLen), (x1 - xScale * eLen), y1);
						mainGraph.draw(errorEastTL);
					}
					if (sLen > 0) {
						Line2D.Double errorEastTR = new Line2D.Double((x1 - xScale * eLen), y1, (x1 - xScale * eLen), (y1 + yScale * sLen));
						mainGraph.draw(errorEastTR);
					}
				}
			}

			// Draw Error West
			if (wLen >= 0) {
				// Draw cross hares
				if (Controller.getGraph().getLine(lineNum).isShowErrorCrossHairs()) {
					Line2D.Double errorWest = new Line2D.Double(x1, y1, (x1 + xScale * wLen), y1);
					mainGraph.draw(errorWest);
				}

				// Draw Box
				if (Controller.getGraph().getLine(lineNum).isShowErrorBox()) {
					if (nLen > 0) {
						Line2D.Double errorEastTL = new Line2D.Double((x1 + xScale * wLen), (y1 - yScale * nLen), (x1 + xScale * wLen), y1);
						mainGraph.draw(errorEastTL);
					}
					if (sLen > 0) {
						Line2D.Double errorEastTR = new Line2D.Double((x1 + xScale * wLen), y1, (x1 + xScale * wLen), (y1 + yScale * sLen));
						mainGraph.draw(errorEastTR);
					}
				}
			}
		}
	}

	/**
	 * @description test function
	 * @param args
	 */
	public static void main(String[] args) {

		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GraphPanel mainGraph = new GraphPanel();
		Controller.getGraph().setName("2D Grapher Test Graph");
		Controller.getGraph().setXName("Peace Out");
		Controller.getGraph().setYName("A-Town");

		// ExportPlot.exportPlot(mainGraph, "testing", "jpg", 3000, 3000);

		f.getContentPane().add(mainGraph);

		f.setSize(1000, 1000);
		f.setLocation(200, 200);
		f.setVisible(true);

		Controller.getGraph().insertPointOrdered(0, 1, 1, 5, 5, 5, 5);
		Controller.getGraph().insertPointOrdered(0, 2, 2, 5, 5, 5, 5);
		Controller.getGraph().insertPointOrdered(0, 3, 3, 5, 5, 5, 5);
		Controller.getGraph().insertPointOrdered(0, 4, 4, 5, 5, 5, 5);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(1, 1, 2, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(1, 1.5, 4, 2, 2, 2, 2);
		Controller.getGraph().insertPointOrdered(1, 2, 6, 3, 3, 3, 3);
		Controller.getGraph().insertPointOrdered(1, 2.5, 8, 3, 3, 3, 3);
		Controller.getGraph().insertPointOrdered(1, 3, 10, 4, 4, 4, 4);
		Controller.getGraph().insertPointOrdered(1, 3.5, 12, 4, 4, 4, 4);
		Controller.getGraph().insertPointOrdered(1, 4, 14, 4, 4, 4, 4);
		Controller.getGraph().insertPointOrdered(1, 4.5, 16, 3, 3, 3, 3);
		Controller.getGraph().insertPointOrdered(1, 5, 18, 2, 2, 2, 2);
		Controller.getGraph().insertPointOrdered(1, 5.5, 20, 1, 1, 1, 1);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(2, 3, 6, 4, 4, 2, 2);
		Controller.getGraph().insertPointOrdered(2, 4, 12, 4, 4, 2, 2);
		Controller.getGraph().insertPointOrdered(2, 5, 18, 4, 4, 2, 2);
		Controller.getGraph().insertPointOrdered(2, 6, 24, 4, 4, 2, 2);
		Controller.getGraph().insertPointOrdered(2, 7, 30, 4, 4, 2, 2);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(3, 8, 15, 4, 2, 4, 2);
		Controller.getGraph().insertPointOrdered(3, 9, 14, 2, 4, 2, 4);
		Controller.getGraph().insertPointOrdered(3, 10, 13, 4, 2, 4, 2);
		Controller.getGraph().insertPointOrdered(3, 11, 12, 2, 4, 3, 4);
		Controller.getGraph().insertPointOrdered(3, 12, 11, 4, 2, 4, 2);
		Controller.getGraph().insertPointOrdered(3, 13, 10, 2, 4, 2, 4);
		Controller.getGraph().insertPointOrdered(3, 15, 9, 4, 2, 4, 2);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(4, 5, 2, 1.1, 1.2, 1.3, 1.4);
		Controller.getGraph().insertPointOrdered(4, 7, 3, 1.5, 1.6, 1.7, 1.8);
		Controller.getGraph().insertPointOrdered(4, 9, 4, 1.9, 1.10, 1.11, 12);
		Controller.getGraph().insertPointOrdered(4, 11, 5, 1.13, 1.14, 1.15, 1.16);
		Controller.getGraph().insertPointOrdered(4, 13, 6, 1.17, 1.18, 1.19, 1.20);
		Controller.getGraph().insertPointOrdered(4, 15, 7, 1.21, 1.22, 1.23, 1.24);
		Controller.getGraph().insertPointOrdered(4, 17, 8, 1.25, 1.26, 1.27, 1.28);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(5, 19, 7, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 21, 6, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 23, 5, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 24, 4, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 25, 3, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 27, 2, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(5, 30, 1, 1, 1, 1, 1);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(6, 1, 0.25, 5, 5, 5, 5);
		Controller.getGraph().insertPointOrdered(6, 3, 0.5, 4, 4, 4, 4);
		Controller.getGraph().insertPointOrdered(6, 5, 0.75, 3, 3, 3, 3);
		Controller.getGraph().insertPointOrdered(6, 7, 1, 2, 2, 2, 2);
		Controller.getGraph().insertPointOrdered(6, 8, 1.25, 1, 1, 1, 1);
		Controller.getGraph().insertPointOrdered(6, 9, 1.5, 0, 0, 0, 0);

		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointOrdered(7, 3, 1);
		Controller.getGraph().insertPointOrdered(7, 4, 2);
		Controller.getGraph().insertPointOrdered(7, 5, 4);
		Controller.getGraph().insertPointOrdered(7, 6, 8);
		Controller.getGraph().insertPointOrdered(7, 7, 16);
		Controller.getGraph().insertPointOrdered(7, 8, 32);

		Controller.getGraph().getLine(0).setLineVisible(true);

		Controller.getGraph().getLine(0).setLineThickness(1);
		Controller.getGraph().getLine(0).setLineColor(Color.PINK);

		Controller.getGraph().getLine(1).setLineVisible(true);
		Controller.getGraph().getLine(1).setPointVisible(true);
		Controller.getGraph().getLine(1).setXErrorVisible(true);
		Controller.getGraph().getLine(1).setYErrorVisible(true);

		Controller.getGraph().getLine(1).setLineThickness(1);
		Controller.getGraph().getLine(1).setPointThickness(2);
		Controller.getGraph().getLine(1).setPointColor(Color.ORANGE);
		Controller.getGraph().getLine(1).setLineColor(Color.PINK);

		Controller.getGraph().getLine(2).setLineVisible(true);
		Controller.getGraph().getLine(2).setPointVisible(true);
		Controller.getGraph().getLine(2).setXErrorVisible(true);
		Controller.getGraph().getLine(2).setYErrorVisible(true);

		Controller.getGraph().getLine(2).setErrorBarThickness(1);
		Controller.getGraph().getLine(2).setLineThickness(2);
		Controller.getGraph().getLine(2).setPointThickness(3);
		Controller.getGraph().getLine(2).setErrorBarColor(Color.GREEN);
		Controller.getGraph().getLine(2).setPointColor(Color.ORANGE);
		Controller.getGraph().getLine(2).setLineColor(Color.PINK);

		Controller.getGraph().getLine(3).setPointVisible(true);
		Controller.getGraph().getLine(3).setXErrorVisible(true);
		Controller.getGraph().getLine(3).setYErrorVisible(true);
		Controller.getGraph().getLine(3).setShowErrorBox(false);

		Controller.getGraph().getLine(3).setLineThickness(2);
		Controller.getGraph().getLine(3).setErrorBarThickness(2);
		Controller.getGraph().getLine(3).setErrorBarColor(Color.CYAN);

		Controller.getGraph().getLine(4).setXErrorVisible(true);
		Controller.getGraph().getLine(4).setYErrorVisible(true);
		Controller.getGraph().getLine(4).setShowErrorCrossHairs(false);

		Controller.getGraph().getLine(4).setLineThickness(1);
		Controller.getGraph().getLine(4).setErrorBarThickness(6);
		Controller.getGraph().getLine(4).setErrorBarColor(Color.RED);

		Controller.getGraph().getLine(5).setPointVisible(true);
		Controller.getGraph().getLine(5).setXErrorVisible(true);
		Controller.getGraph().getLine(5).setYErrorVisible(true);

		Controller.getGraph().getLine(5).setLineThickness(1);
		Controller.getGraph().getLine(5).setErrorBarThickness(4);
		Controller.getGraph().getLine(5).setErrorBarColor(Color.PINK);

		Controller.getGraph().getLine(6).setLineVisible(true);
		Controller.getGraph().getLine(6).setYErrorVisible(true);
		Controller.getGraph().getLine(6).setXErrorVisible(true);
		Controller.getGraph().getLine(6).setYErrorVisible(true);
		Controller.getGraph().getLine(6).setShowErrorCrossHairs(false);

		Controller.getGraph().getLine(6).setLineThickness(2);
		Controller.getGraph().getLine(6).setErrorBarThickness(2);
		Controller.getGraph().getLine(6).setErrorBarColor(Color.YELLOW);

		Controller.getGraph().getLine(7).setLineVisible(true);
		Controller.getGraph().getLine(7).setXErrorVisible(true);
		Controller.getGraph().getLine(7).setYErrorVisible(true);
		Controller.getGraph().getLine(7).setShowErrorBox(false);

		Controller.getGraph().getLine(7).setLineThickness(10);
		Controller.getGraph().getLine(7).setErrorBarThickness(1);
		Controller.getGraph().getLine(7).setErrorBarColor(Color.GRAY);

	}
}

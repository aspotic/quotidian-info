package GUI;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * @author dwp726, ark043 This in the window that allows for the input of all
 *         the information pertaining directly to the graph
 */
public class GraphInfoWindow extends JFrame {

	private final JTextField title = new JTextField(Controller.getGraph().getName());
	private final JTextField xformat = new JTextField(Controller.getGraph().getXFormat());
	private final JTextField yformat = new JTextField(Controller.getGraph().getYFormat());
	private final JTextField regformat = new JTextField(Controller.getGraph().getRegFormat());
	private final JTextField yName = new JTextField(Controller.getGraph().getYName());
	private final JTextField xName = new JTextField(Controller.getGraph().getXName());
	private final JTextField yUnits = new JTextField(Integer.toString(Controller.getGraph().getScaleY()));
	private final JTextField xUnits = new JTextField(Integer.toString(Controller.getGraph().getScaleX()));
	private final JTextField hPadding = new JTextField(Double.toString(Controller.getGraph().getHPadding()));

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 */
	public GraphInfoWindow() {
		// create focus listeners to highlight box text when a box is clicked
		title.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		/*
		 * Focus Listeners allow for immediate text selection instead of
		 * highlighting
		 */
		yformat.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		xformat.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		regformat.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		yName.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		xName.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				regformat.selectAll();
			}
		});

		// create focus and action listeners for xunits to ensure the values are
		// greater than 1
		xUnits.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				if (Integer.parseInt(xUnits.getText()) < 2) {
					xUnits.setText("2");
				}
			}

			public void focusGained(FocusEvent e) {
				xUnits.select(0, xUnits.getText().length());
			}
		});

		xUnits.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent newGraph) {
				if (Integer.parseInt(xUnits.getText()) < 2) {
					xUnits.setText("2");
				}
			}
		});

		// create action listeners for yunits to ensure the values are greater
		// than 1
		yUnits.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				if (Integer.parseInt(yUnits.getText()) < 2) {
					yUnits.setText("2");
				}
			}

			public void focusGained(FocusEvent e) {
				yUnits.select(0, yUnits.getText().length());
			}
		});

		yUnits.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent newGraph) {
				if (Integer.parseInt(yUnits.getText()) < 2) {
					yUnits.setText("2");
				}
			}
		});

		// Create panels
		JPanel graphTitle = new JPanel();
		graphTitle.setLayout(new GridLayout(1, 2));
		graphTitle.add(new JLabel(" Graph Title"));
		graphTitle.add(title);

		JPanel xTitle = new JPanel();
		xTitle.setLayout(new GridLayout(1, 2));
		xTitle.add(new JLabel(" X Axis Title"));
		xTitle.add(xName);

		JPanel yTitle = new JPanel();
		yTitle.setLayout(new GridLayout(1, 2));
		yTitle.add(new JLabel(" Y Axis Title"));
		yTitle.add(yName);

		JPanel xTicks = new JPanel();
		xTicks.setLayout(new GridLayout(1, 2));
		xTicks.add(new JLabel(" X Axis Ticks"));
		xTicks.add(xUnits);

		JPanel yTicks = new JPanel();
		yTicks.setLayout(new GridLayout(1, 2));
		yTicks.add(new JLabel(" Y Axis Ticks"));
		yTicks.add(yUnits);

		JPanel yFormat = new JPanel();
		yFormat.setLayout(new GridLayout(1, 2));
		yFormat.add(new JLabel(" X Axis Number Format"));
		yFormat.add(xformat);

		JPanel xFormat = new JPanel();
		xFormat.setLayout(new GridLayout(1, 2));
		xFormat.add(new JLabel(" Y Axis Number Format"));
		xFormat.add(yformat);

		JPanel regFormat = new JPanel();
		regFormat.setLayout(new GridLayout(1, 2));
		regFormat.add(new JLabel(" Regression Data Format"));
		regFormat.add(regformat);

		JPanel hPaddingPanel = new JPanel();
		hPaddingPanel.setLayout(new GridLayout(1, 2));
		hPaddingPanel.add(new JLabel(" Horizontal Padding"));
		hPaddingPanel.add(hPadding);

		// Setup the main panel
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(graphTitle);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(xTitle);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(yTitle);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(xTicks);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(yTicks);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(yFormat);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(xFormat);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(regFormat);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(hPaddingPanel);
		mainPanel.add(Box.createVerticalGlue());
		addNextButton(mainPanel);

		// Setup the frame info
		add(mainPanel);
		setTitle("Graph Information");
		setLocationRelativeTo(MainWindow.frame);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}
	
	public void refresh () {
		title.setText(Controller.getGraph().getName());
		xformat.setText(Controller.getGraph().getXFormat());
		yformat.setText(Controller.getGraph().getYFormat());
		regformat.setText(Controller.getGraph().getRegFormat());
		yName.setText(Controller.getGraph().getYName());
		xName.setText(Controller.getGraph().getXName());
		yUnits.setText(Integer.toString(Controller.getGraph().getScaleY()));
		xUnits.setText(Integer.toString(Controller.getGraph().getScaleX()));
		hPadding.setText(Double.toString(Controller.getGraph().getHPadding()));
	}

	/**
	 * @description adds a next button to the given panel
	 * @param panel
	 *            the panel to put the button on
	 */
	private void addNextButton(JPanel panel) {
		JButton button = new JButton("Apply");

		JPanel buttonBox = new JPanel();
		buttonBox.setLayout(new GridLayout(1, 1));
		buttonBox.add(button);

		panel.add(buttonBox);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent newGraph) {
				Controller.getGraph().setXName(xName.getText());
				Controller.getGraph().setYName(yName.getText());
				Controller.getGraph().setXFormat(xformat.getText());
				Controller.getGraph().setYFormat(yformat.getText());
				Controller.getGraph().setRegFormat(regformat.getText());
				Controller.getGraph().setName(title.getText());

				// make sure valid values are entered for numerical fields
				try {
					if (Integer.parseInt(xUnits.getText()) < 2) {
						xUnits.setText("2");
					}
				} catch (NumberFormatException myexception) {
					xUnits.setText(String.valueOf(Controller.getGraph().getScaleX()));
				}

				try {
					if (Integer.parseInt(yUnits.getText()) < 2) {
						yUnits.setText("2");
					}
				} catch (NumberFormatException myexception) {
					yUnits.setText(String.valueOf(Controller.getGraph().getScaleY()));
				}

				try {
					if (Double.parseDouble(hPadding.getText()) < 0) {
						hPadding.setText("0");
					}
				} catch (NumberFormatException myexception) {
					hPadding.setText(String.valueOf(Controller.getGraph().getHPadding()));
				}

				Controller.getGraph().setScaleX(Integer.parseInt(xUnits.getText()));
				Controller.getGraph().setScaleY(Integer.parseInt(yUnits.getText()));
				Controller.getGraph().setHPadding(Double.parseDouble(hPadding.getText()));
			}
		});

	}
}

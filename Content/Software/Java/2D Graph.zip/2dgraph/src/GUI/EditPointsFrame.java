package GUI;

import javax.swing.JFrame;

/**
 * @author dwp726
 * @description Edit DataLines Frame, upon creation, adds the Edit Lines Panel.
 */
public class EditPointsFrame extends JFrame {
	private EditPointsPanel panel = new EditPointsPanel();
	private static final long serialVersionUID = 1L;

	public EditPointsFrame() {
		setTitle("Edit Data Points");
		setLocationRelativeTo(MainWindow.frame);

		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		add(panel);
	}

	public int getCurrentLine() {
		return panel.dataLinesComboBox.getSelectedIndex();
	}

	public void addLine(String name) {
		int index = panel.dataLinesComboBox.getSelectedIndex();
		panel.newDataLineBtn.doClick();
		panel.title.setText(name);
		panel.setTitle.doClick();
		panel.showPoints.setSelected(false);
		panel.dataLinesComboBox.setSelectedIndex(index);
	}
	
	public void refresh(){
		
		panel.refresh();
	}
}

package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * 
 * @author ral940
 * @description The colour chooser class allows for the selection and usage of a
 *              particular colour.
 */
public class ColorChooser {
	/* Constructor */
	public Color chooseColor() {

		JFrame frame = new JFrame("Choose a color");
		Color initialColor = Color.black;
		Color newColor;

		// Show the dialog; this method does not return until the dialog is
		// closed
		newColor = JColorChooser.showDialog(frame, "Choose a color:", initialColor);

		return newColor;

	}

	/* Main Method for Starting a local colour chooser */
	public static void main(String[] args) {
		JFrame j = new JFrame();
		j.setSize(150, 100);
		j.setVisible(true);

		JPanel p = new JPanel();

		j.add(p);

		JButton b = new JButton("Choose a color:");
		p.add(b);

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ColorChooser c = new ColorChooser();
				c.chooseColor();
			}
		});
	}

}

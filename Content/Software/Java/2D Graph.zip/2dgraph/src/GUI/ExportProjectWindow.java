package GUI;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class ExportProjectWindow extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JFileChooser fc;
	private JButton selectFolderButton;
	private JTextField filename, width, height;

	/**
	 * Constructor
	 * 
	 * @author Adam Knox
	 */
	public ExportProjectWindow() {
		// Create a file chooser
		fc = new JFileChooser();
		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		// create filename panel
		JPanel filenamePanel = new JPanel();
		filenamePanel.setLayout(new GridLayout(1, 2));
		JLabel filenameLabel = new JLabel(" Filename:");
		filenameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		filename = new JTextField();
		filenamePanel.add(filenameLabel);
		filenamePanel.add(filename);

		// create width panel
		JPanel widthPanel = new JPanel();
		widthPanel.setLayout(new GridLayout(1, 2));
		JLabel widthLabel = new JLabel(" Image Width (pixels): ");
		widthLabel.setHorizontalAlignment(SwingConstants.CENTER);
		width = new JTextField();
		widthPanel.add(widthLabel);
		widthPanel.add(width);

		// create height panel
		JPanel heightPanel = new JPanel();
		heightPanel.setLayout(new GridLayout(1, 2));
		JLabel heightLabel = new JLabel(" Image Height (pixels): ");
		heightLabel.setHorizontalAlignment(SwingConstants.CENTER);
		height = new JTextField();
		heightPanel.add(heightLabel);
		heightPanel.add(height);

		// create folder selection button
		selectFolderButton = new JButton("Save");
		selectFolderButton.addActionListener(this);

		JPanel folderPanel = new JPanel();
		folderPanel.setLayout(new GridLayout(1, 1));
		folderPanel.add(selectFolderButton);

		// create and setup main panel
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.add(filenamePanel);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(widthPanel);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(heightPanel);
		mainPanel.add(Box.createVerticalGlue());
		mainPanel.add(folderPanel);

		// setup frame
		this.add(mainPanel);
	}

	/**
	 * @description saves the image file when the save button is clicked (if the
	 *              user enters a valid location)
	 * @author Adam Knox
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == selectFolderButton) {
			int returnVal = fc.showOpenDialog(fc);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				// create duplicate of the graph
				GraphPanel imagePanel = new GraphPanel();
				LegendPanel legendPan = new LegendPanel();
				RegTextPanel regPanel = new RegTextPanel();

				// plot will export, so hide the window
				this.setVisible(false);

				// save this plot int widthPlot, int widthReg, int legendHeight,
				// int plotHeight
				Controller.exportPlot(imagePanel, regPanel, legendPan, fc.getSelectedFile(), filename.getText(), "jpg",
						Integer.parseInt(width.getText()) - MainWindow.COLWIDTH, MainWindow.COLWIDTH, legendPan.getH(),
						Integer.parseInt(height.getText()) - legendPan.getH());

			}
		}
	}
}

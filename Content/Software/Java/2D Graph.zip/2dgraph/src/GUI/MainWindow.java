package GUI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.KeyStroke;
import javax.swing.JFrame;

/**
 * @author ark083, dwp726 Main Menu creator
 */
public class MainWindow implements ActionListener {
	JFileChooser fc;

	private static final int BAR_HEIGHT = 23;
	private static final int PADDING = 5;
	static final int COLWIDTH = 250;

	private static final int LINE_INFO_WINDOW_WIDTH = 900;
	private static final int LINE_INFO_WINDOW_HEIGHT = 550;

	private static final int GRAPH_INFO_WINDOW_HEIGHT = 300;
	private static final int GRAPH_INFO_WINDOW_WIDTH = 300;

	private static final int REGRESSION_WINDOW_WIDTH = 400;
	private static final int REGRESSION_WINDOW_HEIGHT = 300;

	private static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	public static final int WIDTH = (int) screenSize.getWidth();
	public static final int HEIGHT = (int) (screenSize.getHeight() - BAR_HEIGHT) / 2;

	static final JFrame frame = new JFrame("2DGraph");
	private static final MainWindow mainWindow = new MainWindow();
	private static final GraphInfoWindow graphInfoWindow = new GraphInfoWindow();
	private static final RegressionWindow regressionWindow = new RegressionWindow();
	public static final EditPointsFrame lineInfoWindow = new EditPointsFrame();
	private static final ExportProjectWindow exportProject = new ExportProjectWindow();
	private static final SaveProjectWindow saveProject = new SaveProjectWindow();

	private JMenuBar createMenuBar() {
		JMenu menu;
		JMenuBar menuBar;
		JMenuItem menuItem;

		// Create the menu bar
		menuBar = new JMenuBar();

		// create project setup/save menu
		menu = new JMenu("File");
		menu.getAccessibleContext().setAccessibleDescription("File");
		menuBar.add(menu);

		// setup the new project button
		menuItem = new JMenuItem("New Project", KeyEvent.VK_N);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("Creates a new graph");
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getGraph().resetGraph();
			}
		});

		// setup open project button
		menuItem = new JMenuItem("Open Project", KeyEvent.VK_O);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("Loads a graph");
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent Load) {
				// open file chooser
				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				int returnVal = fc.showOpenDialog(fc);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					// valid file, so read the project in
					Controller.openProject(fc.getSelectedFile().getPath());
				}
			}
		});

		// setup save project button
		menuItem = new JMenuItem("Save Project", KeyEvent.VK_S);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("Saves a graph");
		menuItem.setEnabled(true);
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveProject.setVisible(true);
			}
		});

		// setup export project to image button
		menuItem = new JMenuItem("Export Project", KeyEvent.VK_S);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("Saves a graph");
		menuItem.setEnabled(true);
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportProject.setVisible(true);
			}
		});

		// setup edit menu
		menu = new JMenu("Edit");
		menu.setMnemonic(KeyEvent.VK_E);
		menu.getAccessibleContext().setAccessibleDescription("Allows for editing of graph");
		menu.setEnabled(true);

		// setup line information button
		menuItem = new JMenuItem("Line Information", KeyEvent.VK_L);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("open line information options window");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lineInfoWindow.setVisible(true);
			}
		});
		menu.add(menuItem);

		// setup graph information button
		menuItem = new JMenuItem("Graph Information", KeyEvent.VK_G);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("open graph information options window");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				graphInfoWindow.setVisible(true);
			}
		});
		menu.add(menuItem);

		// setup regression analysis button
		menuItem = new JMenuItem("Regression Analysis", KeyEvent.VK_R);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.ALT_MASK));
		menuItem.getAccessibleContext().setAccessibleDescription("open regression analysis window");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regressionWindow.setVisible(true);
			}
		});
		menu.add(menuItem);

		// put the menubar into the panel
		menuBar.add(menu);

		return menuBar;
	}

	/**
	 * @description does the actual image refreshing
	 * @param imagePanel
	 *            imagePanel
	 * @param rightPanel
	 *            rightPanel
	 * @param regPanel
	 *            regPanel
	 * @param legendPanel
	 *            legendPanel
	 * @author Adam Knox
	 */
	private static void refresh(final GraphPanel imagePanel, final RegTextPanel regPanel, final LegendPanel legendPanel) {
		// create listener for updating on window size change
		regPanel.addComponentListener(new ComponentListener() {

			public void componentResized(ComponentEvent e) {

				regPanel.setPreferredSize(new Dimension(COLWIDTH, regPanel.getHeight()));
				legendPanel.setPreferredSize(new Dimension(legendPanel.getWidth(), legendPanel.getH()));

				regPanel.repaint();
				legendPanel.repaint();
				imagePanel.repaint();

			}

			public void componentMoved(ComponentEvent e) {
			}

			public void componentShown(ComponentEvent e) {
			}

			public void componentHidden(ComponentEvent e) {
			}
		});

		// create updater for forced updates
		javax.swing.Timer timer = new javax.swing.Timer(10, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Controller.getGraph().refreshStatus() == true) {

					// refresh each panel
					legendPanel.setPreferredSize(new Dimension(legendPanel.getWidth(), legendPanel.getH()));
					legendPanel.repaint();

					imagePanel.repaint();
					graphInfoWindow.refresh();
					lineInfoWindow.refresh();
					regressionWindow.refresh();
					regPanel.repaint();
					// notify GraphData that the panels have been
					// refreshed
					Controller.getGraph().refreshed();
				}
			}
		});

		timer.start();
	}

	/**
	 * @description Creates the panel where the main graph editing can take
	 *              place
	 * @author Adam Knox
	 */
	public static void createGraphPanel() {

		final Container contentPane = frame.getContentPane();

		// create the panels
		GraphPanel GraphPanel = new GraphPanel();
		LegendPanel legendPanel = new LegendPanel();
		RegTextPanel displayText = new RegTextPanel();

		// setup each panel's layout
		contentPane.setLayout(new BorderLayout());

		// set each panel's size
		displayText.setPreferredSize(new Dimension(COLWIDTH, contentPane.getHeight()));
		legendPanel.setPreferredSize(new Dimension(legendPanel.getWidth(), legendPanel.getH()));

		// add each panel to the main frame
		contentPane.add(GraphPanel, BorderLayout.CENTER);
		contentPane.add(legendPanel, BorderLayout.SOUTH);
		contentPane.add(displayText, BorderLayout.EAST);

		// display the frame
		contentPane.setVisible(true);
		frame.validate();

		// setup the refreshing function
		refresh(GraphPanel, displayText, legendPanel);
	}

	/**
	 * @description creates the gui windows, and shows the required ones
	 * @author Adam Knox
	 */
	public static void createAndShowGUI() {
		// Create save project window
		saveProject.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		saveProject.setSize(350, 100);
		saveProject.setLocation((screenSize.width - saveProject.getWidth()) / 2, (screenSize.height - saveProject.getHeight()) / 2);
		saveProject.setVisible(false);

		// Create export project window
		exportProject.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		exportProject.setSize(350, 150);
		exportProject.setLocation((screenSize.width - exportProject.getWidth()) / 2, (screenSize.height - exportProject.getHeight()) / 2);
		exportProject.setVisible(false);

		// Create line information window
		lineInfoWindow.setSize(LINE_INFO_WINDOW_WIDTH, LINE_INFO_WINDOW_HEIGHT);
		lineInfoWindow.setLocation(0, 0);

		// Create graph information window
		graphInfoWindow.setSize(GRAPH_INFO_WINDOW_WIDTH, GRAPH_INFO_WINDOW_HEIGHT);
		graphInfoWindow.setLocation(0, 0);

		// Create regression analysis window
		regressionWindow.setSize(REGRESSION_WINDOW_WIDTH, REGRESSION_WINDOW_HEIGHT);
		regressionWindow.setLocation(0, 0);

		// Create and set up the main window
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new JPanel(new BorderLayout()));
		frame.setJMenuBar(mainWindow.createMenuBar());

		// Display the main window
		frame.setSize(WIDTH - PADDING * 2, HEIGHT - PADDING);
		frame.setLocation(PADDING, PADDING);
		frame.setVisible(true);

	}

	public static void main(String[] args) {
		/* Schedule a job for the event-dispatching thread: */
		/* creating and showing this application's GUI. */
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	public void actionPerformed(ActionEvent e) {
	}
}

package GUI;

import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.JPanel;

import output.ExportPlot;
import output.SavePlot;
import plotInstance.GraphData;

import input.ReadInData;
import input.ReadInPlot;

import container.Graph;
import enumerations.RegTypes;

public class Controller {
	/**
	 * @description gets the singleton graph
	 * @return the singleton graph
	 */
	public static Graph getGraph() {
		return plotInstance.GraphData.get();
	}
	
	
	/**
	 * @description creates a line showing the requested regression
	 * @param index the line containing the data to show the regression for
	 * @param regType the regression to show
	 */
	public static void createRegSet(int index, RegTypes regType) {
		GraphData.get().createRegSet(index, regType, 0);
	}
	
	
	/**
	 * @description creates a line showing the requested regression
	 * @param index the line containing the data to show the regression for
	 * @param regType the regression to show
	 * @param order the polynomial order
	 */
	public static void createRegSet(int index, RegTypes regType, int order) {
		GraphData.get().createRegSet(index, regType, order);
	}
	
	
	
	/**
	 * @description saves the panel(s) as an image
	 * @param plot
	 *            the panel to save
	 * @param name
	 *            the name to use to save the panel as (imge name)
	 * @param extension
	 *            the format to save the image in (png, jpg, ...)
	 * @param width
	 *            the width in pixels of the new image
	 * @param plotHeight
	 *            the height in pixels of the new image
	 * @author Adam Knox
	 */
	public static void exportPlot(JPanel plot, JPanel regData, JPanel legend, File folder, String name, String extension, int widthPlot, int widthReg, int legendHeight, int plotHeight) {
		ExportPlot.exportPlot(plot, regData, legend, folder, name, extension, widthPlot, widthReg, legendHeight, plotHeight);
	}
	
	
	
	/**
	 * @description saves graph to file.
	 * @param filename
	 *            name of the file to save to
	 * @param filePath
	 *            the path to the directory to save in
	 * @author Adam Knox
	 */
	public static void saveProject(File filePath, String filename) {
		 SavePlot.savePlot(filePath, filename);
	}
	
	
	
	/**
	 * @description gets the data from the file, and places it in the Graph
	 * @param file
	 *            name of the file
	 * @return true if successful exception if not
	 * @author Adam Knox
	 */
	public static void openProject(String file) {
		ReadInPlot.Read(file);
	}

	

	/**
	 * @description process every line of the project file
	 * @param delim
	 *            the delimiter used for finding columns
	 * @param xCol
	 *            the column containing the x values
	 * @param yCol
	 *            the column containing the y values
	 * @param xColErrL
	 *            the column containing the left error bar values
	 * @param xColErrR
	 *            the column containing the right error bar values
	 * @param yColErrT
	 *            the column containing the top error bar values
	 * @param yColErrB
	 *            the column containing the bottom error bar values
	 * @throws FileNotFoundException
	 * @author Adam Knox
	 */
	public static void getFileData(File selectedFile, int currentLine, String text, int xCol, int yCol, int xColErrL, int xColErrR, int yColErrT, int yColErrB) throws FileNotFoundException {
		ReadInData.processLineByLine(selectedFile, currentLine, text, xCol, yCol, xColErrL, xColErrR, yColErrT, yColErrB);
	}
	
	

	/**
	 * @description process every line of the project file
	 * @param delim
	 *            the delimiter used for finding columns
	 * @param xCol
	 *            the column containing the values
	 * @param binSize
	 *            the range of values to put in a given bin
	 * @param binStartValue
	 *            the smallest point that will be put in the bins
	 * @throws FileNotFoundException
	 * @author Adam Knox
	 */
	public static void getFileData(File fFile, int lineIndex, String delim, int xCol, int binSize, int binStartValue) throws FileNotFoundException {
		ReadInData.processLineByLine(fFile, lineIndex, delim, xCol, binSize, binStartValue);
	}
}
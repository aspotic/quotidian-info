package GUI;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SaveProjectWindow extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JFileChooser fc;
	private JButton selectFolderButton;
	private JTextField filename;
	private JLabel filenameLabel;

	/**
	 * Constructor
	 * 
	 * @author Adam Knox
	 */
	public SaveProjectWindow() {
		// Create a file chooser
		fc = new JFileChooser();
		fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		// create filename label
		filenameLabel = new JLabel("Filename:");
		filenameLabel.setHorizontalAlignment(SwingConstants.CENTER);

		// create filename label
		filename = new JTextField();

		// create folder selection button
		selectFolderButton = new JButton("Save");
		selectFolderButton.addActionListener(this);

		// create and setup main panel
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(3, 1));
		mainPanel.add(filenameLabel);
		mainPanel.add(filename);
		mainPanel.add(selectFolderButton);

		// setup frame
		this.add(mainPanel);
	}

	/**
	 * @description saves the file when the save button is clicked (if the user
	 *              enters a valid location)
	 * @author Adam Knox
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == selectFolderButton) {
			int returnVal = fc.showOpenDialog(fc);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				// save this plot
				Controller.saveProject(fc.getSelectedFile(), filename.getText());
				// plot saved, so hide the window
				this.setVisible(false);
			}
		}
	}
}

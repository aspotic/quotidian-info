package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author amd397 Legend Panel placed on Graph Indicates the current line name
 *         and colour
 */
public class LegendPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private Graphics2D canvasPanel;
	private int colorBoxWidth = 10;
	private int colorBoxHeight = 15;

	/**
	 * Creates a Legend for the graph
	 * 
	 * @author Amara Daal
	 */
	public LegendPanel() {
		setBackground(Color.white);

		this.paintAll(canvasPanel);

	}

	public int getH() {
		return 2 * colorBoxHeight + 2 * colorBoxHeight * Controller.getGraph().numLines();
	}

	/**
	 * Draws the legend
	 * 
	 * @author Amara Daal
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		canvasPanel = (Graphics2D) g;
		drawLineInfo();

	}

	/**
	 * Draw Line Info
	 * 
	 * @author Amara Daal
	 */
	private void drawLineInfo() {
		int numLines = Controller.getGraph().numLines();
		int yLocation = 0;
		int xLocation = 10;

		for (int i = 0; i < numLines; i++) {
			yLocation += 2 * colorBoxHeight; // Increment 8 down

			drawColorBox(i, xLocation, yLocation);
			drawLineName(i, xLocation + 30, yLocation + (colorBoxHeight));

		}

	}

	/**
	 * Draw Color Box for respective line
	 * 
	 * @param lineNumber
	 *            the line to draw box for
	 * @param xLocation
	 *            left most x for box
	 * @param yLocation
	 *            upper most y for box
	 * @author Amara Daal
	 */
	private void drawColorBox(int lineNumber, int xLocation, int yLocation) {
		Rectangle colorBox = new Rectangle(xLocation, yLocation, colorBoxWidth, colorBoxHeight);
		canvasPanel.setColor(Controller.getGraph().getLine(lineNumber).getLineColor());
		canvasPanel.draw(colorBox);
		canvasPanel.fill(colorBox);
		canvasPanel.setColor(Color.black);

	}

	/**
	 * Draw Line name for respective line
	 * 
	 * @param lineNumber
	 *            the line to draw box for
	 * @param xLocation
	 *            left most x for name
	 * @param yLocation
	 *            upper most y for name
	 * @author Amara Daal
	 */
	private void drawLineName(int lineNumber, int xLocation, int yLocation) {

		canvasPanel.setFont(new Font("times new roman", Font.ITALIC, 16));
		canvasPanel.drawString(Controller.getGraph().getLine(lineNumber).getName(), xLocation, yLocation);
	}

	public static void main(String[] args) {

		Controller.getGraph().insertPointSequential(0, 1, 1);
		Controller.getGraph().insertPointSequential(0, 4, 4);
		/*
		 * GraphData.getGraph().addNewLine(); GraphData.getGraph().insertPoint(20,2);
		 * GraphData.getGraph().insertPoint(0,0);
		 */
		Controller.getGraph().addNewLine();
		Controller.getGraph().insertPointSequential(0, 1, 2);
		Controller.getGraph().insertPointSequential(0, 1.5, 4);
		Controller.getGraph().insertPointSequential(0, 2, 6);
		Controller.getGraph().insertPointSequential(0, 2.5, 8);
		Controller.getGraph().insertPointSequential(0, 3, 10);
		Controller.getGraph().insertPointSequential(0, 3.5, 12);
		Controller.getGraph().insertPointSequential(0, 4, 14);
		Controller.getGraph().insertPointSequential(0, 4.5, 16);
		Controller.getGraph().insertPointSequential(0, 5, 18);
		Controller.getGraph().insertPointSequential(0, 5.5, 20);
		/*
		 * 
		 * GraphData.getGraph().insertPoint(3,3); GraphData.getGraph().insertPoint(4,4);
		 * GraphData.getGraph().insertPoint(5,5); GraphData.getGraph().insertPoint(6,6);
		 * GraphData.getGraph().insertPoint(7,7); GraphData.getGraph().insertPoint(8,10);
		 * GraphData.getGraph().insertPoint(9,9); GraphData.getGraph().insertPoint(10,10);
		 * GraphData.getGraph().insertPoint(11,11);
		 * GraphData.getGraph().insertPoint(12,12);
		 * GraphData.getGraph().insertPoint(13,133);
		 * GraphData.getGraph().insertPoint(15,133);
		 * 
		 * GraphData.getGraph().addNewLine(); GraphData.getGraph().insertPoint(5,133);
		 * GraphData.getGraph().insertPoint(7,133);
		 * GraphData.getGraph().insertPoint(9,12);
		 * GraphData.getGraph().insertPoint(11,11);
		 * GraphData.getGraph().insertPoint(13,10);
		 * GraphData.getGraph().insertPoint(15,9); GraphData.getGraph().insertPoint(17,8);
		 * GraphData.getGraph().insertPoint(19,7); GraphData.getGraph().insertPoint(21,6);
		 * GraphData.getGraph().insertPoint(23,5); GraphData.getGraph().insertPoint(24,4);
		 * GraphData.getGraph().insertPoint(25,3); GraphData.getGraph().insertPoint(27,2);
		 * GraphData.getGraph().insertPoint(30,1); // lines.get(lineNum).add(120);
		 * 
		 * GraphData.getGraph().addNewLine();
		 * GraphData.getGraph().lines.get(1).goToFirst();
		 * GraphData.getGraph().insertPoint(0,120); // lines.get(i).add(120);
		 * GraphData.getGraph().insertPoint(0,190);
		 * GraphData.getGraph().insertPoint(0,211);
		 * GraphData.getGraph().insertPoint(0,75); GraphData.getGraph().insertPoint(0,30);
		 * GraphData.getGraph().insertPoint(0,290);
		 * GraphData.getGraph().insertPoint(0,182);
		 * GraphData.getGraph().insertPoint(0,65); GraphData.getGraph().insertPoint(0,85);
		 * GraphData.getGraph().insertPoint(0,120);
		 * GraphData.getGraph().insertPoint(0,100);
		 * GraphData.getGraph().insertPoint(0,101);
		 */
		Controller.getGraph().getLine(0).setLineThickness(2);
		Controller.getGraph().getLine(0).setName("A-Town");
		Controller.getGraph().getLine(0).setLineColor(Color.BLUE);
		Controller.getGraph().getLine(0).setErrorBarThickness(3);
		Controller.getGraph().getLine(0).setErrorBarColor(Color.ORANGE);

		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		LegendPanel graphLegend = new LegendPanel();

		// ExportPlot.exportPlot(mainGraph, "testing", "jpg", 3000, 3000);

		f.getContentPane().add(graphLegend);

		f.setSize(200, 200);
		f.setLocation(200, 200);
		f.setVisible(true);

	}

}

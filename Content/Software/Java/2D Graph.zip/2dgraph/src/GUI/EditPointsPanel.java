package GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import container.Graph;
import enumerations.CalcTypes;
import enumerations.RegTypes;

/**
 * @author dwp726 Panel to display the editing of the data line. Has sliders,
 *         buttons and checkboxes to control individual line qualities. In
 *         addition, this class is responsible for GUI creation/removal and the
 *         addition/removal of the data points associated with those lines.
 */
public class EditPointsPanel extends JPanel implements ActionListener, FocusListener, ChangeListener, ItemListener {

	private static final long serialVersionUID = 1L;
	Graph myGraph;
	JTextField xText, yText, eErr, nErr, lineName, sErr, wErr, title;

	JButton addPntBtn, remPntBtn, newDataLineBtn, removeLineBtn, lineColorBtn, importBtn, errColorBtn, pntColorBtn, setTitle;
	JPanel lineClrPan, errClrPan, pointClrPan, linePanel;
	JComboBox dataLinesComboBox, pointBox;
	JSlider lineThickness, errorThickness, pointThickness;
	JCheckBox HerrorBar, VerrorBar, showErrBox, showErrCrossHairs, showPoints, showLines;
	int count; /* Records the number of created lines(but not removed) */

	/** Constructor */
	public EditPointsPanel() {

		count = 1;
		myGraph = Controller.getGraph(); /* Retrieve the current graph */
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		Border etchedBord = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
		/* Setup grids for the panel */
		GridLayout grid = new GridLayout(4, 4);
		grid.setVgap(1);
		GridLayout singles = new GridLayout(0, 1);
		GridLayout halves = new GridLayout(0, 2);
		GridLayout threes = new GridLayout(1, 3);
		threes.setHgap(25);
		GridLayout quarters = new GridLayout(1, 4);

		/* Main Panel with a single column grid layout */
		linePanel = new JPanel();
		linePanel.setLayout(singles);
		linePanel.add(addDataLineList());
		JPanel addPointsPanel = new JPanel();
		addPointsPanel.setLayout(grid);
		JPanel textPanel = new JPanel();
		textPanel.setLayout(new FlowLayout());
		JPanel errorPanel = new JPanel();
		errorPanel.setLayout(new FlowLayout());

		// add set title panel
		JPanel pointLabel = new JPanel();
		pointLabel.setLayout(new GridLayout(1, 3));
		title = new JTextField();
		setTitle = new JButton("set Title");
		setTitle.addActionListener(this);
		title.setText(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getName());
		pointLabel.add(new JLabel("Data Set Title"));
		pointLabel.add(title);
		pointLabel.add(setTitle);

		/* Setup textFields for data-point input */
		xText = new JTextField("0.000000");
		xText.addFocusListener(this);
		yText = new JTextField("0.000000");
		yText.addFocusListener(this);
		eErr = new JTextField("0.000000");
		eErr.addFocusListener(this);
		nErr = new JTextField("0.000000");
		nErr.addFocusListener(this);
		wErr = new JTextField("0.000000");
		wErr.addFocusListener(this);
		sErr = new JTextField("0.000000");
		sErr.addFocusListener(this);

		/* Buttons to be added to the panel */
		addPntBtn = new JButton("Add Point");
		addPntBtn.addActionListener(this);

		remPntBtn = new JButton("Remove Point");
		remPntBtn.addActionListener(this);

		lineColorBtn = new JButton("Line Colour");
		lineColorBtn.addActionListener(this);

		errColorBtn = new JButton("Error Colour");
		errColorBtn.addActionListener(this);

		pntColorBtn = new JButton("Point Colour");
		pntColorBtn.addActionListener(this);

		importBtn = new JButton("Import Data Points");
		importBtn.addActionListener(this);

		/* Panels to show the Line Component Colours */
		lineClrPan = new JPanel();
		errClrPan = new JPanel();
		pointClrPan = new JPanel();
		lineClrPan.setBackground(Color.black);
		lineClrPan.setBorder(etchedBord);
		errClrPan.setBackground(Color.black);
		errClrPan.setBorder(etchedBord);
		pointClrPan.setBackground(Color.black);
		pointClrPan.setBorder(etchedBord);

		textPanel.add(new JLabel("X: "));
		textPanel.add(xText);
		textPanel.add(new JLabel("Y: "));
		textPanel.add(yText);
		errorPanel.add(new JLabel("ErrorBars"));
		errorPanel.add(new JLabel("X"));
		errorPanel.add(eErr);
		errorPanel.add(new JLabel("Y"));
		errorPanel.add(nErr);
		addPointsPanel.add(textPanel, 0, 0);
		addPointsPanel.add(errorPanel, 0, 1);
		addPointsPanel.add(addPntBtn, 0, 2);

		newDataLineBtn = new JButton("Add a Data Line");
		newDataLineBtn.addActionListener(this);
		removeLineBtn = new JButton("Remove Data Line");
		removeLineBtn.addActionListener(this);

		/* Sliders Initialization */
		lineThickness = new JSlider(0, 10);
		lineThickness.setMinorTickSpacing(1);
		lineThickness.setPaintLabels(true);
		lineThickness.setPaintTicks(true);
		lineThickness.setSnapToTicks(true);
		lineThickness.addChangeListener(this);
		lineThickness.setValue(1);
		Dimension d = new Dimension(1, 1);
		lineThickness.setPreferredSize(d);
		lineName = new JTextField(myGraph.getLine(0).getName());

		errorThickness = new JSlider(0, 10);
		errorThickness.setMinorTickSpacing(1);
		errorThickness.setPaintLabels(true);
		errorThickness.setPaintTicks(true);
		errorThickness.setSnapToTicks(true);
		errorThickness.addChangeListener(this);
		errorThickness.setValue(1);
		errorThickness.setPreferredSize(d);

		pointThickness = new JSlider(0, 10);
		pointThickness.setMinorTickSpacing(1);
		pointThickness.setPaintLabels(true);
		pointThickness.setPaintTicks(true);
		pointThickness.setSnapToTicks(true);
		pointThickness.addChangeListener(this);
		pointThickness.setValue(3);
		pointThickness.setPreferredSize(d);

		/* Checkbox initialization */
		HerrorBar = new JCheckBox("Enable Horizontal Error");
		HerrorBar.addItemListener(this);
		VerrorBar = new JCheckBox("Enable Vertical Error");
		VerrorBar.addItemListener(this);
		showErrBox = new JCheckBox("Show Error Bar Box");
		showErrBox.addItemListener(this);
		showErrCrossHairs = new JCheckBox("Show Error Bar Crosshairs");
		showErrCrossHairs.addItemListener(this);
		showPoints = new JCheckBox("Show Points");
		showPoints.addItemListener(this);
		showLines = new JCheckBox("Show Line");
		showLines.addItemListener(this);

		JLabel empty2 = new JLabel(); // Empty Panels for Spacing

		JPanel addrmv = new JPanel();

		/* Each individual panel is added to the single column linePanel */
		/* The individual panels themselves are split via the grid layout */
		addrmv.setLayout(halves);
		addrmv.add(newDataLineBtn);
		addrmv.add(removeLineBtn);

		JPanel txtcolour = new JPanel();
		txtcolour.setLayout(threes);
		txtcolour.add(lineClrPan);
		txtcolour.add(pointClrPan);
		txtcolour.add(errClrPan);

		JPanel colours = new JPanel();
		colours.setLayout(threes);
		colours.add(lineColorBtn);
		colours.add(pntColorBtn);
		colours.add(errColorBtn);

		JPanel txts = new JPanel();
		txts.setLayout(halves);
		txts.add(new JLabel("Line Thickness"));
		txts.add(txtcolour);

		JPanel slds = new JPanel();
		slds.setLayout(halves);
		slds.add(lineThickness);
		slds.add(colours);

		JPanel boxes1 = new JPanel();
		boxes1.setLayout(halves);
		boxes1.add(VerrorBar);
		boxes1.add(HerrorBar);

		JPanel boxes2 = new JPanel();
		boxes2.setLayout(halves);
		boxes2.add(showErrCrossHairs);
		boxes2.add(showErrBox);

		JPanel boxes3 = new JPanel();
		boxes3.setLayout(new GridLayout(1, 4));
		boxes3.add(new JLabel(""));
		boxes3.add(new JLabel(""));
		boxes3.add(showPoints);
		boxes3.add(showLines);

		JPanel slideAndBoxes1 = new JPanel();
		slideAndBoxes1.setLayout(halves);
		slideAndBoxes1.add(errorThickness);
		slideAndBoxes1.add(boxes1);

		JPanel slideAndBoxes2 = new JPanel();
		slideAndBoxes2.setLayout(halves);
		slideAndBoxes2.add(pointThickness);
		slideAndBoxes2.add(boxes2);

		JPanel xcoords = new JPanel();
		xcoords.setLayout(halves);
		JPanel ycoords = new JPanel();
		ycoords.setLayout(halves);
		JPanel arbttns = new JPanel();
		arbttns.setLayout(halves);

		JPanel xinfo = new JPanel();
		xinfo.setLayout(quarters);
		JPanel yinfo = new JPanel();
		yinfo.setLayout(quarters);
		GridLayout thirds = new GridLayout(1, 3);
		JPanel removePoint = new JPanel();
		removePoint.setLayout(halves);
		JPanel addPoint = new JPanel();
		addPoint.setLayout(halves);
		JPanel imp = new JPanel();
		imp.setLayout(thirds);
		JPanel errs = new JPanel();
		errs.setLayout(quarters);
		JPanel errDivide = new JPanel();
		errDivide.setLayout(halves);

		JPanel listPoints = new JPanel();
		listPoints.setLayout(grid);

		listPoints.add(new JLabel("Data Points"), 0, 0);

		createPointList();

		listPoints.add(pointBox, 0, 1);
		listPoints.add(remPntBtn, 0, 2);

		xinfo.add(new JLabel("X:"));
		xinfo.add(xText);
		xinfo.add(new JLabel("Y:"));
		xinfo.add(yText);

		yinfo.add(new JLabel("East Error:"));
		yinfo.add(eErr);
		yinfo.add(new JLabel("North Error:"));
		yinfo.add(nErr);

		addPoint.add(addPntBtn);
		addPoint.add(new JLabel(""));

		removePoint.add(new JLabel(""));
		removePoint.add(remPntBtn);

		imp.add(new JLabel(""));
		imp.add(importBtn);
		imp.add(new JLabel(""));

		errs.add(new JLabel("West Error:"));
		errs.add(wErr);
		errs.add(new JLabel("South Error"));
		errs.add(sErr);

		xcoords.add(xinfo);
		xcoords.add(createPointList());
		ycoords.add(yinfo);
		arbttns.add(addPoint);
		arbttns.add(removePoint);
		errDivide.add(errs);

		/* Addition of panels to the main component */
		linePanel.add(pointLabel);
		linePanel.add(addrmv);
		linePanel.add(empty2);
		linePanel.add(txts);
		linePanel.add(slds);
		linePanel.add(new JLabel("Error Bar Thickness"));
		linePanel.add(slideAndBoxes1);
		linePanel.add(new JLabel("Point Thickess"));
		linePanel.add(slideAndBoxes2);
		linePanel.add(boxes3);
		linePanel.add(xcoords);
		linePanel.add(ycoords);
		linePanel.add(errDivide);
		linePanel.add(arbttns);
		linePanel.add(imp);

		add(linePanel);
		update();
		updateLine();
	}

	/**
	 * @author dwp726 Initializes the list of data points
	 */
	private JComboBox addDataLineList() {

		String[] datalineString = new String[myGraph.numLines()];
		// myGraph.goToFirstLine();
		int i;
		for (i = 0; i < myGraph.numLines(); i++) {
			datalineString[i] = myGraph.getLine(i).getName();
		}
		dataLinesComboBox = new JComboBox(datalineString);

		dataLinesComboBox.addActionListener(this);

		return dataLinesComboBox;
	}

	/**
	 * @author dwp726 Creates the combo box containing the data points.
	 */
	private JComboBox createPointList() {
		String[] pointString = new String[myGraph.getLine(dataLinesComboBox.getSelectedIndex()).size()];

		// iterate through dataline and collect points.
		for (int i = 0; i < myGraph.getLine(dataLinesComboBox.getSelectedIndex()).size(); i++) {
			pointString[i] = myGraph.getLine(dataLinesComboBox.getSelectedIndex()).get(i).toString();
		}

		pointBox = new JComboBox(pointString);
		return pointBox;

	}

	/**
	 * @author dwp726 Updates the combo box containing the data points.
	 */
	private void update() {
		pointBox.removeAllItems();
		
		for (int i = 0; i < myGraph.getLine(dataLinesComboBox.getSelectedIndex()).size(); i++) {
			pointBox.addItem(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).get(i).toString());
		}
		pointBox.validate();
	}

	/**
	 * @author dwp726 Updates the listed dataline info
	 */
	private void updateLine() {

		// update title
		title.setText(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getName());
		/* Update Colours */
		lineClrPan.setBackground(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getLineColor());
		errClrPan.setBackground(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getErrorBarColor());
		pointClrPan.setBackground(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getPointColor());
		/* Update Thicknesses */
		lineThickness.setValue(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getLineThickness());
		errorThickness.setValue(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getErrorBarThickness());
		pointThickness.setValue(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getPointThickness());
		/* Update CheckBoxes */
		showErrBox.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isShowErrorBox());
		showErrCrossHairs.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isShowErrorCrossHairs());
		HerrorBar.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isXErrorVisible());
		VerrorBar.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isYErrorVisible());
		showLines.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isLineVisible());
		showPoints.setSelected(myGraph.getLine(dataLinesComboBox.getSelectedIndex()).isPointVisible());
		myGraph.refresh();
	}

	public void refresh() {

		int tmp = dataLinesComboBox.getSelectedIndex();

		dataLinesComboBox.removeAllItems();

		for (int i = 0; i < myGraph.numLines(); i++) {
			dataLinesComboBox.addItem(myGraph.getLine(i).getName());
		}

		dataLinesComboBox.validate();
		dataLinesComboBox.setSelectedIndex(tmp);

	}
	
	/** Action Listener for the buttons */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == importBtn) {
			// Create Load window
			JFrame newFrame = new JFrame("Load");
			newFrame.setLocationRelativeTo(this);
			newFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

			// Add content to the window.
			newFrame.add(new ImportDataWindow());

			// Display the window.
			newFrame.pack();
			newFrame.setVisible(true);

		}
		/*
		 * Add Point Button: parses information in text field and adds the point
		 * to appropriate dataline
		 */
		else if (e.getSource() == addPntBtn) {
			try {
				Double xTemp = Double.parseDouble(xText.getText());
				Double yTemp = Double.parseDouble(yText.getText());
				Double err = Double.parseDouble(eErr.getText());
				Double nrr = Double.parseDouble(nErr.getText());
				Double srr = Double.parseDouble(sErr.getText());
				Double wrr = Double.parseDouble(wErr.getText());
				myGraph.insertPointOrdered(dataLinesComboBox.getSelectedIndex(), xTemp, yTemp, err, wrr, nrr, srr);

				// update the regressions for this line
				updateRegressions();

				update();
				updateLine();

			} catch (NumberFormatException myexception) {

			}

		}
		/*
		 * Remove Point Button: removes selected data point from appropriate
		 * data line
		 */
		else if (e.getSource() == remPntBtn) {
			myGraph.removePoint(dataLinesComboBox.getSelectedIndex(), pointBox.getSelectedIndex());

			// update the regressions for this line
			updateRegressions();

			update();
			myGraph.refresh();

		}
		/* Data Lines Box, calls update function to update the window */
		else if (e.getSource() == dataLinesComboBox) {

			if ((dataLinesComboBox.getSelectedIndex() >= 0) && (dataLinesComboBox.getSelectedIndex() < myGraph.numLines())) {
				update();
				updateLine();
			}
		}
		/* Colour buttons, opens up colour chooser to edit the component colours */
		else if (e.getSource() == lineColorBtn) {
			JFrame frame = new JFrame("Choose a color");
			Color initialColor = Color.black;
			Color newColor;

			// Show the dialog; this method does not return until the dialog is
			// closed
			newColor = JColorChooser.showDialog(frame, "Choose a color:", initialColor);
			myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setLineColor(newColor);
			lineClrPan.setBackground(newColor);
			myGraph.refresh();
		} else if (e.getSource() == errColorBtn) {
			JFrame frame = new JFrame("Choose a color");
			Color initialColor = Color.black;
			Color newColor;

			// Show the dialog; this method does not return until the dialog is
			// closed
			newColor = JColorChooser.showDialog(frame, "Choose a color:", initialColor);
			myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setErrorBarColor(newColor);
			errClrPan.setBackground(newColor);
			myGraph.refresh();
		} else if (e.getSource() == pntColorBtn) {
			JFrame frame = new JFrame("Choose a color");
			Color initialColor = Color.black;
			Color newColor;

			// Show the dialog; this method does not return until the dialog is
			// closed
			newColor = JColorChooser.showDialog(frame, "Choose a color:", initialColor);
			myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setPointColor(newColor);
			pointClrPan.setBackground(newColor);
			myGraph.refresh();
		}
		/* New Data Line Button: Adds a new DataLine to the system */
		else if (e.getSource() == newDataLineBtn) {
			count++;
			String newName = ("New Data Set " + count);
			dataLinesComboBox.addItem(newName);
			myGraph.addNewLine();
			dataLinesComboBox.setSelectedIndex(dataLinesComboBox.getItemCount() - 1);
			myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setName(newName);
			myGraph.refresh();
			updateLine();
		}
		/* Remove Data Line Button: removes a DataLine from the system */
		else if (e.getSource() == removeLineBtn) {
			int index = dataLinesComboBox.getSelectedIndex();
			// code for removing a line if the selected line is not the first
			// line
			if (index > -1) {
				if (dataLinesComboBox.getItemCount() == 1) {
					newDataLineBtn.doClick();
					dataLinesComboBox.setSelectedIndex(0);
				}

				myGraph.deleteLine(index);
				try {
					dataLinesComboBox.removeItemAt(index);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				dataLinesComboBox.setSelectedIndex(0);
				// update();
				updateLine();
				myGraph.refresh();

				// code for removing a line if the selected line is the first
				// line
			}

			/*
			 * Set Title button: update the data set with the new title if one
			 * was entered
			 */
		} else if (e.getSource() == setTitle) {
			if (title.getText().length() > 0) {
				// ensure that there are never any duplicate names
				String name = title.getText();
				String finalName = name;
				for (int i = 0; i < Controller.getGraph().numLines(); i++) {
					if (Controller.getGraph().getLine(i).getName().equals(finalName)) {
						finalName = name + " dup";
						i = 0;
					}
				}

				// put in the new name
				int index = dataLinesComboBox.getSelectedIndex();
				myGraph.getLine(index).setName(finalName);
				dataLinesComboBox.insertItemAt(myGraph.getLine(index).getName(), index);
				dataLinesComboBox.removeItemAt(index + 1);
				dataLinesComboBox.setSelectedIndex(index);
			}
		}
	}

	/* Instant text selectors for the text fields */
	public void focusGained(FocusEvent e) {
		JTextField source = (JTextField) e.getSource();
		source.requestFocus();
		source.setForeground(Color.black);
		source.selectAll();
	}

	/* Parsing of numbers for text fields. Error Updating */
	public void focusLost(FocusEvent e) {
		JTextField source = (JTextField) e.getSource();
		try {

			Double.parseDouble(source.getText());
			source.setForeground(Color.black);
		} catch (NumberFormatException myexception) {
			source.setText("Invalid Entry");
			source.setForeground(Color.red);
		}
	}

	/* Slider read-in */
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider) e.getSource();
		if (!source.getValueIsAdjusting()) {
			int thick = (int) source.getValue();
			if (source == lineThickness) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setLineThickness(thick);
			} else if (source == errorThickness) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setErrorBarThickness(thick);
			} else if (source == pointThickness) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setPointThickness(thick);
			}
			myGraph.refresh();
		}

	}

	/* Checkbox state-change event reader */
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			if (e.getSource() == HerrorBar) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setXErrorVisible(true);
			} else if (e.getSource() == VerrorBar) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setYErrorVisible(true);
			} else if (e.getSource() == showErrBox) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setShowErrorBox(true);
			} else if (e.getSource() == showErrCrossHairs) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setShowErrorCrossHairs(true);
			} else if (e.getSource() == showLines) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setLineVisible(true);
			} else if (e.getSource() == showPoints) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setPointVisible(true);
			}
			myGraph.refresh();
		} else if (e.getStateChange() == ItemEvent.DESELECTED) {
			if (e.getSource() == HerrorBar) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setXErrorVisible(false);
			} else if (e.getSource() == VerrorBar) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setYErrorVisible(false);
			} else if (e.getSource() == showErrBox) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setShowErrorBox(false);
			} else if (e.getSource() == showErrCrossHairs) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setShowErrorCrossHairs(false);
			} else if (e.getSource() == showLines) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setLineVisible(false);
			} else if (e.getSource() == showPoints) {
				myGraph.getLine(dataLinesComboBox.getSelectedIndex()).setPointVisible(false);
			}
			myGraph.refresh();
		}

	}

	/**
	 * @description updates the displayed regressions for when points are added
	 *              or removed
	 * @author Adam Knox
	 */
	private void updateRegressions() {
		// update linear regression data if linear regression data is displayed
		if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.linear).size() > 0) {
			// update regular items
			myGraph.runRegression(dataLinesComboBox.getSelectedIndex(), RegTypes.linear);

			// update calculus items
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.linear).contains("integral")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.linear, CalcTypes.integral,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral A"),
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral B"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.linear).contains("derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.linear, CalcTypes.derivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("derivative A"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.linear).contains("second derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.linear, CalcTypes.secondDerivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("second derivative A"));
			}

		}

		// update polynomial regression data if polynomial regression data is
		// displayed
		if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.polynomial).size() > 0) {
			// get order
			Double powerDbl = myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("power");
			String powerString = powerDbl.toString();
			int power = Integer.parseInt(powerString.substring(0, powerString.length() - 2));

			// update regular items
			myGraph.runRegression(dataLinesComboBox.getSelectedIndex(), RegTypes.polynomial, power);

			// update calculus items
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.polynomial).contains("integral")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.polynomial, CalcTypes.integral, power,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral A"),
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral B"));
			}

			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.polynomial).contains("derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.polynomial, CalcTypes.derivative, power,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("derivative A"));
			}

			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.polynomial).contains("second derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.polynomial, CalcTypes.secondDerivative, power,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("second derivative A"));
			}
		}

		// update exponential regression data if exponential regression data is
		// displayed
		if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.exponential).size() > 0) {
			// update regular items
			myGraph.runRegression(dataLinesComboBox.getSelectedIndex(), RegTypes.exponential);

			// update calculus items
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.exponential).contains("integral")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.exponential, CalcTypes.integral,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral A"),
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral B"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.exponential).contains("derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.exponential, CalcTypes.derivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("derivative A"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.exponential).contains("second derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.exponential, CalcTypes.secondDerivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("second derivative A"));
			}

		}

		// update power regression data if power regression data is displayed
		if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.power).size() > 0) {
			// update regular items
			myGraph.runRegression(dataLinesComboBox.getSelectedIndex(), RegTypes.power);

			// update calculus items
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.power).contains("integral")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.power, CalcTypes.integral,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral A"),
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral B"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.power).contains("derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.power, CalcTypes.derivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("derivative A"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.power).contains("second derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.power, CalcTypes.secondDerivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("second derivative A"));
			}

		}

		// update logarithmic regression data if logarithmic regression data is
		// displayed
		if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.logarithmic).size() > 0) {
			// update regular items
			myGraph.runRegression(dataLinesComboBox.getSelectedIndex(), RegTypes.logarithmic);

			// update calculus items
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.logarithmic).contains("integral")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.logarithmic, CalcTypes.integral,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral A"),
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("integral B"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.logarithmic).contains("derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.logarithmic, CalcTypes.derivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("derivative A"));
			}
			if (myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegDisplayData(RegTypes.logarithmic).contains("second derivative")) {
				myGraph.showCalculus(dataLinesComboBox.getSelectedIndex(), RegTypes.logarithmic, CalcTypes.secondDerivative,
						myGraph.getLine(dataLinesComboBox.getSelectedIndex()).getRegData(RegTypes.polynomial).get("second derivative A"));
			}

		}
	}

}

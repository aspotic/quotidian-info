package GUI;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.LinkedList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import container.Graph;
import enumerations.CalcTypes;
import enumerations.RegTypes;

/**
 * @author dwp726, partial implementation ral940 Regression Window, where the
 *         user can select a variety of regression tests to run
 */
public class RegressionWindow extends JFrame implements ActionListener, ItemListener, WindowListener {
	private JPanel mainPanel, boxPanel, emptyPanel;
	private JComboBox datalines, regressions;
	private JTextField order, int1, int2, der1, der2;
	private JLabel nl1, nl2;
	private JCheckBox stdev, var, equation, R2, adjR2, integral, derFirst, derSecond;
	private JButton run, plotRegression;
	private String[] datalineString;
	private Graph myGraph;
	private int prevIndex;
	private RegTypes prevType;
	private boolean intCheck1, intCheck2, der1Check, der2Check, powSet, firstIn;

	private static final long serialVersionUID = 1L;

	/* Constructor */
	public RegressionWindow() {

		setTitle("Regression Testing");
		setLocationRelativeTo(MainWindow.frame);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.addWindowListener(this);

		/* Labels used to properly space out derivative from their text boxes */
		nl1 = new JLabel("");
		nl2 = new JLabel("");

		emptyPanel = new JPanel(); /* Empty Panel for Spacing */

		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
		myGraph = Controller.getGraph();

		/* Initial Creation of dataline combobox */
		datalineString = new String[myGraph.numLines()];

		for (int i = 0; i < myGraph.numLines(); i++) {
			datalineString[i] = myGraph.getLine(i).getName();
		}

		datalines = new JComboBox(datalineString);

		datalines.addActionListener(this);

		/* Initial Creation of regression type combo box */
		String[] regressionTypes = { "linear", "polynomial", "exponential", "logarithmic", "power" };
		regressions = new JComboBox(regressionTypes);

		regressions.addActionListener(this);

		boxPanel = new JPanel();
		boxPanel.setLayout(new GridLayout(5, 3));
		stdev = new JCheckBox("Standard Deviation");
		stdev.addItemListener(this);

		var = new JCheckBox("Variation");
		var.addItemListener(this);
		equation = new JCheckBox("Equation");
		equation.addItemListener(this);
		R2 = new JCheckBox("R^2");
		R2.addItemListener(this);
		adjR2 = new JCheckBox("Adjusted R^2");
		adjR2.addItemListener(this);
		integral = new JCheckBox("Integral");
		integral.addItemListener(this);
		derFirst = new JCheckBox("First Derivative");
		derFirst.addItemListener(this);
		derSecond = new JCheckBox("Second Derivative");
		derSecond.addItemListener(this);
		order = new JTextField("Order");
		order.addActionListener(this);
		order.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				order.requestFocus();
				order.selectAll();
			}

			public void focusLost(FocusEvent e) {
				try {
					Integer.parseInt(order.getText());
					order.setForeground(Color.black);
					powSet = true;
				} catch (NumberFormatException myexception) {
					order.setText("Integer required: ");
					order.setForeground(Color.red);
					powSet = false;
				}
				order.select(0, order.getText().length());
			}
		});

		int1 = new JTextField("left limit");
		int1.addActionListener(this);
		int1.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				int1.requestFocus();
				int1.selectAll();
			}

			public void focusLost(FocusEvent e) {
				try {
					Double.parseDouble(int1.getText());
					int1.setForeground(Color.black);
					intCheck1 = true;
				} catch (NumberFormatException myexception) {
					int1.setText("Number required: ");
					int1.setForeground(Color.red);
					intCheck1 = false;
				}
				int1.select(0, int1.getText().length());
			}
		});

		int2 = new JTextField("right limit");
		int2.addActionListener(this);
		int2.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				int2.requestFocus();
				int2.selectAll();
			}

			public void focusLost(FocusEvent e) {
				try {
					Double.parseDouble(int2.getText());
					int2.setForeground(Color.black);
					intCheck2 = true;
				} catch (NumberFormatException myexception) {
					int2.setText("Number required: ");
					int2.setForeground(Color.red);
					intCheck2 = false;
				}
				int2.select(0, int2.getText().length());
			}
		});

		der1 = new JTextField("point");
		der1.addActionListener(this);
		der1.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				der1.requestFocus();
				der1.selectAll();
			}

			public void focusLost(FocusEvent e) {
				try {
					Double.parseDouble(der1.getText());
					der1.setForeground(Color.black);
					der1Check = true;
				} catch (NumberFormatException myexception) {
					der1.setText("Integer required: ");
					der1.setForeground(Color.red);
					der1Check = false;
				}
				der1.select(0, der1.getText().length());
			}
		});

		der2 = new JTextField("point");
		der2.addActionListener(this);
		der2.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				der2.requestFocus();
				der2.selectAll();
			}

			public void focusLost(FocusEvent e) {
				try {
					Double.parseDouble(der2.getText());
					der2.setForeground(Color.black);
					der2Check = true;
				} catch (NumberFormatException myexception) {
					der2.setText("Integer required: ");
					der2.setForeground(Color.red);
					der2Check = false;
				}
				der2.select(0, der2.getText().length());
			}
		});

		boxPanel.add(derSecond, 4, 0);
		boxPanel.add(nl2, 4, 1);
		boxPanel.add(der2, 4, 2);
		boxPanel.add(derFirst, 3, 0);
		boxPanel.add(nl1, 3, 1);
		boxPanel.add(der1, 3, 2);
		boxPanel.add(integral, 2, 0);
		boxPanel.add(int1, 2, 1);
		boxPanel.add(int2, 2, 2);
		boxPanel.add(R2, 1, 0);
		boxPanel.add(adjR2, 1, 1);
		boxPanel.add(order, 1, 2);
		boxPanel.add(stdev, 0, 0);
		boxPanel.add(var, 0, 1);
		boxPanel.add(equation, 0, 2);
		int1.setEnabled(false);
		int2.setEnabled(false);
		der1.setEnabled(false);
		der2.setEnabled(false);
		order.setEnabled(false);
		powSet = false;
		firstIn = true;

		run = new JButton("Run Regression");
		run.addActionListener(this);

		plotRegression = new JButton("Plot Regression");
		plotRegression.addActionListener(this);

		prevIndex = -1;
		prevType = RegTypes.linear;

		mainPanel.add(datalines);
		mainPanel.add(emptyPanel);
		mainPanel.add(regressions);
		mainPanel.add(boxPanel);

		JPanel buttons = new JPanel();
		buttons.setLayout(new GridLayout(1, 2));
		buttons.add(plotRegression);
		buttons.add(run);

		mainPanel.add(buttons);

		add(mainPanel);
		datalines.setSelectedIndex(0);
		// regressions.setSelectedIndex(0);

	}

	/* Action Listener for selection of datalines */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == datalines) {
			if ((datalines.getSelectedIndex() >= 0) && (datalines.getSelectedIndex() < myGraph.numLines())) {
				runPrevRegression();
				LinkedList<String> myList = myGraph.getLine(datalines.getSelectedIndex()).getRegDisplayData(RegTypes.valueOf((String)regressions.getSelectedItem()));
				// show proper integral info
				if (myList.contains("integral")) {
					int1.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("integral A")
							.toString());
					int2.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("integral B")
							.toString());
					integral.setSelected(true);
				} else {
					integral.setSelected(false);
				}

				// show proper derivative info
				if (myList.contains("derivative")) {
					der1.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("derivative A")
							.toString());
					derFirst.setSelected(true);
				} else {
					derFirst.setSelected(false);
				}

				// show proper second derivative info
				if (myList.contains("second derivative")) {
					der2.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("second derivative A")
							.toString());
					derSecond.setSelected(true);
				} else {
					derSecond.setSelected(false);
				}
				
				prevIndex = datalines.getSelectedIndex();
				prevType = RegTypes.valueOf((String) regressions.getSelectedItem());
				regressions.setSelectedIndex(0);
			}
		}
		/*
		 * If a regression type is selected, the panel containing the checkboxes
		 * must be updated
		 */
		else if (e.getSource() == regressions) {
			runPrevRegression();
			firstIn = false;
			prevType = RegTypes.valueOf((String) regressions.getSelectedItem());
			String selection = (String) regressions.getSelectedItem();

			LinkedList<String> myList = myGraph.getLine(datalines.getSelectedIndex()).getRegDisplayData(RegTypes.valueOf(selection));
			if (myList.contains("var"))
				var.setSelected(true);
			else
				var.setSelected(false);

			if (myList.contains("stdev"))
				stdev.setSelected(true);
			else
				stdev.setSelected(false);

			if (myList.contains("equation"))
				equation.setSelected(true);
			else
				equation.setSelected(false);

			if (myList.contains("R^2"))
				R2.setSelected(true);
			else
				R2.setSelected(false);

			if (myList.contains("adj R^2"))
				adjR2.setSelected(true);
			else
				adjR2.setSelected(false);

			// show proper integral info
			if (myList.contains("integral")) {
				int1.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("integral A")
						.toString());
				int2.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("integral B")
						.toString());
				integral.setSelected(true);
			} else {
				integral.setSelected(false);
			}

			// show proper derivative info
			if (myList.contains("derivative")) {
				der1.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("derivative A")
						.toString());
				derFirst.setSelected(true);
			} else {
				derFirst.setSelected(false);
			}

			// show proper second derivative info
			if (myList.contains("second derivative")) {
				der2.setText(myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.valueOf((String) regressions.getSelectedItem())).get("second derivative A")
						.toString());
				derSecond.setSelected(true);
			} else {
				derSecond.setSelected(false);
			}

			// show proper order for polynomial regression
			if (RegTypes.valueOf(selection) != RegTypes.polynomial) {
				order.setText("");
				order.setEnabled(false);
			} else {
				order.setEnabled(true);
				if (myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.polynomial).containsKey("power")) {
					String val = myGraph.getLine(datalines.getSelectedIndex()).getRegData(RegTypes.polynomial).get("power").toString();
					order.setText(val.substring(0, val.length() - 2));

				} else {
					order.setText("order");
				}

				order.requestFocus();
				order.selectAll();
			}

		} else if (e.getSource() == run) {
			if ((String) regressions.getSelectedItem() == "polynomial") {
				if (powSet) {
					if ((intCheck1) && (intCheck2)) {
						myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.integral, Integer.parseInt(order.getText()), Double.parseDouble(int1.getText()),Double.parseDouble(int2.getText()));
					}

					if (der1Check) {
						myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.derivative, Integer.parseInt(order.getText()), Double.parseDouble(der1.getText()));
					}

					if (der2Check) {
						myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.secondDerivative, Integer.parseInt(order.getText()), Double.parseDouble(der2.getText()));
					}

					myGraph.runRegression(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),Integer.parseInt(order.getText()));
				}
			} else {
				if ((intCheck1) && (intCheck2)) {
					myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.integral, Double.parseDouble(int1.getText()), Double.parseDouble(int2.getText()));
				}

				if (der1Check) {
					myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.derivative, Double.parseDouble(der1.getText()));
				}

				if (der2Check) {
					myGraph.showCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),CalcTypes.secondDerivative, Double.parseDouble(der2.getText()));
				}
				myGraph.runRegression(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()));
			}
			myGraph.getLine(datalines.getSelectedIndex()).updateRegString(datalines.getSelectedIndex());
			myGraph.updatePlotText();

		} else if (e.getSource() == order) {
			try {
				Integer.parseInt(order.getText());
				order.setBackground(Color.white);
				powSet = true;
			} catch (NumberFormatException myexception) {
				order.setText("Integer required: ");
				order.setBackground(Color.red);
				powSet = false;
			}

		} else if (e.getSource() == plotRegression) {
			if (regressions.getSelectedItem() == "polynomial") {
				if (powSet) {
					Controller.createRegSet(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), Integer.parseInt(order.getText()));
				}
			} else {
				Controller.createRegSet(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()));
			}
		}
	}

	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {

			if (e.getSource() == var) {
				myGraph.showRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "var");
			} else if (e.getSource() == stdev) {
				myGraph.showRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "stdev");
			} else if (e.getSource() == equation) {
				myGraph.showRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "equation");
			} else if (e.getSource() == R2) {
				myGraph.showRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "R^2");
			} else if (e.getSource() == adjR2) {
				myGraph.showRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "adj R^2");
			} else if (e.getSource() == integral) {
				int1.setEnabled(true);
				int2.setEnabled(true);
			} else if (e.getSource() == derFirst) {
				der1.setEnabled(true);
			} else if (e.getSource() == derSecond) {
				der2.setEnabled(true);
			}
		} else if (e.getStateChange() == ItemEvent.DESELECTED) {
			if (e.getSource() == var) {
				myGraph.hideRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "var");
			} else if (e.getSource() == stdev) {
				myGraph.hideRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "stdev");
			} else if (e.getSource() == equation) {
				myGraph.hideRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "equation");
			} else if (e.getSource() == R2) {
				myGraph.hideRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "R^2");
			} else if (e.getSource() == adjR2) {
				myGraph.hideRegItem(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), "adj R^2");
			} else if (e.getSource() == integral) {
				myGraph.hideCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), CalcTypes.integral);
				int1.setText("left limit");
				int1.setForeground(Color.black);
				int2.setText("right limit");
				int2.setForeground(Color.black);
				int1.setEnabled(false);
				int2.setEnabled(false);
				intCheck1 = false;
				intCheck2 = false;
			} else if (e.getSource() == derFirst) {
				myGraph.hideCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()), CalcTypes.derivative);
				der1.setText("point");
				der1.setForeground(Color.black);
				der1.setEnabled(false);
				der1Check = false;
			} else if (e.getSource() == derSecond) {
				myGraph.hideCalculus(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),
						CalcTypes.secondDerivative);
				der2.setText("point");
				der2.setForeground(Color.black);
				der2.setEnabled(false);
				der2Check = false;
			}
		}
	}

	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	public void windowClosing(WindowEvent e) {
		if ((String) regressions.getSelectedItem() == "polynomial") {
			if (powSet) {
				myGraph.runRegression(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()),
						Integer.parseInt(order.getText()));
			}
		} else {
			myGraph.runRegression(datalines.getSelectedIndex(), RegTypes.valueOf((String) regressions.getSelectedItem()));
		}
		myGraph.getLine(datalines.getSelectedIndex()).updateRegString(datalines.getSelectedIndex());
		myGraph.updatePlotText();
		this.setVisible(false);
	}

	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	/**
	 * Function used to call previous menu values so that the graph can be
	 * continuously updated.
	 */
	private void runPrevRegression() {
		if (prevIndex >= 0) {
			if (prevType == RegTypes.polynomial) {
				if (powSet) {
					if ((intCheck1) && (intCheck2)) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.integral, Integer.parseInt(order.getText()),
								Double.parseDouble(int1.getText()), Double.parseDouble(int2.getText()));
					}

					if (der1Check) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.derivative, Integer.parseInt(order.getText()),
								Double.parseDouble(der1.getText()));
					}

					if (der2Check) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.secondDerivative, Integer.parseInt(order.getText()),
								Double.parseDouble(der2.getText()));
					}

					myGraph.runRegression(prevIndex, prevType, Integer.parseInt(order.getText()));
				}
			} else {
				if (!firstIn) {
					if ((intCheck1) && (intCheck2)) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.integral, Double.parseDouble(int1.getText()),
								Double.parseDouble(int2.getText()));
					}

					if (der1Check) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.derivative, Double.parseDouble(der1.getText()));
					}

					if (der2Check) {
						myGraph.showCalculus(prevIndex, prevType, CalcTypes.secondDerivative, Double.parseDouble(der2.getText()));
					}

					myGraph.runRegression(prevIndex, prevType);
				}
			}
		}

		myGraph.getLine(datalines.getSelectedIndex()).updateRegString(datalines.getSelectedIndex());
		myGraph.updatePlotText();
	}

	/**
	 * Function used to update the datalinecombobox when a line is added or
	 * removed.
	 */
	public void refresh() {

		int tmp = datalines.getSelectedIndex();
		int tmp2 = regressions.getSelectedIndex();

		datalines.removeAllItems();

		for (int i = 0; i < myGraph.numLines(); i++) {
			datalines.addItem(myGraph.getLine(i).getName());
		}

		datalines.validate();
		if (tmp >= datalines.getItemCount()) {
			datalines.setSelectedIndex(datalines.getItemCount()-1);
		} else {
			datalines.setSelectedIndex(tmp);
		}
		regressions.setSelectedIndex(tmp2);

	}

}

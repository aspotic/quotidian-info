package GUI;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

import javax.swing.*;

/**
 * @author dwp726 (scanning implemented by ark043) Opens a file chooser to open
 *         a file
 */
public class ImportDataWindow extends JPanel implements ActionListener, ItemListener {

	private static final long serialVersionUID = 1L;

	private JButton openButton;
	private JTextField delimText;
	private JTextField binSize, binStart;

	private JTextField xColumnText, yColumnText;
	private JTextField xErrBarLeftColumnText, xErrBarRightColumnText;
	private JTextField yErrBarTopColumnText, yErrBarBottomColumnText;

	private JCheckBox xColErrLeftCheck, xColErrRightCheck;
	private JCheckBox yColErrTopCheck, yColErrBottomCheck;
	private JCheckBox histogramCheck;

	private JFileChooser fc;

	public ImportDataWindow() {
		super(new BorderLayout());

		// Create a file chooser
		fc = new JFileChooser();

		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

		// Create the open button
		openButton = new JButton("Open");
		openButton.addActionListener(this);

		// create histogram data checkbox
		histogramCheck = new JCheckBox();
		histogramCheck.addItemListener(this);
		histogramCheck.setText("Import as Histogram");

		// create bin size text box
		binSize = new JTextField("Bin Size");
		binSize.setEnabled(false);
		binSize.addActionListener(this);
		binSize.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				binSize.requestFocus();
				binSize.selectAll();
			}

			public void focusLost(FocusEvent e) {
				binSize.select(0, 0);
			}
		});

		// create bin start point text box
		binStart = new JTextField("Smallest Value");
		binStart.setEnabled(false);
		binStart.addActionListener(this);
		binStart.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				binStart.requestFocus();
				binStart.selectAll();
			}

			public void focusLost(FocusEvent e) {
				binStart.select(0, 0);
			}
		});

		// Create the text panel for the delimiter option.
		delimText = new JTextField("Delimiter");
		delimText.addActionListener(this);
		delimText.addFocusListener(new FocusListener() {

			// Auto Select Text
			public void focusGained(FocusEvent e) {
				delimText.requestFocus();
				delimText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				delimText.select(0, delimText.getText().length());
			}
		});

		// Create the column selection fields
		xColumnText = new JTextField("x Column");
		xColumnText.addActionListener(this);
		xColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				xColumnText.requestFocus();
				xColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				xColumnText.select(0, 0);
			}
		});

		yColumnText = new JTextField("y Column");
		yColumnText.addActionListener(this);
		yColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				yColumnText.requestFocus();
				yColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				yColumnText.select(0, 0);
			}
		});

		xErrBarLeftColumnText = new JTextField("left x error column");
		xErrBarLeftColumnText.addActionListener(this);
		xErrBarLeftColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				xErrBarLeftColumnText.requestFocus();
				xErrBarLeftColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				xErrBarLeftColumnText.select(0, 0);
			}
		});

		xErrBarRightColumnText = new JTextField("right x error column");
		xErrBarRightColumnText.addActionListener(this);
		xErrBarRightColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				xErrBarRightColumnText.requestFocus();
				xErrBarRightColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				xErrBarRightColumnText.select(0, 0);
			}
		});

		yErrBarTopColumnText = new JTextField("upper y error column");
		yErrBarTopColumnText.addActionListener(this);
		yErrBarTopColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				yErrBarTopColumnText.requestFocus();
				yErrBarTopColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				yErrBarTopColumnText.select(0, 0);
			}
		});

		yErrBarBottomColumnText = new JTextField("lower y error column");
		yErrBarBottomColumnText.addActionListener(this);
		yErrBarBottomColumnText.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				yErrBarBottomColumnText.requestFocus();
				yErrBarBottomColumnText.selectAll();
			}

			public void focusLost(FocusEvent e) {
				yErrBarBottomColumnText.select(0, 0);
			}
		});

		JLabel enable = new JLabel("enable");
		enable.setHorizontalAlignment(SwingConstants.CENTER);

		// Create the column enable boxes
		xColErrLeftCheck = new JCheckBox();
		xColErrLeftCheck.addItemListener(this);

		xColErrRightCheck = new JCheckBox();
		xColErrRightCheck.addItemListener(this);

		yColErrTopCheck = new JCheckBox();
		yColErrTopCheck.addItemListener(this);

		yColErrBottomCheck = new JCheckBox();
		yColErrBottomCheck.addItemListener(this);

		JLabel column = new JLabel("column");
		column.setHorizontalAlignment(SwingConstants.CENTER);

		// add the delimiter method box
		JPanel head = new JPanel();
		head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
		head.add(delimText);
		head.add(histogramCheck);
		head.add(binStart);
		head.add(binSize);
		add(head, BorderLayout.PAGE_START);

		// add the column selection check boxes
		JPanel colSelection = new JPanel();
		colSelection.setLayout(new GridLayout(7, 1));

		colSelection.add(column);
		colSelection.add(xColumnText);
		colSelection.add(yColumnText);
		colSelection.add(xErrBarLeftColumnText);
		colSelection.add(xErrBarRightColumnText);
		colSelection.add(yErrBarTopColumnText);
		colSelection.add(yErrBarBottomColumnText);
		add(colSelection, BorderLayout.EAST);

		// add the column selection fields
		JPanel colEnable = new JPanel();
		colEnable.setLayout(new GridLayout(7, 1));

		colEnable.add(enable);
		colEnable.add(new JLabel());
		colEnable.add(new JLabel());
		colEnable.add(xColErrLeftCheck);
		colEnable.add(xColErrRightCheck);
		colEnable.add(yColErrTopCheck);
		colEnable.add(yColErrBottomCheck);
		add(colEnable, BorderLayout.WEST);

		// add the open button
		add(openButton, BorderLayout.PAGE_END);
	}

	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			if (e.getSource() == xColErrLeftCheck) {
				xErrBarLeftColumnText.setEnabled(true);

			} else if (e.getSource() == xColErrRightCheck) {
				xErrBarRightColumnText.setEnabled(true);

			} else if (e.getSource() == yColErrTopCheck) {
				yErrBarTopColumnText.setEnabled(true);

			} else if (e.getSource() == yColErrBottomCheck) {
				yErrBarBottomColumnText.setEnabled(true);

			} else if (e.getSource() == histogramCheck) {
				binStart.setEnabled(true);
				binSize.setEnabled(true);

				xColErrLeftCheck.setSelected(false);
				xColErrRightCheck.setSelected(false);
				yColErrTopCheck.setSelected(false);
				yColErrBottomCheck.setSelected(false);

				xColErrLeftCheck.setEnabled(false);
				xColErrRightCheck.setEnabled(false);
				yColErrTopCheck.setEnabled(false);
				yColErrBottomCheck.setEnabled(false);

				yColumnText.setEnabled(false);
				xErrBarLeftColumnText.setEnabled(false);
				xErrBarRightColumnText.setEnabled(false);
				yErrBarTopColumnText.setEnabled(false);
				yErrBarBottomColumnText.setEnabled(false);

			}
		} else if (e.getStateChange() == ItemEvent.DESELECTED) {
			if (e.getSource() == xColErrLeftCheck) {
				xErrBarLeftColumnText.setEnabled(false);

			} else if (e.getSource() == xColErrRightCheck) {
				xErrBarRightColumnText.setEnabled(false);

			} else if (e.getSource() == yColErrTopCheck) {
				yErrBarTopColumnText.setEnabled(false);

			} else if (e.getSource() == yColErrBottomCheck) {
				yErrBarBottomColumnText.setEnabled(false);

			} else if (e.getSource() == histogramCheck) {
				binStart.setEnabled(false);
				binSize.setEnabled(false);

				yColumnText.setEnabled(true);
				xColErrLeftCheck.setEnabled(true);
				xColErrRightCheck.setEnabled(true);
				yColErrTopCheck.setEnabled(true);
				yColErrBottomCheck.setEnabled(true);
			}
		}
	}

	public void actionPerformed(ActionEvent e) {

		// Handle open button action.
		if (e.getSource() == openButton) {
			int returnVal = fc.showOpenDialog(fc);

			if (returnVal == JFileChooser.APPROVE_OPTION) {

				// parse standard plot data
				if (!histogramCheck.isSelected()) {

					// get columns to use
					int xCol = Integer.parseInt(xColumnText.getText());
					int yCol = Integer.parseInt(yColumnText.getText());
					int xColErrL = -1;
					int xColErrR = -1;
					int yColErrT = -1;
					int yColErrB = -1;

					// only use the required error bars
					if (xColErrLeftCheck.isSelected())
						xColErrL = Integer.parseInt(xErrBarLeftColumnText.getText());
					if (xColErrRightCheck.isSelected())
						xColErrR = Integer.parseInt(xErrBarRightColumnText.getText());
					if (yColErrTopCheck.isSelected())
						yColErrT = Integer.parseInt(yErrBarTopColumnText.getText());
					if (yColErrBottomCheck.isSelected())
						yColErrB = Integer.parseInt(yErrBarBottomColumnText.getText());

					// parse the file
					try {
						Controller.getFileData(fc.getSelectedFile(), GUI.MainWindow.lineInfoWindow.getCurrentLine(), delimText.getText(), xCol, yCol, xColErrL, xColErrR,
								yColErrT, yColErrB);
					} catch (FileNotFoundException e1) {
						//System.out.println("Could not read file");
						e1.printStackTrace();
					}

					// parse data into histogram
				} else {
					int binStartNum = 0;
					int binSizeNum = 0;
					int xCol = 0;

					boolean parsable = true;

					// get columns to use
					try {
						xCol = Integer.parseInt(xColumnText.getText());
						xColumnText.setForeground(Color.black);
					} catch (NumberFormatException e1) {
						xColumnText.setForeground(Color.red);
						parsable = false;
					}

					try {
						binSizeNum = Integer.parseInt(binSize.getText());
						binSize.setForeground(Color.black);
					} catch (NumberFormatException e1) {
						binSize.setForeground(Color.red);
						parsable = false;
					}

					try {
						binStartNum = Integer.parseInt(binStart.getText());
						binStart.setForeground(Color.black);
					} catch (NumberFormatException e1) {
						binStart.setForeground(Color.red);
						parsable = false;
					}

					// parse the file
					if (parsable) {
						try {
							Controller.getFileData(fc.getSelectedFile(), GUI.MainWindow.lineInfoWindow.getCurrentLine(), delimText.getText(), xCol, binSizeNum,
									binStartNum);
						} catch (FileNotFoundException e1) {
							System.out.println("Could not read file");
							e1.printStackTrace();
						}
					}
				}
			}
		}
	}

	/** Returns an ImageIcon, or null if the path was invalid. */
	protected static ImageIcon createImageIcon(String path) {
		java.net.URL imgURL = ImportDataWindow.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}

	/**
	 * Create the Load Window and show it.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		JFrame frame = new JFrame("Load");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Add content to the window.
		frame.add(new ImportDataWindow());

		// Display the window.
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		// Schedule a job for the event dispatch thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				// Turn off metal's use of bold fonts
				UIManager.put("swing.boldMetal", Boolean.FALSE);
				createAndShowGUI();
			}
		});
	}
}

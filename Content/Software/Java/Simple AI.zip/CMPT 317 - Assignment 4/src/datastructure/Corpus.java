/*
	Adam Knox
	ark043
	11049279
	CMPT 317
	Assignment 4
 */
package datastructure;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class Corpus {
	//The lines of data that can be searched
	private final String DOCUMENT_DELIMITER = "(NOSC)";
	private final String PARAGRAPH_DELIMITER = "   ";
	private String corpus = null;
	private String names = null;
	
	//Singleton
	private static Corpus singleton = null;;
	private Corpus () {}
	
	
	
	/**
	 * Access the singleton corpus
	 * @return the corpus
	 */
	public static Corpus get() {
		//create the corpus if it doesnt exist
		if (singleton == null) {
			singleton = new Corpus();
			singleton.corpus = "";
			singleton.names = "";
			
			//read in the name database
			try{
				  FileInputStream fstream = new FileInputStream("names.txt");
				  DataInputStream in = new DataInputStream(fstream);
				  BufferedReader br = new BufferedReader(new InputStreamReader(in));
				  String line;
				  while ((line = br.readLine()) != null)   {
					  singleton.names += line.toUpperCase() + " ";
				  }
				  in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
		}
		return singleton;
	}
	
	
	
	
	/**
	 * Add data to the corpus
	 * @param filename address of text file to add
	 */
	public void insert(String filename) {
		//open the file at filename and read its contents into the corpus
		try{
			  FileInputStream fstream = new FileInputStream(filename);
			  DataInputStream in = new DataInputStream(fstream);
			  BufferedReader br = new BufferedReader(new InputStreamReader(in));
			  String line;
			  while ((line = br.readLine()) != null)   {
				  corpus += line.toUpperCase() + " ";
			  }
			  in.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	
	
	
	/**
	 * searches the corpus for the query
	 * @param query the text to search for
	 * @return a linked list of the index in the corpus of the first character of the sequence each time it appears
	 */
	public LinkedList<Integer> search(String query) {
		LinkedList<Integer> indices = new LinkedList<Integer>();
		int index = -1;
		int startIndex = 0;
		query = query.toUpperCase();
		//works through the corpus until each instance is found and added to the list of indices
		while ((index = corpus.indexOf(query, startIndex)) >= 0) {
			indices.add(index);
			startIndex = index + query.length();
		}
		return indices;
	}
	
	
	
	
	/**
	 * finds the index of the beginning of the sentence
	 * @param startIndex the index to work backwards from
	 * @return the index of the beginning of the sentence
	 */
	public int getSentenceStart(int startIndex) {
		int firstIndex = -1;
		int i = 0;
		while (firstIndex < 0) {
			i--;
			if (corpus.substring(startIndex+i, startIndex+i+2).equals(". ")) {
				firstIndex = startIndex+i+1;
			}
		}
		return firstIndex;
	}
	
	
	
	
	/**
	 * finds the index of the end of the sentence
	 * @param startIndex the index to work forwards from
	 * @return the index of the end of the sentence
	 */
	public int getSentenceEnd(int startIndex) {
		int lastIndex = -1;
		int i = 0;
		boolean inQuotes = false;
		while (lastIndex < 0) {
			i++;
			//if a quote appears in the sentence, then end it after a quote if a period occurs immediately before the closing quote
			if (corpus.substring(startIndex+i, startIndex+i+1).equals("\"") ) {
				inQuotes = !inQuotes;
			}
			if ((corpus.substring(startIndex+i-2, startIndex+i).equals(". ") && !corpus.substring(startIndex+i-4, startIndex+i-3).equals(".") && !inQuotes) || corpus.substring(startIndex+i-2, startIndex+i).equals(".\"")) {
				lastIndex = startIndex+i;
			}
		}
		return lastIndex;
	}
	
	
	

	/**
	 * finds the index of the beginning of the paragraph
	 * @param startIndex the index to work backwards from
	 * @return the index of the beginning of the paragraph
	 */
	public int getParagraphStart(int startIndex) {
		int firstIndex = -1;
		int i = 0;
		while (firstIndex < 0) {
			i--;
			if (corpus.substring(startIndex+i, startIndex+i+PARAGRAPH_DELIMITER.length()).equals(PARAGRAPH_DELIMITER) || (startIndex+i == 0)) {
				firstIndex = startIndex+i+1;
			}
		}
		return firstIndex;
	}
	
	
	
	
	/**
	 * finds the index of the end of the paragraph
	 * @param startIndex the index to work forwards from
	 * @return the index of the end of the paragraph
	 */
	public int getParagraphEnd(int startIndex) {
		int lastIndex = -1;
		int i = 0;
		while (lastIndex < 0) {
			i++;
			if (corpus.substring(startIndex+i-PARAGRAPH_DELIMITER.length(), startIndex+i).equals(PARAGRAPH_DELIMITER)) {
				lastIndex = startIndex+i;
			}
		}
		return lastIndex;
	}
	
	
	

	/**
	 * finds the index of the beginning of the document
	 * @param startIndex the index to work backwards from
	 * @return the index of the beginning of the document
	 */
	public int getDocumentStart(int startIndex) {
		int firstIndex = -1;
		int i = 0;
		while (firstIndex < 0) {
			i--;
			if ((corpus.substring(startIndex+i, startIndex+i+DOCUMENT_DELIMITER.length()).equals(DOCUMENT_DELIMITER)) || (startIndex+i == 0)) {
				firstIndex = startIndex+i+1;
			}
		}
		return firstIndex + DOCUMENT_DELIMITER.length();
	}
	
	
	
	
	/**
	 * finds the index of the end of the document
	 * @param startIndex the index to work forwards from
	 * @return the index of the end of the document
	 */
	public int getDocumentEnd(int startIndex) {
		int lastIndex = -1;
		int i = 0;
		while (lastIndex < 0) {
			i++;
			if (corpus.substring(startIndex+i-DOCUMENT_DELIMITER.length(), startIndex+i).equals(DOCUMENT_DELIMITER)) {
				lastIndex = startIndex+i;
			}
		}
		return lastIndex;
	}
	
	
	
	
	/**
	 * returns the substring within the corpus
	 * @param startIndex the starting index in the corpus
	 * @param endIndex the ending index in the corpus
	 * @return the substring from startIndex to endIndex
	 */
	public String subStr(int startIndex, int endIndex) {
		return corpus.substring(startIndex, endIndex);
	}
	
	
	
	
	/**
	 * checks if a word is a name
	 * @param word the word on which to check the status
	 * @return true if word is a name, false if it is not
	 */
	public boolean isName(String word) {
		if (word.equals(""))
			return false;
		
		return names.contains(" " + word + " ");
	}
}

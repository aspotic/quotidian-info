/*
	Adam Knox
	ark043
	11049279
	CMPT 317
	Assignment 4
 */
package algorithm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

import datastructure.Corpus;

public class RunQuery {
	
	
	/**
	 * checks to see if a location exists within the given set of characters
	 * @param sequence the sequence of characters in which to check for the existence of a location
	 * @return the location, or blank if one was not found
	 */
	private static String findPlace(String sequence) {
		String location = "";
		boolean done = false;
		//words that often preceed a location ordered by likeliness of being next to a location
		String[] words = {"NEAR","IN","AT","BY"};
		//split and strip the sequence
		sequence = sequence.replaceAll("[^A-Za-z0-9 ]", "");
		String[] explodedSentence = sequence.split(" ");
		//look for an occurence of a word that often preceeds a location
		for (int j = 0; j < words.length && !done; j++) {
			for (int i = 0; i < explodedSentence.length && !done; i++) {
				if (explodedSentence[i].equals(words[j])) {
					//the is usually followed by a two word location. The united states, the european union
					if (explodedSentence[i+1].equals("THE")) {
						location = explodedSentence[i+1] + " " + explodedSentence[i+2] + " " + explodedSentence[i+3];
					//these types of words usually mean a two word location
					} else if (explodedSentence[i+1].equals("SAN") ||explodedSentence[i+1].equals("EL") || explodedSentence[i+1].equals("LOS")  || explodedSentence[i+1].equals("PUERTO")) {
						location = explodedSentence[i+1] + " " + explodedSentence[i+2];
					} else {
						location = explodedSentence[i+1];
					}
					done = true;
				}
			}
		}
		
		
		
		return location;
	}
	
	
	
	
	/**
	 * parses a question into a format that is easier to work with
	 * @param question a properly formatted question to parse
	 * @return a linked list containing the critical components of the question starting with type
	 */
	private static LinkedList<String> parseQuestion(String question) {
		LinkedList<String> parsedQuestion = new LinkedList<String> ();
		//splits the string by the square brackets to get the necessary information
		//who
		if (question.startsWith("WHO")) {
			parsedQuestion.add("WHO");
			String[] qList = question.split("\\[");
			parsedQuestion.add(qList[1].split("\\]")[0]);
			parsedQuestion.add(qList[2].split("\\]")[0]);
			parsedQuestion.add(qList[3].split("\\]")[0]);
			
		//what
		} else if (question.startsWith("WHAT")) {
			parsedQuestion.add("WHAT");
			String[] qList = question.split("\\[");
			parsedQuestion.add(qList[1].split("\\]")[0]);
			parsedQuestion.add(qList[2].split("\\]")[0]);
			parsedQuestion.add(qList[3].split("\\]")[0]);
			
		//when
		} else if (question.startsWith("WHEN")) {
			parsedQuestion.add("WHEN");
			String[] qList = question.split("\\[");
			parsedQuestion.add(qList[1].split("\\]")[0]);
			parsedQuestion.add(qList[2].split("\\]")[0]);
		
		//where
		} else if (question.startsWith("WHERE")) {
			parsedQuestion.add("WHERE");
			String[] qList = question.split("\\[");
			parsedQuestion.add(qList[1].split("\\]")[0]);
			parsedQuestion.add(qList[2].split("\\]")[0]);
		}
		return parsedQuestion;
	}
	
	
	
	
	/**
	 * gets an answer to the given parsed question
	 * @param question the parsed question
	 * @return the answer to the question
	 */
	private static String getResponse(LinkedList<String> question) {
		//the list of starting indices for all matching question components
		LinkedList<Integer> bodyLocations = null;
		LinkedList<Integer> placeLocations = null;
		LinkedList<Integer> timeLocations = null;
		
		//the index and score of the body that has the place and time closest to it
		int bestMatch = -1;
		int bestMatchScore = Integer.MAX_VALUE;
		
		
		//Figure out what each item in the linked list is
		String qType = question.get(0);
		String qBody = question.get(1);
		String qPlace = null;
		String qTime = null;
		if (qType.equals("WHEN")) {
			qPlace = question.get(2);
		} else if (qType.equals("WHERE")) {
			qTime = question.get(2);
		} else {
			qPlace = question.get(2);
			qTime = question.get(3);
			
		}
		
		//try to find a line that contains the given text
		bodyLocations = Corpus.get().search(qBody);
		if (bodyLocations.size() == 0) {
			return "Could not find an answer.";
		}
		
		
		//metric: diffTime+diffPlace, lower score is better
		//if multiple results have been found, then cut them down by choosing the result that is closest to references to the date and/or place
		//WHO/WHAT
		if ((qPlace != null) && (qTime != null)) {
			placeLocations = Corpus.get().search(qPlace);
			timeLocations = Corpus.get().search(qTime);
			
			//find the body, place, and time locations that are closest together
			for(int iBody: bodyLocations) {
				int closestPlace = -1;
				int closestTime = -1;
				
				for(int iPlace: placeLocations) {
					if (Math.abs(iPlace - iBody) < Math.abs(closestPlace - iBody)) {
						closestPlace = iPlace;
					}
				}
				
				for(int iTime: timeLocations) {
					if (Math.abs(iTime - iBody) < Math.abs(closestTime - iBody)) {
						closestTime = iTime;
					}
				}
				
				if (bestMatchScore > (Math.abs(closestPlace - iBody) + Math.abs(closestTime - iBody))) {
					bestMatchScore = (Math.abs(closestPlace - iBody) + Math.abs(closestTime - iBody));
					bestMatch = iBody;
				}
			}
			
			
		//WHEN
		} else if ((qPlace != null) && (qTime == null)) {
			placeLocations = Corpus.get().search(qPlace);
			
			//find the body, place, and time locations that are closest together
			for(int iBody: bodyLocations) {
				int closestPlace = -1;
				
				for(int iPlace: placeLocations) {
					if (Math.abs(iPlace - iBody) < Math.abs(closestPlace - iBody)) {
						closestPlace = iPlace;
					}
				}
				
				if (bestMatchScore > Math.abs(closestPlace - iBody)) {
					bestMatchScore = Math.abs(closestPlace - iBody);
					bestMatch = iBody;
				}
			}
			
			
		//WHERE
		} else if ((qPlace == null) && (qTime != null)) {
			timeLocations = Corpus.get().search(qTime);
			
			//find the body, place, and time locations that are closest together
			for(int iBody: bodyLocations) {
				int closestTime = -1;
				
				for(int iTime: timeLocations) {
					if (Math.abs(iTime - iBody) < Math.abs(closestTime - iBody)) {
						closestTime = iTime;
					}
				}
				
				if (bestMatchScore > Math.abs(closestTime - iBody)) {
					bestMatchScore = Math.abs(closestTime - iBody);
					bestMatch = iBody;
				}
			}
		}

		
		//Once only one result exists, then try to get the appropriate response
		//when returns a time, where return a location, who returns a person, what returns the remainder of the sentence after the string
		String result;
		String response = "No answer found";
		if (qType.equals("WHO")) {
			//pull out the sentence that the string appears in
			result = Corpus.get().subStr(Corpus.get().getSentenceStart(bestMatch),Corpus.get().getSentenceEnd(bestMatch));
			response = "no name found in result '" + result + "'";
			//check if a name occurs in the sentence, and assume it is the person being asked for
			result = result.replaceAll("[^A-Za-z ]", "");
			String words[] = result.split(" ");

			for(String word: words) {
				if (Corpus.get().isName(word)) {
					response = word;
					break;
				}
			}
			
		} else if (qType.equals("WHAT")) {
			//return the rest of the sentence
			response = Corpus.get().subStr(bestMatch+qBody.length(),Corpus.get().getSentenceEnd(bestMatch));
			
		} else if (qType.equals("WHEN")) {
			//pull out the sentence that the string appears in
			result = Corpus.get().subStr(Corpus.get().getSentenceStart(bestMatch),Corpus.get().getSentenceEnd(bestMatch));
			
			//look for a date in the sentence, if one is found, then assume it is the date being asked about
			response = FindDate.getDate(result);
			
			//if no date is found, then try the paragraph
			if (response.equals("")) {
				result = Corpus.get().subStr(Corpus.get().getParagraphStart(bestMatch),Corpus.get().getParagraphEnd(bestMatch));
				response = FindDate.getDate(result);
			}
			
			//if no date is found, then try the document
			if (response.equals("")) {
				result = Corpus.get().subStr(Corpus.get().getDocumentStart(bestMatch),Corpus.get().getDocumentEnd(bestMatch));
				response = FindDate.getDate(result);
			}
			
			if (response.equals("")) {
				response = "no date found in document";
			}
			
			
		} else if (qType.equals("WHERE")) {
			//pull out the sentence that the string appears in
			result = Corpus.get().subStr(Corpus.get().getSentenceStart(bestMatch),Corpus.get().getSentenceEnd(bestMatch));
			
			//look for a place in the sentence, if one is found, then assume it is the place being asked about
			response = "";
			response = findPlace(result);
			
			//if no place is found, then try the paragraph
			if (response.equals("")) {
				result = Corpus.get().subStr(Corpus.get().getParagraphStart(bestMatch),Corpus.get().getParagraphEnd(bestMatch));
				response = findPlace(result);
			}
			
			//if no place is found, then try the document
			if (response.equals("")) {
				result = Corpus.get().subStr(Corpus.get().getDocumentStart(bestMatch),Corpus.get().getDocumentEnd(bestMatch));
				response = findPlace(result);
			}
			
			//if no place is found, then use the document header
			if (response.equals("")) {
				response = result.split(",")[0].trim();
			}
		}
		
		if (response.equals("")) {
			response = "No answer found";
		}
		
		//return the best response
		return response;
	}
	
	
	
	
	/**
	 * Runs program
	 * @param args
	 */
	public static void main(String args[]) {
		//create corpus
		Corpus corpus = Corpus.get();
		
		//read in data
		corpus.insert("Assign 4 text (dev-muc3-0001-0100).txt");
		
		//Get questions, and try to answer them
		String question = "";
		while(!question.equals("_END_")) {
			String response = "";
			
			//get question
			System.out.print("Question: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			try {
				question = br.readLine().toUpperCase();
			} catch (IOException ioe) {
				System.out.println("Error reading question");
				System.exit(1);
			}
			
			if (!question.equals("_END_")) {
				//parse question
				LinkedList<String> parsedQuestion = RunQuery.parseQuestion(question);
				
				//search for response
				response = getResponse(parsedQuestion);
				
				
				//give response
				System.out.println(response + "\n");
			}
		}
	}
}

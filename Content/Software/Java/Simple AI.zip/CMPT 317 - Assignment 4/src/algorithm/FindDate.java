/*
	Adam Knox
	ark043
	11049279
	CMPT 317
	Assignment 4
 */
package algorithm;

public class FindDate {
	/*formats
	 8 November 2003
	 Sunday, 8 November 2003
	 
	 08-Nov-2003
	 08 Nov 03
	 08Nov03
	 
	 11/8/2003 (in canada, so should probably include this stupid format)
	 8/11/2003
	 8-11-2003
	 */
	
	private static String[] shortMonths = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
	private static String[] longMonths = {"JANUARY","FEBRUARY","MARCH","APRIL", "MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"};
	private static String[] days = {"MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"};

	
	/**
	 * 
	 * @param sequence the set of characters in which to look for a date
	 * @return a date, or blank if nothing is found
	 */
	public static String getDate(String sequence) {
		//strip the sentence of any punctuation
		sequence = sequence.replaceAll("[^A-Za-z0-9 ]", "");

		//turn the string into an array of words/numbers
		String[] explodedSentence = sequence.split(" ");
		
		//look for each date fomat
		String date = shortFormat(explodedSentence);
		if (date.equals("")) {
			date = longFormat(explodedSentence);
			if (date.equals("")) {
				date = numberFormat(explodedSentence);
			}
		}
		
		return date;
	}
	
	
	
	
	/**
	 * 
	 * @param sequence the list of words in which to look for a date
	 * @return a date, or blank if nothing can be found
	 */
	private static String shortFormat(String[] sequence) {
		String date = "";
		boolean done = false;
		//check each word in the sentence
		for (int i = 0; i < sequence.length && !done; i++) {
			//if the string is 7 characters long, then it may have been in the format 08Nov03 so split it and check it
			if (sequence[i].length() == 7) {
				String potentialDay = sequence[i].substring(0, 2);
				String potentialMonth = sequence[i].substring(2, 5);
				String potentialYear = sequence[i].substring(5, 7);
				
				//check day
				try {
					int day = Integer.parseInt(potentialDay);
					if (day <= 31 && day >= 1) {
						date = potentialDay + date;
					}
					
					//check year
					try {
						Integer.parseInt(potentialYear);
						//check month
						for (int k = 0; k < 12; k++) {
							if (potentialMonth.equals(shortMonths[k])) {
								date = sequence[i];
							}
						}
					} catch (NumberFormatException e) {}
				} catch (NumberFormatException e) {}
				
			//if it is 3 characters long, it may be a short form text month, so check it
			} else if (sequence[i].length() == 3) {
				try {
					int day = Integer.parseInt(sequence[i-1]);
					if (day <= 31 && day >= 1) {
						date = sequence[i-1];
					}
				} catch (NumberFormatException e) {}
				
				//check month
				for (int k = 0; k < 12; k++) {
					if (sequence[i].equals(shortMonths[k])) {
						date = date + " " + sequence[i];
					}
				}
				
				//check year
				try {
					int year = Integer.parseInt(sequence[i+1]);
					if (year <= 9999 && year >= 1) {
						date = date + " " + sequence[i+1];
					}
				} catch (NumberFormatException e) {}
			}
		}
		return date;
	}
	
	
	
	
	/**
	 * 
	 * @param sequence the list of words in which to look for a date
	 * @return a date, or blank if nothing can be found
	 */
	private static String longFormat(String[] sequence) {
		String date = "";
		boolean done = false;
		for (int i = 0; i < sequence.length && !done; i++) {
			for (int j = 0; (j < 12) && !done; j++) {
				if (sequence[i].equals(longMonths[j])) {
					int textPos = -2;
					date = longMonths[j];
					
					//look for year to the right. format should be 4 character year
					if (sequence[i+1].length() == 4) {
						try {
							Integer.parseInt(sequence[i+1]);
							date = date + " " + sequence[i+1];
						} catch (NumberFormatException e) {}
					}

					//look for day to the left
					try {
						int day = Integer.parseInt(sequence[i-1]);
						if (day <= 31 && day >= 1) {
							date = sequence[i-1] + " " + date;
						}
					} catch (NumberFormatException e) {
						textPos = -1;
					}
					
					//look for text day to the left
					for (int k = 0; (j < 7); j++) {
						if (sequence[i+textPos].equals(days[k])) {
							date = sequence[i+textPos] + ", " + date;
						}
					}
					done = true;
				}
			}
		}
		return date;
	}
	
	
	
	
	/**
	 * 
	 * @param sequence the list of words in which to look for a date
	 * @return a date, or blank if nothing can be found
	 */
	private static String numberFormat(String[] sequence) {
		String date = "";
		boolean done = false;
		for (int i = 0; i < sequence.length-2 && !done; i++) {
			int num1 = -1;
			int num2 = -1;
			int year = -1;
			
			try {
				num1 = Integer.parseInt(sequence[i]);
				num2 = Integer.parseInt(sequence[i+1]);
				year = Integer.parseInt(sequence[i+2]);
				
				//do a reasonably thorough check to see if the numbers represent an actual date
				if (year > 0 && year < 10000) {
					if ((num1 > 0 && num2 > 0) && ((num1 < 32 && num2 < 13) || (num1 < 13 && num2 < 32))) {
						date = sequence[i] + "/" + sequence[i+1] + "/" + sequence[i+2];
						done = true;
					}
				}
			} catch (NumberFormatException e) {}
		}
		return date;
	}	
}

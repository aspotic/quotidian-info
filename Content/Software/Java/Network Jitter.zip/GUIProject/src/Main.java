import universal.constants;
import client.CController;
import client.CModel;
import client.CView;
import network.Network;
import host.Controller;
import host.Model;
import host.View;
import host.fileController;

/*
 * The main entry point of the program.
 */
public class Main 
{
	public static void main(String[] args)
	{
		//Creates the client and host models.
		CModel cm = new CModel();
		Model model = new Model();
		//Creates the squares for the host model.
		model.createShape(25, 25, 0, constants.BORDER_WIDTH*3);
		model.createShape(300, 25, 0, constants.BORDER_WIDTH*4);
		model.createShape(300, 300, 0, constants.BORDER_WIDTH*5);
		model.createShape(25, 300, 0, constants.BORDER_WIDTH*6);
		//Creates the client and host views.
		CView cv = new CView(cm);
		View view = new View(model, constants.READ_MOUSE_FROM_FILE);
		//Creates the squares for the client model.
		cm.createShape(25, 25, 0, constants.BORDER_WIDTH*3);
		cm.createShape(300, 25, 0, constants.BORDER_WIDTH*4);
		cm.createShape(300, 300, 0, constants.BORDER_WIDTH*5);
		cm.createShape(25, 300, 0, constants.BORDER_WIDTH*6);
		//Creates the client controller and the network.
		CController cc = new CController(cm,cv);
		Network n = new Network(cc);
		
		//Uses an alternate host controller if we are reading from a file.
		if (constants.READ_MOUSE_FROM_FILE) {
			new fileController(model,view,n);
		} else
			new Controller(model,view,n);
		
	}
}

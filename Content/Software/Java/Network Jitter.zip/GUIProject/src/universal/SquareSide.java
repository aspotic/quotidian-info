package universal;

public enum SquareSide {
	left,
	right,
	top,
	bottom,
	none
}

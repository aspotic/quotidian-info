package universal;

public class Shape 
{
	
	//Relative position for the workspace.
	private int x;
	private int y;
	private double rotation;
	private int size;
	
	public Shape(int x, int y, double rotation, int size)
	{
		this.x = x;
		this.y = y;
		this.rotation = rotation;
		this.size = size;
	}
	
	public double getRotation()
	{
		return rotation;
	}
	
	public void setRotation(double rotation)
	{
		this.rotation = rotation;
		if (rotation >= Math.PI/2)
			this.rotation -= Math.PI/2;
		else if (rotation <= -Math.PI/2)
			this.rotation += Math.PI/2;
	}	
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
	public int getSize()
	{
		return size;
	}
	
	public void setSize(int size)
	{
		this.size = size;
	}
	
	public void changeLocation(int newX, int newY)
	{
		x = newX;
		y = newY;
	}
	
}


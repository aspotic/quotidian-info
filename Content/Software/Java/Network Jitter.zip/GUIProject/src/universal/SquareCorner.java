package universal;

public enum SquareCorner {
	topleft,
	topright,
	bottomleft,
	bottomright,
	none
}

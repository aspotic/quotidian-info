package universal;

public class constants {
	public static final boolean ONLY_DEAD_RECKONING = false;
	//public static final String MOUSE_DATA_FILENAME = "paul1.txt";
	
	///////////DATA INPUT//////////////
	//true will get mouse input from a file instead of the actual mouse
	public static final boolean READ_MOUSE_FROM_FILE = false;
	//the file to get some mouse actions from
	public static final String MOUSE_DATA_FILENAME = "trial_data/trevor1.txt";
	
	///////////DATA COLLECTION/////////
	//true will enable saving the mouse actions the user makes
	public static final boolean OUTPUT_MOVEMENTS_TO_FILE = false;
	//The name of the file to save the user's mouse actions to
	public static final String MOVEMENTS_FILENAME = "MOVEMENT_RESULT_FILE.txt";
	//true will enable saving mouse motion data
	public static final boolean OUTPUT_PTS_TO_FILE = false;
	//The location to save mouse motion data to
	public static final String PTS_FILENAME = "pts.txt";

	///////////ALGORITHM TUNING////////////
	//The name of the natural mouse movement database to use
	public static final String PATH_DB_FILENAME = "mouseData.txt";
	//When true, the natural mouse movement and object recognition are disabled
	//The amount of old data about the user's movements to be stored
	public static int HISTORY_LENGTH = 5;
	//Number of paths that the object recognition algorithm has to choose from
	public static final int NUMBER_OF_PATHS = 10;
	//the number of points required to be the same before assuming the mouse is no longer going to move
	public static final int NUM_SAME_PTS_CHECK = 3;
	
	///////////NETWORK//////////////
	//The time it takes to receive one packet
	public static final int PACKET_PERIOD = 15;
	//The number of milliseconds connectivity is lost for each time
	public static int NETWORK_DROP_TIME = 200;
	//The number of milliseconds to keep connectivity between break times
	public static int NETWORK_UP_TIME = 1000;
	
	///////////USABILITY////////////
	//The amount of space the user has for resizing and rotating a square
	public final static int BORDER_WIDTH = 6;
	
	//The size of the windows.
	public static final int WINDOW_WIDTH = 550;
	public static final int WINDOW_HEIGHT = 600;
	//The size of the workspaces.
	public final static int MIN_WORKSPACE_WIDTH = 500;
	public final static int MIN_WORKSPACE_HEIGHT = 500;
	
	///////////TESTING//////////////
	//Enables showing the guessed path and changes the color of the mouse cursor to blue when guessing
	public static final boolean TESTING = true;
	//Prints the user's mouse paths to the screen
	public static final boolean PRINT = false;
}

package client;

import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;

import universal.constants;
import network.MouseAction;
import network.NetworkData;

public class ApproxAlg {
	//This is the number of points that the algorithm compares to the history.
	private static final int NUM_PTS_CHECK = constants.NUM_SAME_PTS_CHECK;
	//This is the number of paths that are used for the second part of the algorithm where it chooses the path which falls closest to a rectangle.
	private static final int NUMBER_OF_PATHS = constants.NUMBER_OF_PATHS;
	//This is used to rotate a path to the histories alignment after it has been matched.
	double pathRotationAngle = 0;
	
	public ApproxAlg() {
		
	}
	/**
	 * Takes in the history of mouse actions, the database of mouse movements and the model.
	 * Returns one of the mouse movements with its position and rotation changed to match the history.
	 * This is the main algorithm for choosing the best path from the database.
	 */
	public LinkedList<NetworkData> guessPath(LinkedList<NetworkData> hist, LinkedList<LinkedList<Point>> data, CModel model){
		//lower compare values are better so it starts with the worst possible value.
		double bestcmpValue = Double.MAX_VALUE;
		double currentValue;

		LinkedList<NetworkData> h = null;
		
		LinkedList<LinkedList<Point>> bestFitList = new LinkedList<LinkedList<Point>>();
		LinkedList<LinkedList<NetworkData>> bestFitNetworkList = new LinkedList<LinkedList<NetworkData>>();
		LinkedList<NetworkData> bestFitAligned;
		LinkedList<NetworkData> bestFitScaled = new LinkedList<NetworkData> ();
		
		//Makes sure that we have history data and data in our database.
		if (!(hist == null || hist.size() < 2 || data == null || data.size() == 0)){
			//Stores the last mouse action from the history.
			MouseAction a = hist.get(0).action;
			//Removes all the history data that isn't part of the last action. 
			h = removeExtraneousData(hist);
			
			//Makes sure we still have enough history data to continue.
			if (h.size() >= NUM_PTS_CHECK){
				//If the cursor is not moving, then assume it will continue to be stationary
				int sumX = 0;
				int sumY = 0;
				for (int i = 0; i < NUM_PTS_CHECK; i++){
					sumX += h.get(i).getX();
					sumY += h.get(i).getY();
				}
				if (h.get(0).getX() == sumX/NUM_PTS_CHECK && h.get(0).getY() == sumY/NUM_PTS_CHECK) {
					//If the user hasn't moved in the last few points of history then returns an empty list.
					return new LinkedList<NetworkData> ();
				}
				
				//Uses the oldest piece of history for the starting point of the guessed path since that will be the starting point for the comparison.
				int histStartX = (int) h.getLast().getX();
				int histStartY = (int) h.getLast().getY();

				//Moves the starting point to the origin.
				h = normalize(h);
				
				//Rotates the history to match the rotation of the database.
				h = align(h);
		
				//Iterates over all the paths in the database and compares them to the history. stores the top NUMBER_OF_PATHS in bestFitList.
				for (LinkedList<Point> p: data){
					
					currentValue = compare(h,p);
					
					if (currentValue < bestcmpValue) {
						bestcmpValue = currentValue;
						bestFitList.addFirst(p);
						if (NUMBER_OF_PATHS < bestFitList.size()) {
							bestFitList.removeLast();
						}
					}
				}	
				//Goes through each path and rotates them to match the old rotation of the history.
				for (LinkedList<Point> bestFit : bestFitList) {
					if (bestFit != null){			
						bestFitAligned = new LinkedList<NetworkData> ();
						//Only uses the points after the ones that were compared.
						for (int i = NUM_PTS_CHECK; i < bestFit.size(); i++) {
							double xRotated = ((bestFit.get(i).x * Math.cos(-pathRotationAngle)) - (bestFit.get(i).y * Math.sin(-pathRotationAngle)));
							double yRotated = ((bestFit.get(i).y * Math.cos(-pathRotationAngle)) + (bestFit.get(i).x * Math.sin(-pathRotationAngle)));
							
							bestFitAligned.addLast(new NetworkData(a, (int) xRotated, (int) yRotated));
						}
						
	///SHIFT
						
						double histXdiff = h.getFirst().getX()-bestFitAligned.getFirst().getX();
						double histYdiff = h.getFirst().getY()-bestFitAligned.getFirst().getY();
						
						histStartX += histXdiff;
						histStartY += histYdiff;
			
							
						
						/*
						 Rotates the history back to its original position for use in normalizing the distance travelled.
						 for (int i = 0; i < h.size(); i++) {
							double xRotated = ((h.get(i).getX() * Math.cos(-pathRotationAngle)) - (h.get(i).getY() * Math.sin(-pathRotationAngle)));
							double yRotated = ((h.get(i).getY() * Math.cos(-pathRotationAngle)) + (h.get(i).getX() * Math.sin(-pathRotationAngle)));
							
							h.set(i,new NetworkData(a, (int) xRotated, (int) yRotated));
						}
						
						//Get the distance travelled for the best fit
						double BestFitXSum = 0;
						double BestFitYSum = 0;
						int sz = bestFitAligned.size();
						
						for (int i = 1; i < sz; i++) {
							BestFitXSum += Math.abs(bestFitAligned.get(sz - i).getX() - bestFitAligned.get(sz - 1 - i).getX());
							BestFitYSum += Math.abs(bestFitAligned.get(sz - i).getY() - bestFitAligned.get(sz - 1 - i).getY());
						}
						
						if (BestFitXSum == 0) 
							BestFitXSum = 0.01;
						if (BestFitYSum == 0) 
							BestFitYSum = 0.01;
	
						//Get the average distance traveled between points for the best fit
						double BestFitDx = BestFitXSum/sz;
						double BestFitDy = BestFitYSum/sz;
						
						//Get the distance travelled by the user
						double hXSum = 0;
						double hYSum = 0;
						sz = h.size();
						
						for (int i = 1; i < sz; i++) {
							hXSum += Math.abs(h.get(i).getX() - h.get(i-1).getX());
							hYSum += Math.abs(h.get(i).getY() - h.get(i-1).getY());
						}
						
						if (hXSum == 0) 
							hXSum = 0.01;
						if (hYSum == 0) 
							hYSum = 0.01;
						
						//Get the average distance traveled betweent points for the history
						double hDx = hXSum/sz;
						double hDy = hYSum/sz;
						
						//Get the ration between the bestfit and the history
						double scalex = hDx/BestFitDx;
						double scaley = hDy/BestFitDy10;
						
						//Handle any division by zero problems
						if (Double.isNaN(scalex) || Double.isInfinite(scalex) || (scalex == 0)) {
							scalex = 0.5;
						} else {
						}
	
						if (Double.isNaN(scaley) || Double.isInfinite(scaley) || (scaley == 0)) {
							scaley = 0.5;
						} else {
						}
						*/
						
						//Doesn't do any scaling right now.
						//Scaled up/down the best fit to match the scale of the history data
						for (int i = 0; i < bestFit.size() - h.size(); i++) {
							double xScaled = bestFitAligned.get(i).getX();//*scalex;
							double yScaled = bestFitAligned.get(i).getY();//*scaley;
							
							bestFitScaled.addLast(new NetworkData(a, (int) xScaled + histStartX, (int) yScaled + histStartY));
						}
						bestFitNetworkList.add(bestFitScaled);
					}
				}
			}
		}
		
		

		//Only guess the destination if they are not doing a special action
		if ((h == null) || h.isEmpty())
			return new LinkedList<NetworkData> ();
		
		//If the user was just moving then picks the path that gets the closest to a square.
		if (h.get(0).action.equals(MouseAction.move)) {
			return removeBadPaths(bestFitNetworkList, model);		
		} else {
			if (bestFitNetworkList.isEmpty()) {
				return new LinkedList<NetworkData> ();
			}
			else {
				//The first path is the one with the best comparison results.
				return bestFitNetworkList.getFirst();
			}
		}
		
		
		
						
	}
	
	/**
	 * Removes all the data that wasn't in the last move or drag action.
	 * @param hist The history data.
	 * @return The history data that was a part of the last move or drag action.
	 */
	private LinkedList<NetworkData> removeExtraneousData(LinkedList<NetworkData> hist){
		LinkedList<NetworkData> path = new LinkedList<NetworkData> ();

		if (hist.get(0).action == MouseAction.move || hist.get(0).action == MouseAction.drag) {
			for (int i = 0; (i < hist.size() && (hist.get(0).action == hist.get(i).action)); i++) {
				path.addLast(hist.get(i));
			}
			
		}
		
		return path;
	}
	
	/**
	 * Moves all the points so that their origin is at 0,0.
	 * @param hist The history data.
	 * @return The history data normalized to the origin.
	 */
	private LinkedList<NetworkData> normalize(LinkedList<NetworkData> hist){
		if (hist != null && hist.size() > 0){
			int startx = (int) hist.getLast().getX();
			int starty = (int) hist.getLast().getY();
			
			for (int i=0;i<hist.size();i++){
				NetworkData n = new NetworkData(hist.get(i).action,hist.get(i).getX() - startx, hist.get(i).getY() - starty);
				hist.set(i,n);
			}
		} 
		return hist;
	}
	
	/**
	 * Rotates the points using their linear regression to be aligned vertically.
	 * @param n The path that needs to be aligned vertically.
	 * @return The new vertically aligned path.
	 */
	private LinkedList<NetworkData> align(LinkedList<NetworkData> n){
		
		//Get the linear regression data for the path
		HashMap<String, Double> linRegData = Regression.Linear(n);
		
		double slope = linRegData.get("B1");
				
		//Use dot product and cross product to rotate the path to vertical based on its linear regression
		double ax = n.getFirst().getX()+n.getLast().getX();
		double ay = slope*ax;
		
		pathRotationAngle = (ax/Math.abs(ax))*(Math.acos((ay)/(Math.sqrt(ax*ax+ay*ay))));
		if (Double.isNaN(pathRotationAngle)){
			pathRotationAngle = 0;
		}
		//Rotate each point into alignment
		for (int i = 0; i < n.size(); i++) {
			double xPrime = n.get(i).getX();
			double yPrime = n.get(i).getY();
			
			double xRotated = ((xPrime * Math.cos(pathRotationAngle)) - (yPrime * Math.sin(pathRotationAngle)));
			double yRotated = ((yPrime * Math.cos(pathRotationAngle) + (xPrime * Math.sin(pathRotationAngle))));

			n.get(i).setX((int) xRotated);
			n.get(i).setY((int) yRotated);
		}
		
		//pathRotationAngle = -1* pathRotationAngle;
		
		return n;
	}
	
	/**
	 * Compares each point in the data to NUM_PTS_CHECK of history data.
	 * @param hist The history data.
	 * @param data The mouse data to be compared against the path.
	 * @return a number between 0-max_value. Values closer to 0 are better.
	 */
	private double compare(LinkedList<NetworkData> hist, LinkedList<Point> data){
		double closeness = 0;
		if ( data != null && data.size() > 1){
			
			//If the current path doesn't have enough data, then consider it not a match since it is useless
			if (NUM_PTS_CHECK + 20 >= data.size()) {
				return Double.MAX_VALUE;
			//Compare the paths
			} else {
				//more recent points are weighted higher.
				double weight = NUM_PTS_CHECK;
				//Normalizes the values based on the number of points checked, not strictly necessary if the number of points compared is always the same.
				double normalizer = NUM_PTS_CHECK * (weight/2);
				
				//Compare each point.
				for (int i = 0; i < NUM_PTS_CHECK; i++){
					closeness += weight*Math.sqrt(Math.pow((data.get(i).x - hist.get(NUM_PTS_CHECK-i-1).getX()),2) + Math.pow((data.get(i).y - hist.get(NUM_PTS_CHECK-i-1).getY()),2));
					weight--;
				}
				
				return closeness/normalizer;
			}
		} else {
			return Double.MAX_VALUE;
		}
	}
	
	/**
	 * Goes through each path and finds the one with the point that is the closest to a rectangle.
	 * The idea being that users would be approaching an object in most cases (This is not run for dragging).
	 * @param pathList a list of paths.
	 * @param model The model that has the current rectangle locations.
	 * @return The path that has the point that is the closest to a rectangle.
	 */
	private LinkedList<NetworkData> removeBadPaths(LinkedList<LinkedList<NetworkData>> pathList, CModel model) {
		
			LinkedList<NetworkData> bestPath = new LinkedList<NetworkData>();
			double bestPathMinR = Double.MAX_VALUE;
	
			//Compare each of the best paths
			for (LinkedList<NetworkData> path : pathList) {
				double r = Double.MAX_VALUE;
				
				//Check for the distance between every point and every object
				for (NetworkData point : path) {
					//Compare the distance from the point to each object
					for (int i = 0; i < model.getShapes().size(); i++) {
						double diffX = Math.abs(point.getX() - model.getShapes().get(i).getX());
						double diffY = Math.abs(point.getY() - model.getShapes().get(i).getY());
						
						double currR = Math.sqrt(diffX*diffX+diffY*diffY);
						if (currR < r)
							r = currR;
					}
				}
				
				//Set to bestPath if the path got closer to an object than the stored path
				if (bestPathMinR > r) {
					bestPathMinR = r;
					bestPath = path;
				}
			}
		
		return bestPath;
	}
}

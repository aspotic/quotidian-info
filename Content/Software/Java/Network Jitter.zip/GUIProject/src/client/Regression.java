package client;

import java.lang.Math;
import java.util.HashMap;
import java.util.LinkedList;

import network.NetworkData;

public class Regression {
	/**
	 * @author Adam Knox
	 * @description find the mean of the y values in the data set
	 * @return mean of y values from the data set
	 */
	public static double mean(LinkedList<NetworkData> data) {
		int n = 0;
		double cY;
		double yAvg = 0.0;
		double sumOfY = 0.0;

		// Start traversing the list from the top of it
		for (int i = 0; i < data.size(); i++) {
			// get they value of the current DataPoint
			cY = data.get(i).getY();
			// Calculate sum of x values
			sumOfY += cY;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		return yAvg;
	}

	/**
	 * @author Adam Knox
	 * @description does a linear regression fit for y = B0 + B1*x on the data
	 *              set, and finds the variance, standard deviation, coefficient
	 *              of determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains B0, B1, var, stdev, R^2,
	 *         and adv R^2
	 */
	public static HashMap<String, Double> Linear(LinkedList<NetworkData> n2) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double B0;
		double B1;

		double SSe; // Residual Sum of Squares

		double variance; // variance
		double stdev; // standard deviation

		double Rsquared; // Coefficient of Determination
		double adjRsquared = 0; // Adjusted Coefficient of Determination

		int n = 0;
		int p = 1;
		double Sxx = 0;
		double Sxy = 0;
		double SSt = 0;
		double yAvg = 0;
		double xAvg = 0;
		double sumOfY = 0;
		double sumOfX = 0;

		// Start traversing the list from the top of it
		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < n2.size(); i++) {
			// get they value of the current DataPoint
			cY = n2.get(i).getY();
			cX = n2.get(i).getX();

			// Calculate sum of x and y values
			sumOfY += cY;
			sumOfX += cX;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y and x values
		yAvg = sumOfY / n;
		xAvg = sumOfX / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < n2.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = n2.get(i).getX();
			cY = n2.get(i).getY();

			// Calculate Sxx, which is the sum of (xi - xAvg)(xi - xAvg)
			Sxx += (cX - xAvg) * (cX - xAvg);

			// Calculate Sxy, which is the sum of (xi - xAvg)(yi - yAvg)
			Sxy += (cX - xAvg) * (cY - yAvg);

			// Calculate SSt
			SSt += (cY - yAvg) * (cY - yAvg);
		}

		// Calculate Regression Coefficients
		B1 = Sxy / Sxx;
		B0 = yAvg - B1 * xAvg;

		// Calculate Residual Sum of Squares (SSe) & Regression Sum of Squares
		// (SSr)
		SSe = 0;
		// SSr = 0;
		for (int i = 0; i < n2.size(); i++) {
			double yHat;

			// get the x and y values of the current DataPoint
			cX = n2.get(i).getX();
			cY = n2.get(i).getY();

			// Calculate yHat for this DataPoint
			yHat = B0 + B1 * cX;

			// Calculate SSe
			SSe += (cY - yHat) * (cY - yHat);
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		retStruct.put("B0", B0);
		retStruct.put("B1", B1);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);
		retStruct.put("power", 1.0);

		// Return the string
		return retStruct;
	}
	
	

	/**
	 * @author Adam Knox
	 * @description does a polynomial regression fit for y=B0 + B1*x + B2*x^2 +
	 *              ... on the data set, and finds the variance, standard
	 *              deviation, coefficient of determination, and adjusted
	 *              coefficient of determination
	 * @param int power; the order of the polynomial
	 * @return HashMap<String, Double> that contains B0, B1, B2, ..., var,
	 *         stdev, R^2, and adv R^2
	 */
	/*
	public static HashMap<String, Double> Polynomial(LinkedList<NetworkData> data, int power) {
		power++;

		double cX;
		double cY;

		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = power - 1;
		
		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();

			// Calculate sum of x and y values
			sumOfY += cY;

			// set the number of DataPoints retrieved
			n++;
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate SSt
			SSt += (cY - yAvg) * (cY - yAvg);
		}

		// Create map
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		// Create matrices
		Matrix multiples = new Matrix((2 * power), 1);
		Matrix Bvalues = new Matrix(power, 1);
		Matrix equalsMatrix = new Matrix(power, 1);
		Matrix systemMatrix = new Matrix(power, power);

		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Populate the matrix that contains what the system is equal to &
			// the first half of the multiples matrix
			for (int j = 0; j < power; j++) {
				multiples.set(j, 0, (multiples.get(j, 0) + Math.pow(cX, j)));
				equalsMatrix.set(j, 0, (equalsMatrix.get(j, 0) + cY * Math.pow(cX, j)));
			}

			// Populate the rest of the multiples
			for (int j = power; j < (power * 2); j++) {
				multiples.set(j, 0, (multiples.get(j, 0) + Math.pow(cX, j)));
			}
		}

		// Set up the system of equations
		for (int i = 0; i < power; i++) {
			for (int j = 0; j < power; j++) {
				systemMatrix.set(i, j, multiples.get((i + j), 0));
			}
		}

		// Get the result matrix
		Bvalues = MatrixOps.multiply(MatrixOps.inverseGJ(systemMatrix), equalsMatrix);

		// Calculate Residual Sum of Squares (SSe) & Regression Sum of Squares
		// (SSr)
		for (int i = 0; i < data.size(); i++) {
			double yHat;

			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// Calculate yHat for this DataPoint
			yHat = 0;
			for (int j = 0; j < Bvalues.getH(); j++) {
				yHat += Bvalues.get(j, 0) * Math.pow(cX, j);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// put coefficients and error results in return struct
		for (int i = 0; i < power; i++) {
			retStruct.put("B" + i, Bvalues.get(i, 0));
		}
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);
		retStruct.put("power", (double) (power - 1));

		return retStruct;
	}
*/
	/**
	 * @author Adam Knox
	 * @description does a power regression fit for y=A*x^B on the data set, and
	 *              finds the variance, standard deviation, coefficient of
	 *              determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Power(LinkedList<NetworkData> data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat;

		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOflnX = 0;
		double sumOflnY = 0;
		double sumOflnXlnY = 0;
		double sumOflnXlnX = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate sum of x and y values
				sumOfY += cY;
				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Get DataPoint data that requires DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate SSt
				SSt += (cY - yAvg) * (cY - yAvg);
				sumOflnX += Math.log(cX);
				sumOflnY += Math.log(cY);
				sumOflnXlnY += Math.log(cX) * Math.log(cY);
				sumOflnXlnX += Math.log(cX) * Math.log(cX);
			}
		}

		// calculate the coefficients
		b = (n * sumOflnXlnY - sumOflnX * sumOflnY) / (n * sumOflnXlnX - sumOflnX * sumOflnX);
		a = (sumOflnY - (b * sumOflnX)) / n;

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cX != 0) && (cY != 0)) {
				// Calculate yHat for this DataPoint
				yHat = Math.exp(a) * Math.pow(cX, b);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A*x^B; B=b, A=e^a

		retStruct.put("A", Math.exp(a));
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a logarithmic regression fit for y=A + B*ln(x) on the
	 *              data set, and finds the variance, standard deviation,
	 *              coefficient of determination, and adjusted coefficient of
	 *              determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Logarithmic(LinkedList<NetworkData> data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat = 0;
		double SSe = 0;
		double stdev = 0;
		double variance = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOflnX = 0;
		double sumOflnXy = 0;
		double sumOflnXlnX = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if (cX != 0) {
				// Calculate sum of x and y values
				sumOfY += cY;

				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if (cX != 0) {
				SSt += (cY - yAvg) * (cY - yAvg);
				sumOflnX += Math.log(cX);
				sumOflnXlnX += Math.log(cX) * Math.log(cX);
				sumOflnXy += Math.log(cX) * cY;
			}
		}

		// calculate the coefficients
		b = (n * sumOflnXy - sumOflnX * sumOfY) / (n * sumOflnXlnX - sumOflnX * sumOflnX);
		a = (sumOfY - (b * sumOflnX)) / n;

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if (cX != 0) {
				// Calculate yHat for this DataPoint
				yHat = a + b * Math.log(cX);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (variance; sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A + B*ln(x); A = a; B = b
		retStruct.put("A", a);
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}

	/**
	 * @author Adam Knox
	 * @description does a power regression fit for y=A*e^(Bx) on the data set,
	 *              and finds the variance, standard deviation, coefficient of
	 *              determination, and adjusted coefficient of determination
	 * @return HashMap<String, Double> that contains A, B, var, stdev, R^2, and
	 *         adv R^2
	 */
	public static HashMap<String, Double> Exponential(LinkedList<NetworkData> data) {
		HashMap<String, Double> retStruct = new HashMap<String, Double>();

		double cX;
		double cY;

		double a;
		double b;

		double yHat = 0;
		double SSe = 0;
		double variance = 0;
		double stdev = 0;
		double Rsquared = 0;
		double adjRsquared = 0;

		double sumOfxy = 0;
		double sumOfxylnY = 0;
		double sumOflnYy = 0;
		double sumOfxxy = 0;

		double SSt = 0;
		double yAvg = 0;
		double sumOfY = 0;

		int n = 0;
		int p = 1;

		// Get DataPoint data that doesn't require DataPoint average information
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cY = data.get(i).getY();
			cX = data.get(i).getX();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate sum of x and y values
				sumOfY += cY;

				// set the number of DataPoints retrieved
				n++;
			}
		}

		// Calculate the average y value
		yAvg = sumOfY / n;

		// Start traversing the list from the top of it
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate SSt
				SSt += (cY - yAvg) * (cY - yAvg);

				sumOfxy += cX * cY;
				sumOfxylnY += cX * cY * Math.log(cY);
				sumOflnYy += cY * Math.log(cY);
				sumOfxxy += cX * cX * cY;
			}
		}

		// calculate the coefficients
		a = (sumOfxxy * sumOflnYy - sumOfxy * sumOfxylnY) / (sumOfY * sumOfxxy - sumOfxy * sumOfxy);
		b = (sumOfY * sumOfxylnY - sumOfxy * sumOflnYy) / (sumOfY * sumOfxxy - sumOfxy * sumOfxy);

		// calculate SSe
		for (int i = 0; i < data.size(); i++) {
			// get the x and y values of the current DataPoint
			cX = data.get(i).getX();
			cY = data.get(i).getY();

			// cant handle ln(0)
			if ((cY != 0) && (cX != 0)) {
				// Calculate yHat for this DataPoint
				yHat = Math.exp(a) * Math.exp(cX * b);

				// Calculate SSe
				SSe += (cY - yHat) * (cY - yHat);
			}
		}

		// Calculate Variance (sigma^2)
		variance = SSe / (n - 2);

		// Calculate Standard Deviation (sigma)
		stdev = Math.sqrt(variance);

		// Calculate Coefficient of Determination (R^2)
		Rsquared = 1 - (SSe / SSt);

		// Calculate Adjusted Coefficient of Determination (R^2)
		if (n - p - 1 != 0) {
			adjRsquared = 1 - (1 - Rsquared) * ((n - 1) / (n - p - 1));
		} else {
			adjRsquared = Rsquared;
		}

		// Get the resulting data ready to be returned
		// y = A*e^(B*x); A = exp(a); B = b
		retStruct.put("A", Math.exp(a));
		retStruct.put("B", b);
		retStruct.put("var", variance);
		retStruct.put("stdev", stdev);
		retStruct.put("R^2", Rsquared);
		retStruct.put("adj R^2", adjRsquared);

		return retStruct;
	}
}
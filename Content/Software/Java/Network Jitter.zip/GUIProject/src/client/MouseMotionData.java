//^.[^c]*?[)][ ]
//REGULAR EXPRESSION MATCHES A POINT OF DATA.
//USE C TO STOP IT FROM MATCHING EVERYTHING.
package client;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;

import universal.constants;

import network.MouseAction;
import network.NetworkData;

/**
 * Reads in the database of mouse movements.
 */
public class MouseMotionData {
	private LinkedList<LinkedList<Point>> data;
	public MouseMotionData(){
		data = new LinkedList<LinkedList<Point>>();
		try {
			FileInputStream fstream = new FileInputStream(constants.PATH_DB_FILENAME);
			DataInputStream dstream = new DataInputStream(fstream);
			BufferedReader reader = new BufferedReader(new InputStreamReader(dstream));
			String line;
				//Goes through each line and splits up the move movements so that it can read them.
				while ((line = reader.readLine()) != null){
					LinkedList<Point> points = new LinkedList<Point>();
					String stringPoints[] = line.split("[)][ ][(]");
					stringPoints[0] = stringPoints[0].substring(1);
					stringPoints[stringPoints.length - 1] = stringPoints[stringPoints.length - 1].split("[)]")[0];
					//Creates a list of points for each line of data.
					for (int i=0; i < stringPoints.length;i++){
						int x = (int) Double.parseDouble(stringPoints[i].split(",")[0]);
						int y = (int) Double.parseDouble(stringPoints[i].split(",")[1]);
						Point p = new Point(x,y);
						points.add(p);
					}					
					
					//Normalizes the points to the origin.
					points = normalize(points);
		
					//rotates the points to the vertical position.
					points = align(points);
					
				
					data.add(points);
				}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	/**
	 * Uses linear regression to rotate the path to the vertical position.
	 * @param n the path.
	 * @return the vertically aligned path
	 */
	private LinkedList<Point> align(LinkedList<Point> n){
		
		double pathRotationAngle = 0;
		
		//Get the linear regression data for the path
		LinkedList<NetworkData> pts = new LinkedList<NetworkData>();
		for (Point netData : n) {
			pts.add(new NetworkData(MouseAction.click,netData.x, netData.y));
		}
		
		HashMap<String, Double> linRegData = Regression.Linear(pts);
		
		double slope = linRegData.get("B1");
				
		//Use dot product and cross product to rotate the path to vertical based on its linear regression
		double ax = n.getFirst().getX()+n.getLast().getX();
		double ay = slope*ax;
		
		pathRotationAngle = (ax/Math.abs(ax))*Math.acos((ay)/(Math.sqrt(ax*ax+ay*ay)));
		

		//Rotate each point into alignment
		for (int i = 0; i < n.size(); i++) {
			double xPrime = n.get(i).getX();
			double yPrime = n.get(i).getY();
			
			double xRotated = ((xPrime * Math.cos(pathRotationAngle)) - (yPrime * Math.sin(pathRotationAngle)));
			double yRotated = ((yPrime * Math.cos(pathRotationAngle) + (xPrime * Math.sin(pathRotationAngle))));

			n.get(i).setLocation(xRotated, yRotated);
		}
		
		return n;
	}
	
	
	/**
	 * Moves the points so they start at the origin 0,0.
	 * @param points The path that is being moved.
	 * @return The path starting at 0,0.
	 */
	private LinkedList<Point> normalize(LinkedList<Point> points)
	{
		if (points != null && points.size() > 0){
			int startx = points.get(0).x;
			int starty = points.get(0).y;
			for (int i=0;i<points.size();i++){
				Point p = new Point(points.get(i).x - startx, points.get(i).y - starty);
				points.set(i,p);
			}
			return points;
		} else {
			return null;
		}
	}
	
	/**
	 * @return The list of mouse data.
	 */
	public LinkedList<LinkedList<Point>> getData () {
		return data;
	}
}

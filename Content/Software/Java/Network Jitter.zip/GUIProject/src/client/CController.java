package client;


import host.Model;

import java.util.LinkedList;

import network.MouseAction;
import network.NetworkData;

import universal.Shape;
import universal.SquareCorner;
import universal.SquareSide;
import universal.constants;

public class CController extends Thread {
	//Motion Data Lists
	private LinkedList<NetworkData> guessedPoints;			//The list of points to follow while guessing
	private LinkedList<NetworkData> receivedData;			//The list of data that has not been received from the network, but not processed yet
	private LinkedList<NetworkData> history;				//The list of correct and processed data
	
	//Special Classes
	private ApproxAlg alg;									//The approximation algorithm
	private CModel model;									//The model to use on the client side
	private CView view;										//The client window
	
	//Object Movement Variables
	private int xOffset = 0;								//Difference between left side of a square and the cursor's x position
	private int yOffset = 0;								//Difference between top side of a square and the cursor's y position
	private SquareSide currentResizeSide = SquareSide.none;	//The side of the square that the cursor is currently on
	private Shape currentMovingNode;						//The node currently being moved
	
	private MouseMotionData mouseMotionData;
	
	//Network Tracking
	private long lastReceiveTime;

	private int drxDiff = 0;
	private int dryDiff = 0;

	
	/**
	 * CController constructor
	 * @param m client model to use
	 * @param v client view to use
	 */
	public CController(CModel m, CView v) {
		//Setup global variables
		model = m;
		view = v;
		alg = new ApproxAlg();
		mouseMotionData = new MouseMotionData();
		receivedData = new LinkedList<NetworkData>();
		history = new LinkedList<NetworkData>();
		lastReceiveTime = System.currentTimeMillis();
		
		//Start run function
		this.setDaemon(true);
		this.start();
	}
	
	
	
	
	
	/**
	 * The main thread function run when CController is started
	 * This function gets the network data, guesses if no network data is available, and sets the model
	 * If mouse actions were guessed and new network data is received, the guesses are scrubbed and the
	 * new network data is used in place of them.
	 */
	public void run () {
		//Notify the model we will not be following guesses to start with
		model.setFollowingGuesses(false);	
		
		//Continuously check if the network has sent data
		while (true) {
			//If the server has not sent data for twice the time it takes to get a packet, then start guessing
			if (isReceivedDataEmpty()) {
				if (System.currentTimeMillis() - lastReceiveTime >= constants.PACKET_PERIOD*2) {
					//If this is the first guess in a sequence of guesses, then get the sequence of data to follow
					if (!model.isFollowingGuesses()) {
						//If only dead reckoning is to be used, then don't follow a list of preset points (dead reckoning algorithm is run every time
						if (constants.ONLY_DEAD_RECKONING) {
							guessedPoints = new LinkedList<NetworkData>();
						//If the approximation algorithm is to be used then run it to get a path to follow based on previous cursor data
						} else {
							guessedPoints = alg.guessPath(history, mouseMotionData.getData(), model);
						}
						//Notify the model of the guessing
						model.setLastGuessedPath(guessedPoints);
						model.setFollowingGuesses(true);
					}
					
					//If there are preset points to follow then use the next one in the list for the next guess
					if (!guessedPoints.isEmpty()) {
						doAction(guessedPoints.pop());
					//If there are no preset guesses to follow, and enough history, then run dead reckoning
					} else {
						if (history.size() >= 2) {
								doAction(deadReckoning());
						}
					}
					
					try {
						Thread.sleep(constants.PACKET_PERIOD);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			//The client has data from the network, so process all of it
			} else {
				while (!receivedData.isEmpty()) {	
					if (model.isFollowingGuesses()) {
						if (history.size() >= 2)
							endDeadReckoning();
					}
					
					//Make sure the model knows guesses are no longer being followed, then do the mouse action
					model.setFollowingGuesses(false);
					NetworkData currData = getLastReceivedData();
					doAction(currData);
					
					//Add the just completed action to the history of actions.  Drop the oldest action if the list length has been reached
					if (history.size() < constants.HISTORY_LENGTH){
						history.addFirst(currData);
					} else
					{
						history.removeLast();
						history.addFirst(currData);
					}
				}
			}
		}
	}
	
	
	
	
	
	/**
	 * Guesses the cursor's next position using dead reckoning
	 * @return the guess for the cursor's next position
	 */
	private NetworkData deadReckoning() {
		//Store the last two good points
		NetworkData history1 = history.get(0);
		NetworkData history2 = history.get(1);
		
		//Each time dead reckoning is called, the distance traveled in the last real travel is added 
		drxDiff += history1.getX() - history2.getX();
		dryDiff += history1.getY() - history2.getY();
	
		//Return the new mouse position with the action it is currently performing. (we assume a click means it now drags, and a release means its now moving
		if (history1.action == MouseAction.drag || history1.action == MouseAction.click)
			return new NetworkData(MouseAction.drag, history1.getX()+drxDiff, history1.getY()+dryDiff);
		else //if (history1.action == MouseAction.move || history1.action == MouseAction.release )
			return new NetworkData(MouseAction.move, history1.getX()+drxDiff, history1.getY()+dryDiff);
	}
	
	
	
	private void endDeadReckoning() {
		if (history.get(0).action == MouseAction.drag || history.get(0).action == MouseAction.click) {
			dragMouse((int)history.get(0).getX(), (int)history.get(0).getY());
		} else {
			moveMouse((int)history.get(0).getX(), (int)history.get(0).getY());
		}
		drxDiff = 0;
		dryDiff = 0;
	}
	
	
	
	/**
	 * Figures out what the mouse is doing, then calls the appropriate mouse action
	 * @param currData the mouse data
	 */
	private void doAction(NetworkData currData) {
		if (!(Double.isInfinite(currData.getX()) || Double.isNaN(currData.getX()) || Double.isInfinite(currData.getY()) || Double.isNaN(currData.getY()))) {
			model.setMouseX((int)currData.getX());
			model.setMouseY((int)currData.getY());
			
			if (MouseAction.click == currData.action) {
				clickMouse((int)currData.getX(), (int)currData.getY());
			} else if (MouseAction.drag == currData.action) {
				dragMouse((int)currData.getX(), (int)currData.getY());
			} else if (MouseAction.move == currData.action) {
				moveMouse((int)currData.getX(), (int)currData.getY());
			} else if (MouseAction.release == currData.action) {
				releaseMouse((int)currData.getX(), (int)currData.getY());
			}
		}
	}
	
	
	
	
	
	/**
	 * Moves the mouse to the given position
	 * @param x new x position
	 * @param y new y position
	 */
	public void moveMouse(int x, int y) {
		//update the model to reflect whether the cursor is on a resize or rotation point of a rectangle
		if (model.isOnRotatePoint(x, y) != SquareCorner.none) {
				model.setRotationMode(true);
				model.setResizeMode(false);
		} else if (model.isOnResizePoint(x, y) != SquareSide.none) {
				model.setResizeMode(true);
				model.setRotationMode(false);
		} else {
			model.setResizeMode(false);
			model.setRotationMode(false);
		}
		
		//Update the view to model the model changes
		view.updateView(model);
	}
	
	
	
	
	
	/**
	 * Clicks the mouse at the given position
	 * @param x the x position to click
	 * @param y the y position to click
	 */
	public void clickMouse(int x, int y) {	
		Shape n = null;
		
		//find the object being rotated
		if (model.getRotationMode()) {
			n = model.getRotationShape(x, y);
			
		//find the object being resized
		} else if (model.getResizeMode()) {
			n = model.getResizeShape(x, y);
			currentResizeSide = model.isOnResizePoint(x, y);
			
		//find any object on the same point as the mouse
		} else {
			n = model.findShape(x, y);
		}
		
		// if a shape was found, then do something to it
		if (n != null) {
			//mouse clicked, and on a shape, so set this shape to the shape being transformed
			currentMovingNode = n;
			
			//Set the proper mouse offset from the object's active point
			if (model.getRotationMode() || model.getResizeMode()) {
				xOffset =x;
				yOffset =y;
			} else {
				xOffset = x - n.getX();
				yOffset = y - n.getY();
			}
		}
		
		//Update what the user sees
		view.updateView(model);
	}
	
	
	

	
	/**
	 * Releases the client mouse at the given location
	 * @param x the x position to release
	 * @param y the y position to release
	 */
	public void releaseMouse(int x, int y) {
		//Drag the mouse to this position so that the model is updated to the new position correctly
		dragMouse(x,y);		
		//If the mouse is no longer being dragged then don't store a node for moving.
		currentMovingNode = null; 
		//Update the view
		view.updateView(model);
	}
	
	
	
	
	
	/**
	 * drags the mouse to the given position
	 * @param x the x position to drag to
	 * @param y the y position to drag to
	 */
	public void dragMouse(int x, int y) {
		 //operate on the active shape
		if (currentMovingNode != null) {
			//If currently resizing, then resize the active shape. Also limit the minimum size
			if (model.getResizeMode()) {
				int size = 0;
				int sizeChange = 0;
				//Resize using top as clicked side
				if (currentResizeSide.equals(SquareSide.top)) {
					sizeChange = currentMovingNode.getY() - y;
					size = sizeChange + currentMovingNode.getSize();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					} else {
						model.moveShape(currentMovingNode, currentMovingNode.getX()-sizeChange, currentMovingNode.getY()-sizeChange);
					}
					currentMovingNode.setSize(size);
					
				//Resize using bottom as clicked side
				} else if (currentResizeSide.equals(SquareSide.bottom)) {
					size = y - currentMovingNode.getY();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					}
					currentMovingNode.setSize(size);
					
				//Resize using left as clicked side
				} else if (currentResizeSide.equals(SquareSide.left)) {
					sizeChange = currentMovingNode.getX() - x;
					size = sizeChange + currentMovingNode.getSize();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					} else {
						model.moveShape(currentMovingNode, currentMovingNode.getX()-sizeChange, currentMovingNode.getY()-sizeChange);
					}
					currentMovingNode.setSize(size);
					
				//Resize using right as clicked side
				} else {
					size = x - currentMovingNode.getX();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					}
					currentMovingNode.setSize(size);
				} 
				
			//If currently rotating, then rotate the active shape
			} else if (model.getRotationMode()) {

				//Center of square
				double p1x = currentMovingNode.getX() + currentMovingNode.getSize()/2;
				double p1y = currentMovingNode.getY() + currentMovingNode.getSize()/2;
				
				//cursor's new drag position
				double p2x = x - p1x;
				double p2y = y - p1y;
				
				//Cursor's old drag position
				double p3x = xOffset - p1x;
				double p3y = yOffset - p1y;
				
				//magnitude of vectors
				double p2Mag = Math.sqrt(p2x*p2x+p2y*p2y);
				double p3Mag = Math.sqrt(p3x*p3x+p3y*p3y);
				
				//Dot product rule for selection the rotation angle
				double changeInRotation = Math.acos((p2x*p3x+p2y*p3y)/(p2Mag*p3Mag)); 
				
				//Cross Product
				double crossProduct = p3x*p2y-p2x*p3y;
				
				//trig comparison for finding angle directionality
				changeInRotation = changeInRotation*(crossProduct/Math.abs(crossProduct));

				//Trap NaN value
				if (Double.isNaN(changeInRotation)) {
					changeInRotation = 0;
				}

				//Set the new rotation
				double newRotation = changeInRotation + currentMovingNode.getRotation();
				currentMovingNode.setRotation(newRotation);
				
				//Update the offset
				xOffset = x;
				yOffset = y;
				
			//Move the object to the current location
			} else {
				//The new x location of the node, can't be less then 0.
				int moveX = x - xOffset;
				if (moveX < 0) {
					moveX = 0;
				}
			
				//The new y location of the node, can't be less then 0.
				int moveY = y - yOffset;
				if (y-yOffset< 0) {
					moveY = 0;
				}
				
				//Move the shape
				model.moveShape(currentMovingNode,moveX, moveY);
			}
		}
		
		//Update the view
		view.updateView(model);
	}
	
	
	
	
	
	/**
	 * Network Listener. Listens for data from the network, then puts any received data in the controller
	 * @param data the data received from the network
	 */
	public synchronized void receiveData(NetworkData data) {
		lastReceiveTime = System.currentTimeMillis();
		receivedData.addFirst(data);
	}
	
	

	
	
	/**
	 * checks if there is any unprocessed received data
	 * @return true if there is no received data, false otherwise
	 */
	public synchronized boolean isReceivedDataEmpty () {
		return receivedData.isEmpty();
	}
	
	
	
	
	
	/**
	 * gets the last received data
	 * @return the last received data
	 */
	public synchronized NetworkData getLastReceivedData () {
		NetworkData data = receivedData.getLast();
		receivedData.removeLast();
		return data;
	}
}


package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Scrollable;

import universal.Shape;
import universal.constants;



@SuppressWarnings("serial")
public class CView extends JFrame
{
	private static final boolean TESTING = constants.TESTING;
	private static final int WINDOW_WIDTH = constants.WINDOW_WIDTH;
	private static final int WINDOW_HEIGHT = constants.WINDOW_HEIGHT;
	private Workspace workspace;
	
	public CView(CModel m)
	{
		createAndDisplayGUI(m);
	}
	//Makes the GUI and displays it.
		private void createAndDisplayGUI(CModel m)
		{
			//Creates the window.
			JFrame frame = new JFrame("Jitter Project. CLIENT");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			//creates the content pane and adds it to the frame.
			JPanel mainPane = new JPanel();
			frame.setContentPane(mainPane);
			
			//Creates the workspace and sets its dimensions.
			workspace = new Workspace(m);
			workspace.setBackground(Color.WHITE);
			//Creates the scroll pane.
			JScrollPane scrollPane = new JScrollPane(workspace);
			workspace.setSize(m.getWidth(),m.getHeight());
			workspace.setPreferredSize(new Dimension(m.getWidth(),m.getHeight()));
			workspace.setMinimumSize(new Dimension(m.getWidth(),m.getHeight()));
			
			mainPane.add(scrollPane,BorderLayout.CENTER);

			
			frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //sets the size of the window.
			frame.setVisible(true); //Makes the window visible.
		}
		
		//Update view updates the view based on the model.
		public void updateView(CModel m)
		{
				workspace.requestFocusInWindow();
				workspace.setSize(m.getWidth(),m.getHeight());
				workspace.setPreferredSize(new Dimension(m.getWidth(),m.getHeight()));
				workspace.setMinimumSize(new Dimension(m.getWidth(),m.getHeight()));
			if (m.isCatchingUp() == false){
				workspace.repaint();
			}
		}
		

		
		public class Workspace extends JLabel implements Scrollable 
		{
			//Needs to know about the model to get the shape info.
			private CModel model;
			
			public Workspace(CModel model)
			{
				this.model = model;
			}
			
			
			//This is where everything is drawn.
			public void paintComponent(Graphics g) 
			{
				setBackground(Color.WHITE);
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, model.getWidth(), model.getHeight());
				
				Graphics2D g2D = (Graphics2D) g;
				drawSquares(g2D);
				drawPointer(g2D);
				g.setColor(Color.pink);
				//If we are in testing mode then shows the lines of the paths.
				if (TESTING) {
					for (int i=1;i<model.getLastGuessedPath().size();i++){
						g2D.drawLine((int)model.getLastGuessedPath().get(i-1).getX(),(int)model.getLastGuessedPath().get(i-1).getY(),(int)model.getLastGuessedPath().get(i).getX(),(int)model.getLastGuessedPath().get(i).getY());
					}
				}
			}

			/**
			 * Draws the mouse pointer dot.
			 */
			private void drawPointer(Graphics2D g)
			{
				if (TESTING) {
					if (model.isFollowingGuesses())
						g.setColor(Color.cyan);
					else
						g.setColor(Color.red);
				} else {
					g.setColor(Color.red);
				}
				
				g.fillOval(model.getMouseX()-4, model.getMouseY()-4, 8, 8);
			}
			
			/**
			 * Draws the squares.
			 */
			private void drawSquares(Graphics2D g)
			{
				List<Shape> nodes = model.getShapes();
				for (Shape n : nodes )
				{
					double xMiddleSquare = n.getX() + n.getSize()/2;
					double yMiddleSquare = n.getY() + n.getSize()/2;
					//Middle of the rectangle for rotating.
					g.rotate(n.getRotation(),xMiddleSquare,yMiddleSquare);
					g.translate(n.getX(), n.getY());
					if (model.getResizeMode()) {
						g.setColor(Color.black);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						g.setColor(Color.green);
						g.fillRect(CModel.BORDER_WIDTH, CModel.BORDER_WIDTH, n.getSize()-(2*CModel.BORDER_WIDTH), n.getSize()-(2*CModel.BORDER_WIDTH)); //Fills in the rectangle.
					} else if (model.getRotationMode()) {
						g.setColor(Color.black);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						g.setColor(Color.yellow);
						g.fillRect(CModel.BORDER_WIDTH, CModel.BORDER_WIDTH, n.getSize()-(2*CModel.BORDER_WIDTH), n.getSize()-(2*CModel.BORDER_WIDTH)); //Fills in the rectangle.
					} else {
						g.setColor(Color.black);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						g.setColor(Color.blue);
						g.fillRect(CModel.BORDER_WIDTH, CModel.BORDER_WIDTH, n.getSize()-(2*CModel.BORDER_WIDTH), n.getSize()-(2*CModel.BORDER_WIDTH)); //Fills in the rectangle.
					}
					
					g.translate(-n.getX(), -n.getY()); //Back to the origin.
					g.rotate(-n.getRotation(),xMiddleSquare,yMiddleSquare);
				}
			}
			
			//Used for scrolling.
			@Override
			public Dimension getPreferredScrollableViewportSize() 
			{
				return new Dimension(model.getWidth(),model.getHeight());
			}
			@Override
			public int getScrollableBlockIncrement(Rectangle arg0, int arg1, int arg2) 
			{
				return 1;
			}
			@Override
			public boolean getScrollableTracksViewportHeight() {
				return false;
			}
			@Override
			public boolean getScrollableTracksViewportWidth() {
				return false;
			}
			@Override
			public int getScrollableUnitIncrement(Rectangle arg0, int arg1, int arg2) {
				return 1;
			}
		}
}

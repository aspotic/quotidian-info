package client;

import java.util.LinkedList;
import java.util.List;

import network.NetworkData;

import universal.Shape;
import universal.SquareCorner;
import universal.SquareSide;
import universal.constants;


public class CModel 
{
		public final static int BORDER_WIDTH = constants.BORDER_WIDTH;
		public final static int MIN_WORKSPACE_WIDTH = constants.MIN_WORKSPACE_WIDTH;
		public final static int MIN_WORKSPACE_HEIGHT = constants.MIN_WORKSPACE_HEIGHT;
		//A list of all the squares.
		private List<Shape> shapes;
		
		private int width = MIN_WORKSPACE_WIDTH; //The width needed to display the model.
		private int height = MIN_WORKSPACE_HEIGHT; //The height needed to display the model.

		private Boolean rotationMode = false;
		private Boolean resizeMode = false;
		
		private int mouseX = 0;
		private int mouseY = 0;
		
		private boolean followingGuesses = false;
		private boolean catchingUp = false;
		private LinkedList<NetworkData> lastGuessedPath = new LinkedList<NetworkData>();
		
		/**
		 * Constructor for the client model.
		 */
		public CModel()
		{
			shapes = new LinkedList<Shape>();
		}
		
		/**
		 * Stretches the window if an object goes out of the window.
		 */
		private void updateDimensions()
		{
			width = MIN_WORKSPACE_WIDTH;
			height = MIN_WORKSPACE_HEIGHT;
			for (Shape n : shapes)
			{
				if (n.getX()+n.getSize() > width)
				{
					width = n.getX()+n.getSize();
				}
				if (n.getY()+n.getSize() > height)
				{
					height = n.getY() + n.getSize();
				}
			}
		}
		
		public List<Shape> getShapes()
		{
			return shapes;
		}
		
		
		public void addShape(Shape n)
		{
			shapes.add(n);
		}
		
		/**
		 * Creates a shape
		 * @param x The x location of the new shape.
		 * @param y the y location of the new shape.
		 * @param rotation the rotation of the new shape.
		 * @param size the size of the new shape.
		 */
		public void createShape(int x, int y, double rotation, int size)
		{
			Shape shape = new Shape(x,y,rotation,size);
			shapes.add(shape);
		}
		
		/**
		 * @param x location of the mouse
		 * @param y location of the mouse
		 * @return the corner of the rectangle that the mouse is on.
		 */
		public SquareCorner isOnRotatePoint(int x, int y) {
			for (Shape n : shapes)
			{
				int xUnrotated = getXUnrotated(x,y,n);
				int yUnrotated = getYUnrotated(x,y,n);

				//If in left column
				if ((xUnrotated >= n.getX()) && (xUnrotated <= n.getX() + BORDER_WIDTH)) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return SquareCorner.topleft;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return SquareCorner.bottomleft;
					}
				//If in right column
				} else if ((xUnrotated >= n.getX() + n.getSize() - BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize())) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return SquareCorner.topright;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return SquareCorner.bottomright;
					}
				}
			}
			return SquareCorner.none;
		}
		
		/**
		 * Finds the shape that you are rotating.
		 * @param x the x location of the mouse
		 * @param y the y location of the mouse
		 * @return The shape the mouse is rotating.
		 */
		public Shape getRotationShape(int x, int y) {
			for (Shape n : shapes)
			{
				int xUnrotated = getXUnrotated(x,y,n);
				int yUnrotated = getYUnrotated(x,y,n);

				//If in left column
				if ((xUnrotated >= n.getX()) && (xUnrotated <= n.getX() + BORDER_WIDTH)) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return n;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return n;
					}
				//If in right column
				} else if ((xUnrotated >= n.getX() + n.getSize() - BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize())) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return n;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return n;
					}
				}
			}
			return null;
		}
		
		/**
		 * @param x the x location of the mouse.
		 * @param y the y location of the mouse.
		 * @return The side of the rectangle that the mouse is on.
		 */
		public SquareSide isOnResizePoint(int x, int y) {
			for (Shape n : shapes)
			{
				int xUnrotated = getXUnrotated(x,y,n);
				int yUnrotated = getYUnrotated(x,y,n);
				
				//If between two columns
				if ((xUnrotated >= n.getX() + BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize() - BORDER_WIDTH)) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return SquareSide.top;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return SquareSide.bottom;
					}
					
				//If in between two rows
				} else if ((yUnrotated >= n.getY() + BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize() - BORDER_WIDTH)) {
					//If in left column
					if ((xUnrotated >= n.getX()) && (xUnrotated <= n.getX() + BORDER_WIDTH)) {
						return SquareSide.left;
						
					//If in right column
					} else if ((xUnrotated >= n.getX() + n.getSize() - BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize())) {
						return SquareSide.right;
					}
				}
			}
			return SquareSide.none;
		}
		
		/**
		 * @param x the x location of the mouse.
		 * @param y the y location of the mouse.
		 * @return The shape that is being resized.
		 */
		public Shape getResizeShape(int x, int y) {
			for (Shape n : shapes)
			{
				int xUnrotated = getXUnrotated(x,y,n);
				int yUnrotated = getYUnrotated(x,y,n);
				
				//If between two columns
				if ((xUnrotated >= n.getX() + BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize() - BORDER_WIDTH)) {
					//If in the top row
					if ((yUnrotated >= n.getY()) && (yUnrotated <= n.getY() + BORDER_WIDTH)) {
						return n;
						
					//If in the bottom row
					} else if ((yUnrotated >= n.getY() + n.getSize() - BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize())) {
						return n;
					}
					
				//If in between two rows
				} else if ((yUnrotated >= n.getY() + BORDER_WIDTH) && (yUnrotated <= n.getY() + n.getSize() - BORDER_WIDTH)) {
					//If in left column
					if ((xUnrotated >= n.getX()) && (xUnrotated <= n.getX() + BORDER_WIDTH)) {
						return n;
						
					//If in right column
					} else if ((xUnrotated >= n.getX() + n.getSize() - BORDER_WIDTH) && (xUnrotated <= n.getX() + n.getSize())) {
						return n;
					}
				}
			}
			return null;
		}
		
		/**
		 * @param x the x location of the mouse.
		 * @param y the y location of the mouse.
		 * @return one of the shapes that the mouse is on.
		 */
		public Shape findShape(int x, int y)
		{
			for (Shape n : shapes)
			{
				int xUnrotated = getXUnrotated(x,y,n);
				int yUnrotated = getYUnrotated(x,y,n);
				if (n.getX() <= xUnrotated && n.getX() + n.getSize() >= xUnrotated && n.getY() <= yUnrotated && n.getY() + n.getSize() >= yUnrotated)
				{
					return n;
				}
			}
			return null;
		}
		
		/**
		 * @param x the x location of the mouse.
		 * @param y the y location of the mouse.
		 * @param n the shape that the mouse position is being compared against.
		 * @return The x location rotated about the middle of the shape.
		 */
		private int getXUnrotated(int x, int y, Shape n)
		{
			//First it is converted into a vector from the rotation origin (middle of the square)
			double xVector = x - (n.getX() + n.getSize() / 2);
			double yVector = y - (n.getY() + n.getSize() / 2);
			
			double xUnrotated = ((xVector * Math.cos(-n.getRotation())) - (yVector * Math.sin(-n.getRotation())));
			
			//Converted back to the origin
			xUnrotated += (n.getX() + n.getSize() / 2);
			return (int) xUnrotated;
		}
		
		/**
		 * @param x the x location of the mouse.
		 * @param y the y location of the mouse.
		 * @param n the shape that the mouse position is being compared against.
		 * @return The y location rotated about the middle of the shape.
		 */
		private int getYUnrotated(int x, int y, Shape n)
		{
			//First it is converted into a vector from the rotation origin (middle of the square)
			double xVector = x - (n.getX() + n.getSize() / 2);
			double yVector = y - (n.getY() + n.getSize() / 2);
			
			double yUnrotated = ((yVector * Math.cos(-n.getRotation()) + (xVector * Math.sin(-n.getRotation()))));
			
			//Converted back to the origin
			yUnrotated += (n.getY() + n.getSize() / 2);
			return (int) yUnrotated;
		}
		
		/**
		 * @param n the shape being moved
		 * @param x the new x location
		 * @param y the new y location
		 */
		public void moveShape(Shape n, int x, int y)
		{
			n.changeLocation(x,y);
			updateDimensions();
		}
		
		public int getWidth() 
		{
			return width;
		}

		public int getHeight() 
		{
			return height;
		}

		public Boolean getRotationMode() {
			return rotationMode;
		}

		public void setRotationMode(Boolean rotationMode) {
			this.rotationMode = rotationMode;
		}

		public Boolean getResizeMode() {
			return resizeMode;
		}

		public void setResizeMode(Boolean resizeMode) {
			this.resizeMode = resizeMode;
		}

		public int getMouseX() {
			return mouseX;
		}

		public void setMouseX(int mouseX) {
			this.mouseX = mouseX;
		}

		public int getMouseY() {
			return mouseY;
		}

		public void setMouseY(int mouseY) {
			this.mouseY = mouseY;
		}

		public boolean isFollowingGuesses() {
			return followingGuesses;
		}

		public void setFollowingGuesses(boolean followingGuesses) {
			this.followingGuesses = followingGuesses;
		}

		public LinkedList<NetworkData> getLastGuessedPath() {
			return lastGuessedPath;
		}

		public void setLastGuessedPath(LinkedList<NetworkData> lastGuessedPath) {
			this.lastGuessedPath = lastGuessedPath;
		}

		public boolean isCatchingUp() {
			return catchingUp;
		}

		public void setCatchingUp(boolean catchingUp) {
			this.catchingUp = catchingUp;
		}
		
}


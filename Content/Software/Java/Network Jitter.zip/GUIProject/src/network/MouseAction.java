package network;
public enum MouseAction {
	click,
	release,
	drag,
	move
}

package network;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Random;

import universal.constants;

import client.CController;



public class Network extends Thread  
{
	//If this is set to true then mouse information is stored in MOVEMENTS_FILENAME.
	private static final boolean OUTPUT_MOVEMENTS_TO_FILE = constants.OUTPUT_MOVEMENTS_TO_FILE;
	private static final String MOVEMENTS_FILENAME = constants.MOVEMENTS_FILENAME;
	
	//If this is set to true then mouse points are stored in PTS_FILENAME.
	private static final boolean OUTPUT_PTS_TO_FILE = constants.OUTPUT_PTS_TO_FILE;
	private static final String PTS_FILENAME = constants.PTS_FILENAME;
	//Keeps track of when the network started.
	private long startTime;
	//The network stops looping if this is set to true.
	private boolean done = false;
	
	private LinkedList<NetworkData> data;
	private CController controller;
	private Random rand;
	
	private boolean mouseStopped = false;
	
	/**
	 * The network constructor
	 * @param controller the client controller.
	 */
	public Network (CController controller) {
		startTime = System.currentTimeMillis();
		data = new LinkedList<NetworkData>();
		this.controller = controller;
		rand = new Random();
		rand.setSeed(Calendar.getInstance().getTimeInMillis());
		this.setDaemon(true);
		this.start();
	}
	
	/**
	 * Main network loop.
	 */
	public void run () {
		NetworkData lastDataSent = null;
		
		while(!done) {
			//Pass packets
			double startTime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startTime < constants.NETWORK_UP_TIME) {
				if (data.isEmpty()) {
					if (lastDataSent != null) {
						controller.receiveData(lastDataSent);
					}
					
					mouseStopped = true;
				}
				
				while (!data.isEmpty()) {	
					
					//Prints out the mouse points to PTS_FILENAME
					if (OUTPUT_PTS_TO_FILE) {
						try {
							FileOutputStream fstream = new FileOutputStream(PTS_FILENAME, true);

							DataOutputStream dstream = new DataOutputStream(fstream);
							BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(dstream));
							
							if (mouseStopped) {
								writer.append("\n");
								mouseStopped = false;
							}
							writer.append("(" + data.getLast().getX() + "," + data.getLast().getY() + ") ");
							
							writer.close();
							dstream.close();
							fstream.close();
							
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					controller.receiveData(data.getLast());
					lastDataSent = data.getLast();	//Store the last data sent in case it has to be resent
					removeLast();
				}	
				
				
				try {
					Thread.sleep(constants.PACKET_PERIOD);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			//Hold packets
			try {
				Thread.sleep(constants.NETWORK_DROP_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void done() {
		done = true;
	}
	
	public synchronized void removeLast() {
		data.removeLast();
	}
	
	//Functions for adding the different mouse actions to the networks list of data to send.
	public synchronized void moveMouse(int x, int y) {
		printToFile(MouseAction.move.toString() + ", "+ x + ", " + y + ", " + String.valueOf(System.currentTimeMillis() - startTime));
		data.addFirst(new NetworkData(MouseAction.move,x,y));
	}
	
	public synchronized void clickMouse(int x, int y) {
		printToFile(MouseAction.click.toString() + ", "+ x + ", " + y + ", " + String.valueOf(System.currentTimeMillis() - startTime));
		data.addFirst(new NetworkData(MouseAction.click,x,y));
	}
	
	public synchronized void releaseMouse(int x, int y) {
		printToFile(MouseAction.release.toString() + ", "+ x + ", " + y + ", " + String.valueOf(System.currentTimeMillis() - startTime));
		data.addFirst(new NetworkData(MouseAction.release,x,y));
	}
	
	public synchronized void dragMouse(int x, int y) {
		printToFile(MouseAction.drag.toString() + ", "+ x + ", " + y + ", " + String.valueOf(System.currentTimeMillis() - startTime));
		data.addFirst(new NetworkData(MouseAction.drag,x,y));
	}
	
	/**
	 * Prints a mouse action to MOVEMENTS_FILENAME.
	 * @param line the mouse action string.
	 */
	private void printToFile(String line) {
		if (OUTPUT_MOVEMENTS_TO_FILE) {
			try {
				FileOutputStream fstream = new FileOutputStream(MOVEMENTS_FILENAME, true);

				DataOutputStream dstream = new DataOutputStream(fstream);
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(dstream));
				
				writer.append(line + "\n");
				
				writer.close();
				dstream.close();
				fstream.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
		
}

package network;

import java.awt.Point;


/**
 * Stores a point and a mouse action.
 */
public class NetworkData extends Point {
	private static final long serialVersionUID = 1L;
	public MouseAction action;
	private int x;
	private int y;
	
	public NetworkData(MouseAction action, double d, double e) {
		this.action = action;
		this.setX((int)d);
		this.setY((int)e);
	}
	
	public NetworkData(MouseAction action, int d, int e) {
		this.action = action;
		this.setX(d);
		this.setY(e);
	}

	public double getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString(){
		String s;
		s = "x:" + this.getX() + " y:" + this.getY();
		return s;
	}
}

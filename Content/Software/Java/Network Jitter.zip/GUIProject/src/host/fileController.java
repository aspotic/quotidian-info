package host;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import universal.Shape;
import universal.SquareCorner;
import universal.SquareSide;
import universal.constants;

import network.MouseAction;
import network.Network;

/**
 * File Controller gets information from disk.
 */
public class fileController 
{
	private static final boolean PRINT = constants.PRINT;
	private Network network;
	private Model model;
	private View view;
	private SquareSide currentResizeSide = SquareSide.none;
	
	//Used so that the shape gets moved from where you grab it instead of from the top left.
	private int xOffset = 0;
	private int yOffset = 0;
	
	//Used when moving a shape.
	private Shape currentMovingShape;
	
	

	/**
	 * Constructor for the file controller.
	 * Reads in data from disk.
	 * @param m the model
	 * @param v the view
	 * @param n the network
	 */
	public fileController(Model m, View v,Network n)
	{
		network = n;
		model = m;
		view = v;
		long startTime = System.currentTimeMillis();
		
		//Read in data
		try {
			FileInputStream fstream = new FileInputStream(constants.MOUSE_DATA_FILENAME);
			DataInputStream dstream = new DataInputStream(fstream);
			BufferedReader reader = new BufferedReader(new InputStreamReader(dstream));
			String line;
			
				while ((line = reader.readLine()) != null){
					//Split the line into the mouse action, mouse x position, and mouse y position
					String stringPoints[] = line.split("[,][ ]");
					MouseAction ma = MouseAction.valueOf(stringPoints[0]);
					int x = Integer.parseInt(stringPoints[1]);
					int y = Integer.parseInt(stringPoints[2]);
					long time = Long.parseLong(stringPoints[3]) + startTime;
					
					//Wait until the action actually happens before doing it
					long sleepTime = time - System.currentTimeMillis();
					if (sleepTime > 0) {
						try {
							Thread.sleep(sleepTime);
						} catch(Exception e) {
							e.printStackTrace();
						}
					}
					
					//Do the appropriate mouse action
					if (MouseAction.click == ma) {
						this.mousePressed(x, y);
					} else if (MouseAction.drag == ma) {
						this.mouseDragged(x, y);
					} else if (MouseAction.move == ma) {
						this.mouseMoved(x, y);
					} else if (MouseAction.release == ma) {
						this.mouseReleased(x, y);
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//Tells the network to stop.
		network.done();
		
	}
	
	
	

	/**
	 * Mouse move event
	 * @param x mouse x location
	 * @param y mouse y location
	 */
	public void mouseMoved(int x, int y) {
		if (model.isOnRotatePoint(x, y) != SquareCorner.none)
		{
				model.setRotationMode(true);
				model.setResizeMode(false);
		}
		else if (model.isOnResizePoint(x, y) != SquareSide.none)
		{
				model.setResizeMode(true);
				model.setRotationMode(false);
		}
		else
		{
			model.setResizeMode(false);
			model.setRotationMode(false);
		}
		
		network.moveMouse(x, y);
		view.updateView(model);
	}
	
	/**
	 * Mouse pressed event
	 * @param x mouse x location
	 * @param y mouse y location
	 */
	public void mousePressed(int x, int y)
	{
		network.clickMouse(x, y);
		
		Shape n = null;
		if (model.getRotationMode()) {
			n = model.getRotationShape(x, y);
		}
		else if (model.getResizeMode()) {
			n = model.getResizeShape(x, y);
			currentResizeSide = model.isOnResizePoint(x, y);
		}
		else {
			n = model.findShape(x, y);
		}
		if (n != null)
		{
			currentMovingShape = n;
			if (model.getRotationMode() || model.getResizeMode())
			{
				xOffset = x;
				yOffset = y;
			}
			else
			{
				xOffset = x - n.getX();
				yOffset = y - n.getY();
			}
		}
		view.updateView(model);
	}
	
	/**
	 * Mouse dragged event.
	 * @param x mouse x location
	 * @param y mouse y location
	 */
	public void mouseDragged(int x, int y)
	{
		if (PRINT) {
		System.out.print("(" + x + "," + y + ") ");
		}
		network.dragMouse(x, y);
		
		if (currentMovingShape != null) //If we have a shape stored for moving then move it.
		{
			if (model.getResizeMode())
			{
				int size = 0;
				int sizeChange = 0;
				if (currentResizeSide.equals(SquareSide.top)) {
					sizeChange = currentMovingShape.getY() - y;
					size = sizeChange + currentMovingShape.getSize();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					} else {
						model.moveShape(currentMovingShape, currentMovingShape.getX()-sizeChange, currentMovingShape.getY()-sizeChange);
					}
					currentMovingShape.setSize(size);
					
					} else if (currentResizeSide.equals(SquareSide.bottom)) {
					size = y - currentMovingShape.getY();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					}
					currentMovingShape.setSize(size);
					
				} else if (currentResizeSide.equals(SquareSide.left)) {
					sizeChange = currentMovingShape.getX() - x;
					size = sizeChange + currentMovingShape.getSize();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					} else {
						model.moveShape(currentMovingShape, currentMovingShape.getX()-sizeChange, currentMovingShape.getY()-sizeChange);
					}
					currentMovingShape.setSize(size);
					
				} else {
					size = x - currentMovingShape.getX();
					if (size < (3*Model.BORDER_WIDTH)){
						size = 3*Model.BORDER_WIDTH;
					}
					currentMovingShape.setSize(size);
				}
			} 
			else if (model.getRotationMode())
			{
				

				//Center of square
				double p1x = currentMovingShape.getX() + currentMovingShape.getSize()/2;
				double p1y = currentMovingShape.getY() + currentMovingShape.getSize()/2;
				
				//cursor's new drag position
				double p2x = x - p1x;
				double p2y = y - p1y;
				
				//Cursor's old drag position
				double p3x = xOffset - p1x;
				double p3y = yOffset - p1y;
				
				//magnitude of vectors
				double p2Mag = Math.sqrt(p2x*p2x+p2y*p2y);
				double p3Mag = Math.sqrt(p3x*p3x+p3y*p3y);
				
				//Dot product rule for selection the rotation angle
				double changeInRotation = Math.acos((p2x*p3x+p2y*p3y)/(p2Mag*p3Mag));	
				
				//Cross Product
				double crossProduct = p3x*p2y-p2x*p3y;
				
				//trig comparison for finding angle directionality
				changeInRotation = changeInRotation*(crossProduct/Math.abs(crossProduct));

				if (Double.isNaN(changeInRotation)) {
					changeInRotation = 0;
				}
				
				double newRotation = changeInRotation + currentMovingShape.getRotation();
				currentMovingShape.setRotation(newRotation);
				xOffset = x;
				yOffset = y;
			
			}
			else
			{
				//The new x location of the shape, can't be less then 0.
				int moveX = x - xOffset;
				if (moveX < 0)
				{
					moveX = 0;
				}
			
				//The new y location of the shape, can't be less then 0.
				int moveY = y - yOffset;
				if (y-yOffset< 0)
				{
					moveY = 0;
				}
				model.moveShape(currentMovingShape,moveX, moveY);
			}
			view.updateView(model);
		}
	}
	
	/**
	 * Mouse released event
	 * @param x mouse x location
	 * @param y mouse y location
	 */
	public void mouseReleased(int x, int y)
	{
		if (PRINT) {
		System.out.println("");
		}
		network.releaseMouse(x, y);
		
		currentMovingShape = null; //If the mouse is no longer being dragged then don't store a shape for moving.
	}



}


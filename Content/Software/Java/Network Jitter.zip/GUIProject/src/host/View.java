package host;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Scrollable;

import universal.Shape;
import universal.constants;



@SuppressWarnings("serial")
public class View extends JFrame
{
	private static final int WINDOW_WIDTH = constants.WINDOW_WIDTH;
	private static final int WINDOW_HEIGHT = constants.WINDOW_HEIGHT;
	JFrame frame;
	private Workspace workspace;
	public View(Model m, boolean isHidden)
	{
		createAndDisplayGUI(m, isHidden);
	}
	//Makes the GUI and displays it.
		private void createAndDisplayGUI(Model m, boolean isHidden)
		{
			//Creates the window.
			frame = new JFrame("Jitter Project. HOST");
			frame.setVisible(false); //Makes the window invisible.
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			//creates the content pane and adds it to the frame.
			JPanel mainPane = new JPanel();
			frame.setContentPane(mainPane);
			
			//Creates the workspace and sets its dimensions.
			workspace = new Workspace(m);
			workspace.setBackground(Color.WHITE);
			//Creates the scroll pane.
			JScrollPane scrollPane = new JScrollPane(workspace);
			workspace.setSize(m.getWidth(),m.getHeight());
			workspace.setPreferredSize(new Dimension(m.getWidth(),m.getHeight()));
			workspace.setMinimumSize(new Dimension(m.getWidth(),m.getHeight()));
			
			mainPane.add(scrollPane,BorderLayout.CENTER);

			
			frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //sets the size of the window.
			if (isHidden) {
				frame.setVisible(false); //Makes the window invisible.
			} else {
				frame.setVisible(true); //Makes the window visible.
			}
		}
		
		//Update view updates the view based on the model.
		//Since the workspace knows about the model it just needs to be repainted.
		//Focus is given to the workspace so that the keylistener actually gets called,
		//Any time it is being updated it should have focus anyways.
		public void updateView(Model m)
		{
			workspace.requestFocusInWindow();
			workspace.setSize(m.getWidth(),m.getHeight());
			workspace.setPreferredSize(new Dimension(m.getWidth(),m.getHeight()));
			workspace.setMinimumSize(new Dimension(m.getWidth(),m.getHeight()));
			workspace.repaint();
		}
		
		//Adds the workspace's listeners.
		public void addWorkspaceListeners(MouseMotionListener listener1, MouseListener listener2)
		{
			workspace.addMouseMotionListener(listener1);
			workspace.addMouseListener(listener2);
		}
		
		public class Workspace extends JLabel implements Scrollable 
		{
			//Needs to know about the model to get the shape information.
			private Model model;
			
			public Workspace(Model model)
			{
				this.model = model;
			}
			
			//Needs to receive focus for its key listener
			@Override
			public boolean isFocusable()
			{
				return true;
			}
			
			//This is where the shapes and links are drawn.
			public void paintComponent(Graphics g) 
			{
				setBackground(Color.WHITE);
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, model.getWidth(), model.getHeight());
				Graphics2D g2D = (Graphics2D) g;
				drawshapes(g2D);
			}
			
			/**
			 * Draws all the squares.
			 */
			private void drawshapes(Graphics2D g)
			{
				List<Shape> shapes = model.getShapes();
				for (Shape n : shapes )
				{
					double xMiddleSquare = n.getX() + n.getSize()/2;
					double yMiddleSquare = n.getY() + n.getSize()/2;
					//Middle of the rectangle for rotating.
					g.rotate(n.getRotation(),xMiddleSquare,yMiddleSquare);
					g.translate(n.getX(), n.getY());
					if (model.getResizeMode()) {
						g.setColor(Color.BLACK);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						
						g.setColor(Color.LIGHT_GRAY);
						g.fillRect(0, 0, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(0, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, 0, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						
						g.setColor(Color.BLUE);
						g.fillRect(Model.BORDER_WIDTH, Model.BORDER_WIDTH, n.getSize()-(2*Model.BORDER_WIDTH), n.getSize()-(2*Model.BORDER_WIDTH)); //Fills in the rectangle.
						
						
						
					} else if (model.getRotationMode()) {
						g.setColor(Color.LIGHT_GRAY);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						
						g.setColor(Color.BLACK);
						g.fillRect(0, 0, constants.BORDER_WIDTH, constants.BORDER_WIDTH);
						g.fillRect(0, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, 0, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						
						g.setColor(Color.BLUE);
						g.fillRect(Model.BORDER_WIDTH, Model.BORDER_WIDTH, n.getSize()-(2*Model.BORDER_WIDTH), n.getSize()-(2*Model.BORDER_WIDTH)); //Fills in the rectangle.
					} else {
						g.setColor(Color.LIGHT_GRAY);
						g.fillRect(0, 0, n.getSize(), n.getSize());
						
						g.setColor(Color.LIGHT_GRAY);
						g.fillRect(0, 0, constants.BORDER_WIDTH, constants.BORDER_WIDTH);
						g.fillRect(0, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, 0, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						g.fillRect(n.getSize() - Model.BORDER_WIDTH, n.getSize() - Model.BORDER_WIDTH, Model.BORDER_WIDTH, Model.BORDER_WIDTH);
						
						g.setColor(Color.BLUE);
						g.fillRect(Model.BORDER_WIDTH, Model.BORDER_WIDTH, n.getSize()-(2*Model.BORDER_WIDTH), n.getSize()-(2*Model.BORDER_WIDTH)); //Fills in the rectangle.
					}
					
					g.translate(-n.getX(), -n.getY()); //Back to the origin.
					g.rotate(-n.getRotation(),xMiddleSquare,yMiddleSquare);
				}
			}
			
			//Used for scrolling.
			@Override
			public Dimension getPreferredScrollableViewportSize() 
			{
				return new Dimension(model.getWidth(),model.getHeight());
			}
			@Override
			public int getScrollableBlockIncrement(Rectangle arg0, int arg1, int arg2) 
			{
				return 1;
			}
			@Override
			public boolean getScrollableTracksViewportHeight() {
				return false;
			}
			@Override
			public boolean getScrollableTracksViewportWidth() {
				return false;
			}
			@Override
			public int getScrollableUnitIncrement(Rectangle arg0, int arg1, int arg2) {
				return 1;
			}
		}
}

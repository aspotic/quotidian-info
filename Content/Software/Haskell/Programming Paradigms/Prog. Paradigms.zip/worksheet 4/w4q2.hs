-- file: w4q2.hs
-- 2010.t2.CMPT.340.WS04.Q1

data Peano = Zero | S Peano
  deriving (Show)

-- part 1
add :: Peano -> Peano -> Peano

add Zero x = x
add (S x) y = S (add x y)


-- part 2
multiply :: Peano -> Peano -> Peano

multiply Zero _ = Zero
multiply (S x) y = add y (multiply x y)


-- part 3
equals :: Peano -> Peano -> Peano

equals Zero Zero = True
equals (S x) (S y) = equals x y
equals _ _ = False


-- part 4
sub :: Peano -> Peano -> Peano

sub x Zero = x
sub (S x) (S y) = sub x y
sub _ _ = error "obscure error message about negative Peano numbers"


-- part 5
instance Eq Peano where 
  (==) = equals

-- eof

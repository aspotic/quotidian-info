-- file: w4q1.hs
-- 2010.t2.CMPT.340.WS04.Q1

-- part 1
sum1 :: Integer -> Integer -> Integer
sum1 lo hi = if (lo == hi) then hi else lo + (sum1 (lo + 1) hi)


-- part 2
sum2 :: Integer -> Integer -> Integer
sum2 x y
  | x == y = y
  | otherwise = x + (sum2 (x+1) y)


-- part 3
sum3 :: Integer -> Integer -> Integer
sum3 x y = sum3h x y y
  where sum3h x y s
          | x == y = s
          | otherwise = sum3h (x+1) y (s + x)


-- part 4
sum4 :: Integer -> Integer -> Integer
sum4 x y = sum4h (y-x) x
  where sum4h 0 s = s
        sum4h n s = sum4h (n-1) (s+x+n)
 

-- eof

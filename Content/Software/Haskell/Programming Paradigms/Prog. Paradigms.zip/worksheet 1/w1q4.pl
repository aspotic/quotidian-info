% File: qsort.pl
% Michael C. Horsch
%
% Synopsis:
%   A simple implementation of quick sort.
% 
% Main predicate:
%   qsort(+List,-Sorted)



% partition(+L,+P,-S,-E,-G)
% partitions the list L into 3 lists
% S: The elements of L that are less than P
% E: The elements of L that are equal to P
% G: The elements of L that are greater than P
% P: the value used to partion L

partition([],_,[],[],[]).
partition([X|Xs],P,[X|S],E,G) :-
  X < P,
  partition(Xs,P,S,E,G).
partition([X|Xs],P,S,[X|E],G) :-
  X = P,
  partition(Xs,P,S,E,G).
partition([X|Xs],P,S,E,[X|G]) :-
  X > P,
  partition(Xs,P,S,E,G).

% mergeSorted(+S,+E,+G,-Merged)
% merge the sorted lists S,E,G
% S: elements less than E
% G: elements greater than E
% E: a list of values, all the same

mergeSorted(S,E,G,Merged) :-
  append(E,G,Tail),
  append(S,Tail,Merged).

% select(+List,-Value)
% grab the first Value in the List
% The list has to be at least 2 elements long.
select([X,_|_],X).



% qsort(+List,-Sorted)
% Rearrange the List so that it is Sorted
% (from small to large)

qsort([],[]).
qsort([X],[X]).
qsort(I,O) :-
  select(I,P),
  partition(I,P,S,E,G),
  qsort(S,SS),
  qsort(G,SG),
  mergeSorted(SS,E,SG,O).

% eof

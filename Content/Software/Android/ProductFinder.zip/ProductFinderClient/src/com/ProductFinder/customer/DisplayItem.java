package com.ProductFinder.customer;

import com.ProductFinder.dataStructure.ClientItem;
import com.ProductFinder.R;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;


/**
 * Performs a search of the product database
 * @author adam knox
 */
public class DisplayItem extends Activity {
	private ClientItem item;
	private TextView department;
	private TextView brand;
	private TextView description;
	private TextView isle;
	private TextView price;
	private TextView name;
	private TextView serial;
	private TextView shelf;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_search_showitem);
        
        //Get screen objects
    	name = (TextView) findViewById(R.id.seeItemName);
    	description = (TextView) findViewById(R.id.seeItemDescription);
    	department = (TextView) findViewById(R.id.seeItemDepartment);
    	brand = (TextView) findViewById(R.id.seeItemBrand);
    	price = (TextView) findViewById(R.id.seeItemPrice);
    	serial = (TextView) findViewById(R.id.seeItemSerial);
    	isle = (TextView) findViewById(R.id.seeItemIsle);
    	shelf = (TextView) findViewById(R.id.seeItemShelf);
        
    	//Get passed item object
    	item = (ClientItem) getIntent().getExtras().get("item");
    	
    	//Set text views to contain the item data
    	name.setText(item.name);
    	description.setText(item.description);
    	department.setText(item.department);
    	brand.setText(item.brand);
    	price.setText(String.valueOf(item.price));
    	serial.setText(String.valueOf(item.serial));
    	isle.setText(String.valueOf(item.isle));
    	shelf.setText(String.valueOf(item.shelf));
    }
}
package com.example.easypassword;


/**
 * An algorithm that takes user's selected pics and android id to generate
 * a password, given user's specifications
 * 
 * @author gsd581
 *
 */
public class HashAlgorithm 
{
	/**
	 * Contains array of picture names selected by user (in sequential order)
	 */
	private String[] picNames;
	
	/**
	 * Unique android ID in hex
	 */
	private String androidID;
	
	/**
	 * Min password length
	 */
	private int minPassLength;
	
	/**
	 * Max password length
	 */
	private int maxPassLength;
	
	/**
	 * Number of characters that are lowercase alpha
	 */
	private int numLowerAlpha;
	
	/**
	 * Number of characters that are uppercase alpha
	 */
	private int numUpperAlpha;
	
	/**
	 * Number of characters that are numbers
	 */
	private int numNumbers;
	
	/**
	 * Number of characterst that are symbols
	 */
	private int numSymbols;
	
	/**
	 * Variables that decide which characters in character set are allowed in password
	 * (true = include, false = don't include)
	 */
	private boolean includeLower; //lowercase letters
	private boolean includeUpper; //uppercase letters
	private boolean includeNum; //numbers
	private boolean includeSym; //symbols and punctuations
	
	/**
	 * Required length of pin number used to create pass (pin number created from androidID
	 */
	public static final int  PIN_NUM_LENGTH = 10; // must be greater than 6 (see getHashPass())
	
	/**
	 * Algorithm's min suggested password length
	 */
	public static final int MIN_PASS_LENGTH = 8;
	
	/**
	 * Algorithm's max suggested password length
	 */
	public static final int MAX_PASS_LENGTH = 12;
	
	/**
	 * Constructor with user specifying allowed characters and min/max pass length
	 * @param picNames String that stores names of user selected pics
	 * @param androidID String that stores Android device's unique ID
	 * @param minPassLength Integer that stores min required pass length
	 * @param maxPassLength Integer that stores max required pass length
	 * @param includeLower Boolean that determines if lowercase letters are included in pass
	 * @param includeUpper Boolean that determines if uppercase letters are included in pass
	 * @param includeNum Boolean that determines if numbers are included in pass
	 * @param includeSym Boolean that determines if symbols and punctuations are included in pass
	 */
	public HashAlgorithm(String[] picNames, String androidID, int minPassLength, int maxPassLength,
			boolean includeLower, boolean includeUpper, boolean includeNum, boolean includeSym)
	{
		//initialize values
		this.picNames = picNames;
		this.androidID = androidID;
		this.minPassLength = minPassLength;
		this.maxPassLength = maxPassLength;
		this.includeLower = includeLower;
		this.includeUpper = includeUpper;
		this.includeNum = includeNum;
		this.includeSym = includeSym;		
		
		this.numLowerAlpha = 0;
		this.numUpperAlpha = 0;
		this.numNumbers = 0;
		this.numSymbols = 0;
		
		validateConstructorValues();
		
		// Remove extensions in picNames
		removePicNameExtensions();
	}
	
	/**
	 * Constructor with user specifying allowed character, but not min/max pass length
	 * @param picNames String that stores names of user selected pics
	 * @param androidID String that stores Android device's unique ID
	 * @param includeLower Boolean that determines if lowercase letters are included in pass
	 * @param includeUpper Boolean that determines if uppercase letters are included in pass
	 * @param includeNum Boolean that determines if numbers are included in pass
	 * @param includeSym Boolean that determines if symbols and punctuations are included in pass
	 */
	public HashAlgorithm(String[] picNames, String androidID, boolean includeLower, 
			boolean includeUpper, boolean includeNum, boolean includeSym)
	{
		//initialize values
		this.picNames = picNames;
		this.androidID = androidID;
		this.minPassLength = MIN_PASS_LENGTH;
		this.maxPassLength = MAX_PASS_LENGTH;
		this.includeLower = includeLower;
		this.includeUpper = includeUpper;
		this.includeNum = includeNum;
		this.includeSym = includeSym;		
		
		validateConstructorValues();
		
		// Remove extensions in picNames
		removePicNameExtensions();	}
	
	/**
	 * Constructor with user specifying min/max pass length, but not allowed characters
	 * @param picNames String that stores names of user selected pics
	 * @param androidID String that stores Android device's unique ID
	 * @param minPassLength Integer that stores min required pass length
	 * @param maxPassLength Integer that stores max required pass length
	 */
	public HashAlgorithm(String[] picNames, String androidID, int minPassLength, int maxPassLength)
	{
		//initialize values
		this.picNames = picNames;
		this.androidID = androidID;
		this.minPassLength = minPassLength;
		this.maxPassLength = maxPassLength;
		this.includeLower = true;
		this.includeUpper = true;
		this.includeNum = true;
		this.includeSym = true;		
		
		validateConstructorValues();
		
		// Remove extensions in picNames
		removePicNameExtensions();
	}
	
	/**
	 * Constructor with user not specifying min/pass length nor allowed characters
	 * @param picNames String that stores names of user selected pics
	 * @param androidID String that stores Android device's unique ID
	 */
	public HashAlgorithm(String[] picNames, String androidID)
	{
		//initialize values
		this.picNames = picNames;
		this.androidID = androidID;
		this.minPassLength = MIN_PASS_LENGTH;
		this.maxPassLength = MAX_PASS_LENGTH;
		this.includeLower = true;
		this.includeUpper = true;
		this.includeNum = true;
		this.includeSym = true;		
		
		validateConstructorValues();
		
		// Remove extensions in picNames
		removePicNameExtensions();
	}
	
	/**
	 * Validates constructor values
	 */
	private void validateConstructorValues()
	{
		//validate picNames
		if (this.picNames.length == 0)
		{
			throw new RuntimeException("Pic names array is empty");
		}
		for (String name: this.picNames)
		{
			if (name.trim().isEmpty())
			{
				throw new RuntimeException("Pic names cannot be empty");
			}
		}
		
		//validate androidID
		if (this.androidID.trim().isEmpty())
		{
			throw new RuntimeException("Android ID is empty");
		}
		if (this.androidID.matches("^[0]*$"))
		{
			throw new RuntimeException("Android ID cannot consist only of zeros");
		}
		
		//validate min/max length
		if (this.minPassLength <= 0 || this.maxPassLength <= 0)
		{
			throw new RuntimeException("Min and max pass length must be greater than zero");
		}
		if (this.minPassLength > this.maxPassLength)
		{
			throw new RuntimeException("Min pass length must be less than or equal to max pass length");
		}
		
		//pass should have at least one character from each pic names
		//therefore, min pass length must be at least same number of pic names
		if (minPassLength < picNames.length)
		{
			throw new RuntimeException("Min pass length must be at least same number as number of pic names");
		}
		
		//valide include booleans
		//at least one should be true
		if (!this.includeLower && !this.includeUpper && !this.includeNum && !this.includeSym)
		{
			throw new RuntimeException("Password must include at least one of the following groups:" +
					"Lowercase characters, uppercase characters, numbers, or symbols");
		}
	}
	
	/**
	 * Remove extensions from pic names
	 */
	private void removePicNameExtensions()
	{
		for (int i = 0; i < picNames.length; i++)
		{
			//Remove extension (.jpg, .png, etc.)
			boolean isRemoved = false;
			int extStart = picNames[i].length() - 1;
			while (!isRemoved && (extStart > 0))
			{
				if (picNames[i].charAt(extStart) == '.')
				{
					picNames[i] = picNames[i].substring(0, extStart);
					
					isRemoved = true;
				}
				
				extStart--;
			}
		}
	}
	
	/**
	 * Creates and returns string of alphabet in sequential order
	 * @return String of alphabet in sequential order
	 */
	private String getAlphaString()
	{
		String alphaString = "abcdefghijklmnopqrstuvwxyz";
		
		return alphaString;		
	}
	
	/**
	 * Creates and returns string of symbols and punctuation in sequential order 
	 * @return String of symbols and punctuation in sequential order
	 */
	private String getSymString()
	{
		String symString = "~!@#%&_=}{:;<,>/~!@#%&_=<>";
		
		return symString;
	}
	
	/**
	 * Convert android hex ID to pin number of length PIN_NUM_LENGTH
	 * @return pin number
	 */
	private long getPinNumber()
	{
		long pinNum;
		
		//Remove trailing zeros
		while (androidID.charAt(androidID.length() - 1) == '0')
		{
			androidID = androidID.substring(0, androidID.length() - 1);
		}
		
		//Get last seven hex characters
		
		if (androidID.length() < 7)
		{
			//ID length is less than 7, add to ID until length >= 7
			while (androidID.length() <= 7)
			{
				androidID = androidID + androidID;
			}
		}
		
		androidID = androidID.substring(androidID.length() - 7);
		
		//Convert hex to decimal
		pinNum = Long.parseLong(androidID, 16);
		
		//Ensure pin has pinNumLength
		
		String pinNumStr = "" + pinNum;
		
		pinNumStr = pinNumStr.replace("0", ""); //Remove all zeros to avoid bad cases
		
		while (pinNumStr.length() < PIN_NUM_LENGTH)
		{
			pinNumStr = pinNumStr + pinNumStr;
		}
		
		pinNumStr = pinNumStr.substring(pinNumStr.length() - PIN_NUM_LENGTH);
		
		//Convert string back to long int
		pinNum = Long.parseLong(pinNumStr);
		
		return pinNum;
	}	
	
	/**
	 * Combines pic names, keeping length between min and max pass length
	 * All non-alpha characters are either removed or replaced by an alpha character
	 * @return String that stores combined pic names with length between min and max 
	 * 		   pass length (non-alpha chars are either replaced or removed)	 
	 */
	private String getCombinedPicNames()
	{
		String combinedPicNames = "";
		int totalLengthOfCombinedNames = 0;
		
		// Find expected total length of combined names
		for (String name: this.picNames)
		{		
			// Add to total combined name length
			totalLengthOfCombinedNames += name.length();
		}
		
		// If total < required min length for pass, add to each pic name 
		// until total reaches min
		int i = 0;
		int indexOfCharToAdd = 0;
		while (totalLengthOfCombinedNames < MIN_PASS_LENGTH)
		{
			if (i >= this.picNames.length)
			{
				// i out of bounds (previous loop hit last array element, reset
				i = 0;				
			}
			
			if (indexOfCharToAdd >= this.picNames[i].length())
			{
				// indexOfCharToAdd is out of bounds, reset
				indexOfCharToAdd = 0;
			}
				
			this.picNames[i] += this.picNames[i].charAt(indexOfCharToAdd);
			totalLengthOfCombinedNames++;
			
			indexOfCharToAdd++;
			i++;
		}
		
		// If total > required max length for pass, remove from each pic name
		// until total reaches max
		i = 0;
		while (totalLengthOfCombinedNames > MAX_PASS_LENGTH)
		{
			if (i >= this.picNames.length)
			{
				// i out of bounds (previous loop hit last array element, reset
				i = 0;				
			}
			
			// Only remove from pic name if name's length > 1
			if (this.picNames[i].length() > 1)
			{
				// Remove first letter of name
				this.picNames[i] = this.picNames[i].substring(1);
				totalLengthOfCombinedNames--;
			}
			
			i++;
		}
		
		// Now combine names
		for (String name: this.picNames)
		{
			combinedPicNames += name;
		}
		
		return combinedPicNames;
	}
	
	/**
	 * Converts all characters in string to lowercase alpha character
	 * @param strToConvert String to be converted to lowercase alpha characters
	 * @return String of lowercase alpha characters
	 */
	private String convertToLowerAlpha(String strToConvert)
	{
		String convertedString = strToConvert;
		
		//Convert all uppercase letters to lowercase
		convertedString = convertedString.toLowerCase();
		
		//Remove all whitespace
		convertedString = convertedString.replaceAll("\\s", "");
		
		//Remove all non-alpha characters (or replace with alpha equivalent)
		char character;
		for (int i = 0; i < convertedString.length(); i++)
		{
			character = convertedString.charAt(i);
			
			// If character not alpha, remove or replace
			if (!Character.isLetter(character))
			{
				if (("" + character).matches("^[0-9]*$"))
				{
					//Character is a number, replace with alpha equivalent
					convertedString = convertedString.substring(0, i) 
										+ this.getAlphaString().charAt(Integer.parseInt("" + character))
										+ convertedString.substring(i + 1); 
				}
				else if (this.getSymString().indexOf("" + character) >= 0)
				{
					//Character in symString, replace with alpha equivalent
					convertedString = convertedString.substring(0, i)
										+ this.getAlphaString().charAt(this.getSymString().indexOf("" + character))
										+ convertedString.substring(i + 1);
				}
				else
				{
					//Character not number or in symString, remove
					convertedString = convertedString.substring(0, i)
										+ convertedString.substring(i + 1);
					
					//Decrement i to make up for character removed (or else next loop skips the character
					//after the removed character
					i--;
				}
			}		
		}
		
		return convertedString;		
	}
	
	/**
	 * Adds uppercase letters to string
	 * @param str String to have uppercase letters added to
	 * @param startIndex Integer where conversion should start
	 * @param skipNum Integer that stores number of letters to skip before next conversion
	 * @param totalNum Integer that stores total number of letter conversion
	 * @return String with uppercase letters added
	 */
	private String addUpperAlpha(String strToConvert, int startIndex, int skipNum, int totalNum)
	{
		int nextIndex = startIndex; // index of next character to convert
		
		// Add uppercase letters to string
		// If nuLowerAlpha reaches one, stop
		int count = 0;
		while ((count < totalNum) && (this.numLowerAlpha > 1))
		{
			// If nextIndex is out of bound, bring it in bounds
			while (nextIndex >= strToConvert.length())
			{
				nextIndex -= strToConvert.length();
			}
			
			// Convert letter at nextIndex to uppercase (if character is lower alpha)
			// Keep track of lower and upper alpha counts
			if (Character.isLowerCase(strToConvert.charAt(nextIndex)))
			{
				strToConvert = strToConvert.substring(0, nextIndex) 
				+ Character.toUpperCase(strToConvert.charAt(nextIndex))
				+ strToConvert.substring(nextIndex + 1);
				
				this.numLowerAlpha--;
				this.numUpperAlpha++;
			}	

			nextIndex += skipNum;
			count++;
		}
		
		return strToConvert;
	}
	
	/**
	 * Adds numbers to string
	 * @param str String to have numbers added to
	 * @param startIndex Integer where conversion should start
	 * @param skipNum Integer that stores number of letters to skip before next conversion
	 * @param totalNum Integer that stores total number of character conversions
	 * @return String with numbers added
	 */
	private String addNumbers(String strToConvert, int startIndex, int skipNum, int totalNum)
	{
		int nextIndex = startIndex; // index of next character to convert
		
		// Add numbers to string, while avoiding replacing all characters of one type
		int count = 0;
		char characterToConvert;
		int replacement;
		boolean replace = false; //if true, replace, else skip (to avoid replacing all of one type)
		while (count < totalNum)
		{
			// If nextIndex is out of bound, bring it in bounds
			while (nextIndex >= strToConvert.length())
			{
				nextIndex -= strToConvert.length();
			}
			
			// Convert character at nextIndex to number (if character is not already a number)
			// Keep track of lower and upper alpha counts as well as numbers
			// (ensure no set of one type = 0)
			if (!("" + strToConvert.charAt(nextIndex)).matches("[0-9]"))
			{
				if(Character.isLowerCase(strToConvert.charAt(nextIndex)) && (this.numLowerAlpha > 1))
				{
					//replacing lower case alpha with num, adjust count
					this.numLowerAlpha--;
					replace = true;
				}
				else if (Character.isUpperCase(strToConvert.charAt(nextIndex)) && (this.numUpperAlpha > 1))
				{
					//replacing upper case alpha with num, adjust count
					this.numUpperAlpha--;
					replace = true;
				}
				
				if (replace = true)
				{
					// Get character to convert
					characterToConvert = Character.toLowerCase(strToConvert.charAt(nextIndex)); //lowercased to search alphaString
					replacement = this.getAlphaString().indexOf(characterToConvert);
					
					// Ensure replacement is one digit (if not, get last digit)
					if (replacement > 9)
					{
						replacement = replacement % 10;
					}

					// Replace character with replacement
					strToConvert = strToConvert.substring(0, nextIndex) 
					+ replacement
					+ strToConvert.substring(nextIndex + 1);
					
					this.numNumbers++;
				}
				
			}	

			nextIndex += skipNum;
			count++;
		}
		
		return strToConvert;
	}
	
	/**
	 * Adds symbols to string
	 * @param str String to have symbols added to
	 * @param startIndex Integer where conversion should start
	 * @param skipNum Integer that stores number of characters to skip before next conversion
	 * @param totalNum Integer that stores total number of character conversions
	 * @return String with symbols added
	 */
	private String addSymbols(String strToConvert, int startIndex, int skipNum, int totalNum)
	{
		int nextIndex = startIndex; // index of next character to convert
		
		// Add symbols to  string, while avoiding replacing all of one type
		int count = 0;
		char characterToConvert;
		int replacement = 0;
		boolean replace = false; //if true, replace, else skip (to avoid replacing all of one type)
		while (count < totalNum)
		{
			// If nextIndex is out of bound, bring it in bounds
			while (nextIndex >= strToConvert.length())
			{
				nextIndex -= strToConvert.length();
			}
			
			// Convert character at nextIndex to symbol (if character is not already a symbol)
			// Keep track of lower and upper alpha counts as well as numbers and symbols
			// (ensure no set of one type = 0)
			if (!("" + strToConvert.charAt(nextIndex)).matches("[" + this.getSymString() + "]")) //right here
			{
				if (Character.isLetter(strToConvert.charAt(nextIndex)))
				{
					// Character is an lower or upper case letter
					if(Character.isLowerCase(strToConvert.charAt(nextIndex)) && (this.numLowerAlpha > 1))
					{
						//replacing lower case alpha with symbol, adjust count
						this.numLowerAlpha--;
						replace = true;
					}
					else if (Character.isUpperCase(strToConvert.charAt(nextIndex)) && (this.numUpperAlpha > 1))
					{
						//replacing upper case alpha with symbol, adjust count
						this.numUpperAlpha--;
						replace = true;
					}
					
					// Get character to convert
					characterToConvert = Character.toLowerCase(strToConvert.charAt(nextIndex)); //lowercased to search alphaString
					replacement = this.getAlphaString().indexOf(characterToConvert);
				}
				else if (Character.isDigit(strToConvert.charAt(nextIndex)) && (this.numNumbers > 1))
				{
					//replacing number with symbol, adjust count
					this.numNumbers--;
					replace = true;
					
					// Get character to convert
					replacement = Integer.parseInt("" + strToConvert.charAt(nextIndex));
				}
								
				if (replace = true)
				{
					// Ensure replacement is one digit (if not, get last digit)
					if (replacement > 9)
					{
						replacement = replacement % 10;
					}

					// Replace character with replacement
					strToConvert = strToConvert.substring(0, nextIndex) 
					+ this.getSymString().charAt(replacement)
					+ strToConvert.substring(nextIndex + 1);
					
					this.numSymbols++;
				}
				
			}	

			nextIndex += skipNum;
			count++;
		}
		
		return strToConvert;
	}
	
	/**
	 * Swaps characters of string based on pin number
	 * @param strToSwap String that stores string of characters to swap based on pin num
	 * @return Original string input with some characters swapped
	 */
	private String swapChars(String strToSwap)
	{
		String pinStr = "" + this.getPinNumber();
		
		//If pin length is odd, add zero to end
		if (pinStr.length() % 2 != 0)
		{
			pinStr += "0";
		}
		
		int startIndex = 0;
		int nextIndex = 0;
		
		// Go through strToSwap, swapping characters based on pin number
		char tmpChar;
		for (int i = 0; i < pinStr.length(); i += 2)
		{
			startIndex = nextIndex + Integer.parseInt("" + pinStr.charAt(i));
			nextIndex = startIndex + Integer.parseInt("" + pinStr.charAt(i + 1));
			
			// If start index is out of bounds, bring in bounds
			while (startIndex > pinStr.length())
			{
				startIndex -= pinStr.length();
			}
			
			// If next index is out of bounds, bring in bounds
			while (nextIndex > pinStr.length())
			{
				nextIndex -= pinStr.length();
			}
			
			// Swap characters at startIndex and nextIndex

			// Place character at startIndex in tmpChar
			tmpChar = strToSwap.charAt(startIndex);
			
			// Place char at nextIndex in startIndex
			strToSwap = strToSwap.substring(0, startIndex)
						+ strToSwap.charAt(nextIndex)
						+ strToSwap.substring(startIndex + 1);
			
			// Place character at tmpChar in nextIndex
			strToSwap = strToSwap.substring(0, nextIndex)
						+ tmpChar
						+ strToSwap.substring(nextIndex + 1);
		}
		
		return strToSwap;
	}
	
	/**
	 * Creates and returns fully hashed password
	 * @return String that stores fully hashed password
	 */
	String getHashPass()
	{
		String hashPass = "";
		
		// Convert all pic names to lower cased alpha characters
		// (even if includeLower = false, for ease)
		for (int i = 0; i < this.picNames.length; i++)
		{
			picNames[i] = this.convertToLowerAlpha(picNames[i]);
		}
		
		// Combine pic names within min/max pass length requirement
		hashPass = this.getCombinedPicNames();
		
		// Keep track of number of lowercase alpha characters
		this.numLowerAlpha = hashPass.length();
						
		// For adding characters, use pin number to determine start index
		int start1 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(0));
		int start2 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(1));
		int start3 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(2));
		int start4 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(3));
		int start5 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(4));
		int start6 = Integer.parseInt("" + ("" + this.getPinNumber()).charAt(5));
		
		// Total number of uppercase letters (should be half of total pass length)
		int totalNumUpperAlpha = hashPass.length() / 2;
		
		// Total number of numbers and symbols (should be 1/5 of total pass length)
		int totalNumNumbers = hashPass.length() / 5;
		int totalNumSyms = totalNumNumbers;
		
		// Skip nums (take num equivalent of alpha at start index)
		int upperSkipNum;
		int numberSkipNum;
		int symSkipNum;
		
		if (this.includeLower)
		{
			// Lowercase characters allowed; add other character types
			// (use start1 to start3 as start indexes)
			if (this.includeUpper)
			{
				upperSkipNum = this.getAlphaString().indexOf("" + hashPass.charAt(start1));
				
				hashPass = this.addUpperAlpha(hashPass, start1, upperSkipNum, totalNumUpperAlpha);
			}
			if (this.includeNum)
			{
				numberSkipNum = this.getAlphaString().indexOf("" + Character.toLowerCase(hashPass.charAt(start2)));
				
				hashPass = this.addNumbers(hashPass, start2, numberSkipNum, totalNumNumbers);
			}
			if (this.includeSym)
			{
				// Character at start3 is either a number or letter
				if (Character.isDigit(hashPass.charAt(start3)))
				{
					//Character is a digit, set skip num as that digit
					symSkipNum = Integer.parseInt("" + hashPass.charAt(start3));
				}
				else
				{
					//Character is a letter, set skip nums as num equiv of that letter
					symSkipNum = this.getAlphaString().indexOf("" + Character.toLowerCase(hashPass.charAt(start3)));
				}
				
				hashPass = this.addSymbols(hashPass, start3, symSkipNum, totalNumSyms);
			}
		}
		else if (this.includeUpper)
		{
			// Lowercase characters not allowed; convert all characters 
			// to uppercase letters
			// (use start4 to start5 as start indexes)
			
			//TODO: convert to upper alpha
			
			// Add other character types
			if (this.includeNum)
			{
				//TODO: Add numbers
			}
			if (this.includeSym)
			{
				//TODO: Add symbols
			}			
		}
		else if (this.includeNum)
		{
			// Lowercase and uppercase characters not allowed; convert all
			// characters to numbers
			//(use start6 as start index)
			//TODO: convert to numbers
			
			//Add symbols
			if (this.includeSym)
			{
				//TODO: Add symbols
			}	
		}
		else if (this.includeSym)
		{
			// Only symbols are allowed; convert all characters to symbols
			
			//TODO: convert to symbols
		}
		else
		{
			throw new RuntimeException("No character types chosen for password");
		}	
		
		//Use swap function to swap characters based on pin num to get final hashed password
		hashPass = swapChars(hashPass);
		
		return hashPass;
	}	
}

package com.example.easypassword;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.TextView;

public class CombinationScreen extends Activity {
	private static final int SEQUENCE_LENGTH = 5;
	HashMap<Integer, String> pictureNames;	
	private LinkedList<Integer> imageSequence;
	private CharSequence password = "";
	
	
	//Description: Starts the program
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//Store the button names
		pictureNames = new HashMap<Integer, String> ();	
		pictureNames.put(R.id.b1, "ic_menu_categories.png");
		pictureNames.put(R.id.b2, "ic_menu_contrast.png");
		pictureNames.put(R.id.b3, "ic_menu_flash.png");
		pictureNames.put(R.id.b4, "ic_menu_clock.png");
		pictureNames.put(R.id.b5, "ic_menu_chart.png");
		pictureNames.put(R.id.b6, "ic_menu_cards.png");
		pictureNames.put(R.id.b7, "ic_menu_car.png");
		pictureNames.put(R.id.b8, "ic_menu_dice.png");
		pictureNames.put(R.id.b9, "ic_menu_umbrella.png");
		pictureNames.put(R.id.b10, "ic_menu_sun.png");
		pictureNames.put(R.id.b11, "ic_menu_smalltiles.png");
		pictureNames.put(R.id.b12, "ic_menu_sad.png");
		pictureNames.put(R.id.b13, "ic_menu_puzzle.png");
		pictureNames.put(R.id.b14, "ic_menu_tick.png");
		pictureNames.put(R.id.b15, "ic_menu_laptop.png");
		pictureNames.put(R.id.b16, "ic_menu_ruler.png");
		
		//Setup the image button id list
		imageSequence = new LinkedList<Integer> ();
       
		//Display the image sequence screen
			setContentView(R.layout.main);       
	}
   
   
	//Description: Adds the id of the button that called the function to a list, then generates a password after SEQUENCE_LENGTH calls
	public void buttonClicked (View v) {
		//Add the image button id to the list of clicked image buttons
		imageSequence.addLast(v.getId());
	   
		//When there are SEQUENCE_LENGTH images in the list, then run the algorithm and show the password
		if (imageSequence.size() == SEQUENCE_LENGTH) {
			//Run the password generator algorithm
			password = passwordGenerator();

			//Show the password display screen
			setContentView(R.layout.seepassword);
		   
			//Display the password
			TextView passwordField = new TextView(this);
			passwordField = (TextView)findViewById(R.id.password);
			passwordField.setText(password);
		}
	}
   
   
	//Description: Clear the image sequence to restart
	public void restart(View v) {
		//Clear the existing image sequence
		imageSequence = new LinkedList<Integer> ();

		//Show the image selection screen
		setContentView(R.layout.main);
	}


	
	
	//Description: The algorithm used for generating a list of passwords
	//Return: The password generated
	private CharSequence passwordGenerator () {
		//Create a code unique to the phone based on the device ID
		final TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
	    final String tmDevice = tm.getDeviceId();
	    final UUID deviceUuid = new UUID(tmDevice.hashCode(), ((long)tmDevice.hashCode() << 32));
	    final String deviceId = deviceUuid.toString().replace("-","");
		final String[] pics = getPics();
	    
		//Get the password
		HashAlgorithm alg = new HashAlgorithm(pics, deviceId);
	    
		return alg.getHashPass();
	}
	
	
	//Description: Gets a list of all the 
	//Return: String Array of the names of the pictures pressed
	private String[] getPics() {		
		LinkedList<String> returnPics = new LinkedList<String>();
		
		for (int i = 0; i < imageSequence.size(); i++) {
			returnPics.add(pictureNames.get(imageSequence.get(i)));
		}
		
		return returnPics.toArray(new String[returnPics.size()]);
	}
}
%%%%%%%%%%%%%%%%%%%%%%
%Finds the resistance and capacitance that produce a frequency response
%that has the peak frequency response magnitude at the given input frequency
%where the ratio between the DC and peak frequency magnitude responses
%matches the given ratio
%A good input: (200, pi/256, 31000, 3.2, 0.00001, 0.0000005, 0.000005, 1 , 100, 1000)
%%%%%%%%%%%%%%%%%%%%%%
%UILength: the length of the impulse to use in the frequency response. must
%be long enough to account for feedback
%omegaT: omega*T
%reqPeakInput: the input frequency at which the freq. response magnitude peak occurs
%reqPeakDCRatio: the required peak to DC response magnitude ratio (peak mag/DC mag = ratio)
%T: the time step
%Cmin: the minimum possible capacitance
%Cmax: the maximum possible capacitance
%Rmin: the minimum possible resistance
%Rmax: the maximum possible resistance
%numSteps: The granularity of the capacitance and resistance ranges
%%%%%%%%%%%%%%%%%%%%%%
%C: The optimal capacitance for the given input frequency
%R: The optimal resistance for the given peak/DC ratio
%%%%%%%%%%%%%%%%%%%%%%
function [R, C] = findRC(UILength, omegaT, reqPeakInput, reqPeakDCRatio, T, Cmin, Cmax, Rmin, Rmax, numSteps)
     [C, inputFreqPeak] = findC(UILength, omegaT, reqPeakInput, T, Cmin, Cmax, numSteps);
     R = findR(UILength, omegaT, T, Rmin , Rmax, numSteps, C, inputFreqPeak, reqPeakDCRatio);
end
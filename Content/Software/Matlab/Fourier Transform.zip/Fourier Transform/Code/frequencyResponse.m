function result = frequencyResponse(freqResolution, unitImpulseResponse)
    %Determin how many individual frequencies to check
    arrLength = floor(2*pi()/freqResolution);
    
    %form a list for all the individual frequencies being checked
    result = zeros(arrLength,2);
    
    %check each frequency
    for k = 1:arrLength
        %find the current frequency
        result(k,1) = (k-1)*freqResolution - pi(); 
       
        %%%find the response for the current frequency
        %get number of entries
        numK = size(unitImpulseResponse.index, 1);
        %get the discrete response
        result(k,2) = 0;
        for j = 1:numK
            angle = -1*sqrt(-1)*result(k,1)*unitImpulseResponse.index(j);
            result(k,2) = result(k,2) + unitImpulseResponse.data(j)*exp(angle);
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%
%Finds the convolution and feedback sequences for an RLC circuit with
%voltage in and capacitor voltage out
%%%%%%%%%%%%%%%%%%%%%%
%L: Inductance
%C: Capacitance
%R: Resistance
%T: Time Step Size
%%%%%%%%%%%%%%%%%%%%%%
%h: the first and third convolution term. the second term = 2*h
%g1: the first feedback term
%g2: the second feedback term
%%%%%%%%%%%%%%%%%%%%%%
function [h, g1, g2] = getFilterCharacteristics(L, T, R, C)
    den = 4*L*C+2*R*C*T+T*T;
    h = (T*T)/den;
    g1 = (8*L*C-2*T*T)/den;
    g2 = (-4*L*C+2*R*C*T-T*T)/den;
end
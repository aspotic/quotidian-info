function [h1, h2, h3, h4, g1, g2, g3] = getResistorVDrop(L, T, R, C)
    den = 4*L*C+2*R*C*T+T*T;
    
    h1 = (2*R/T)*(C*T*T)/den;
    h2 = h1;
    h3 = -h1;
    h4 = -h1;
    
    g1 = ((8*L*C - 2*T*T)/den)-1;
    g2 = (8*L*C - 2*T*T - 4*L*C + 2*R*C*T - T*T)/den;
    g3 = (-4*L*C + 2*R*C*T - T*T)/den;
end
function y = feedbackconvolve(f, h, g)
    %find the number of entries in the signal and filter arrays
    flength = size(f.index, 1);
    hlength = size(h.index, 1);
    glength = size(g.index, 1);
    
    %set the k range shifted to start at 1 for the matrix indices
    kMinOffset = 1;
    kMaxOffset = flength + (hlength - 1);

    
    %set the y index to the actual index value, not the matrix index
    y.index = ((f.index(1)+h.index(1)):(f.index(end) + h.index(end))).'; 
    
    %initialize y data to all zeroes so it doesnt shift in memory
    y.data = zeros(kMaxOffset, 1);
    
    %rebuild f with zeroes on either end to make multiplication easier
    f.data = padarray(f.data, (hlength - 1));
 
    %rebuild the f indices to account for the added zeros in f.data
    %f.index = ((f.index(1)+h.index(1) - (hlength - 1)):(f.index(end) + h.index(end))).';
    f.index = ((f.index(1)+h.index(1) - (hlength - 1)):(f.index(end) + h.index(end))).';
    
    %run operation for the possibly non zero sequences of results
    for k = kMinOffset:kMaxOffset
        %sum the products to get the y data value
        for m = 1:hlength
            y.data(k) = y.data(k) + h.data(m)*f.data(hlength + (k-m));
        end
        
        %account for feedback. will only exist for previously processed signal
        for m = 1:glength
            if ((k-m) > 0)
                y.data(k) = y.data(k) + g.data(m)*y.data(k-m);
            end
        end
    end
end
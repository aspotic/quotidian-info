function result = FrequencyResponseWFeedback(UIlength, omegaT, h, g)
    %setup an impulse to feed into the feedback convolve system in form
    %0, ..., 0, 1, 0, ..., 0
    centerIndex = floor(UIlength/2) + 1;
    for k = 1:UIlength
        f.index(k, 1) = k - centerIndex;
        f.data(k, 1) = 0;
    end
    f.data(centerIndex, 1) = 1;
    %get the unit impulse response by feeding in a unit umpulse
    UIR = feedbackconvolve(f, h, g);

    %trim leading zeros
    UIR.index(1:(centerIndex-1)) = [];
    UIR.data(1:(centerIndex-1)) = [];
    %get the frequency response
    result = frequencyResponse(omegaT,UIR);
end
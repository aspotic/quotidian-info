function y = convolve(f, h)
    %find the number of entries in the signal and filter arrays
    hlength = h.index(end) - h.index(1) + 1;
    flength = f.index(end) - f.index(1) + 1;

    %set the k range shifted to start at 1 for the matrix indices
    kMinOffset = 1;
    kMaxOffset = flength + hlength - 1;

    %set the y index to the actual index value, not the matrix index
    y.index = (f.index(1)+h.index(1)):(f.index(end) + h.index(end));

    %initialize y data to all zeroes so it doesnt shift in memory
    y.data = zeros(kMaxOffset, 1);

    %rebuild f with zeroes on either end to make multiplication easier
    f.data = padarray(f.data, hlength - 1);

    %setup the f index values
    f.index = (f.index(1)-hlength+1):(f.index(end)+hlength-1);

    %run operation for the (likely) non zero sequences of results
    for k = kMinOffset:kMaxOffset
        %sum the products to ge the y data value
        %(could do dot product, but supposed to use loops)
        for m = 1:hlength
            y.data(k) = y.data(k) + h.data(m)*f.data(hlength+k-m);
        end
    end
end

% This function loads a 2 column text file
% into a returned MATLAB structure, signal.
% This structure is composed of 2 variables:
%    index = column 1 = 1D array of size numrows
%    data  = column 2 = 1D array of size numrows
% The index field represents the sample index
% of the sequence, or signal, k.
% The data field represents the value of the 
% signal f[k] at the corresponding index, k.

% The input parameter can be a string variable
% for the path of the file to load.  Alternately, 
% the function can be called with no parameters
% and the user is presented with a dialog box to 
% choose the file.

function signal = loadsignal( varargin )

% check for no arguments case
if size(varargin) == 0
    % load the dialog box and save the filename
    [filename,pathname] = uigetfile('*.txt','EP 320: choose signal text file');
    filename = [pathname filename];
else
    % user supplied filename
    filename = char(varargin(1));
end

% ASCII load all the data in the file
temp = load( filename );

% if 2 columns exist, this is a valid input file
if size(temp,2) == 2
    % first column is the index field
    signal.index = temp(:,1);
    % second column is the data field
    signal.data = temp(:,2);
else
    % not a proper input file
    signal.index = [0];
    signal.data = [0];
    '??? Error badly formed input file'
end

% signal is returned


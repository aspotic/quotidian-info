function y = frequencyManipulation(S, f)
    %N=2000;plot(1:1:(size(F1)),abs(fft(f.data .* (2*N*sinc((2*pi*N/110250) .* f.index)))));
    
    N = 700001;
    numSignals = 5;
    Fs = 110250;
    Range = floor(N/(numSignals*2));
    
    
    H = zeros(N,1);
    H((S-1)*Range+1:S*Range,1) = 1;
    
    h = ifft(H);
    
    y = conv(f, h);
    
   
    wavwrite(abs(y),110250,'signalout.wav');
    
    
    
    
    
    %wavwrite(abs(osig5),110250,'signal5.wav')
end
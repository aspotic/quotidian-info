%%%%%%%%%%%%%%%%%%%%%%
%Find capacitance that places the response peak the closest to the
%input frequency it should occur at.
%A good input: (200, pi/256, 31000, 0.00001, 0.0000005, 0.000005, 1000)
%%%%%%%%%%%%%%%%%%%%%%
%UILength: the length of the impulse to use in the frequency response
%omegaT: omega*T
%reqPeakInput: The input frequency the response peak should occur at
%T: the time step
%Cmin: the minimum possible capacitance
%Cmax: the maximum possible capacitance
%numSteps: how many times to increment the capacitance. Cap. granularity
%%%%%%%%%%%%%%%%%%%%%%
%C: The optimal capacitance
%inputFreqPeak: the input frequency that the peak occurs at for capacitance C
%%%%%%%%%%%%%%%%%%%%%%
function [C, inputFreqPeak] = findC(UILength, omegaT, reqPeakInput, T, Cmin, Cmax, numSteps)
    %set the inductor value
    L = 0.001;
    
    %set resistance
    R = 1;
    
    %set capacitance range
    stepSize = (Cmax-Cmin)/numSteps;
    C = Cmin;
    
    %set the filter indices
    h.index(1, 1) = 0;
    h.index(2, 1) = 1;
    h.index(3, 1) = 2;
    g.index(1, 1) = 1;
    g.index(2, 1) = 2;
    
    %Find capacitance that places the response peak the closest to inputPeak
    for cCount = 1:numSteps
        %get the filter values
        [h1, g1, g2] = getFilterCharacteristics(L, T, R, C);
        
        %Setup Filter
        h.data(1, 1) = h1;
        h.data(2, 1) = 2*h1;
        h.data(3, 1) = h1;
        g.data(1, 1) = g1;
        g.data(2, 1) = g2;

        %get the frequency response
        FR = FrequencyResponseWFeedback(UILength, omegaT, h, g);
        
        %find a peak
        indexPeak = 1;
        for j = 2:size(FR(:, 2))
            if (abs(FR(j, 2)) > abs(FR(indexPeak, 2)))
               indexPeak = j;
            end
        end
        
        %check if the peak for this cap. is closer than the current closest peak
        if (cCount == 1)
            curPeakC = C;     %the cap. that causes curPeakResponse @ curPeakInput
            curPeakInput = FR(indexPeak, 1); %the input frequency at which this peak occurrs
            
        elseif (abs(abs(FR(indexPeak, 1)) - reqPeakInput*T) < abs(abs(curPeakInput) - reqPeakInput*T))
            curPeakC = C;     %the cap. that causes curPeakResponse @ curPeakInput
            curPeakInput = FR(indexPeak, 1); %the input frequency at which this peak occurrs
        end
        
        %check the next capacitance
        C = C + stepSize;
    end
    
    inputFreqPeak = curPeakInput;
    C = curPeakC;
end
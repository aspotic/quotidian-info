%%%%%%%%%%%%%%%%%%%%%%
%Plots the applied voltage against the resistor voltage drop for an LCR
%circuit with L = 1mh; C = 0.995uF; R = 10.009 ohms; T = 0.00001s
%%%%%%%%%%%%%%%%%%%%%%
%numSteps: The number of time steps to plot. Allows one to look at x cycles
%inputPeriod: The period of the square wave driving the circuit
%V: Applied Voltage Peak Magnitude
%%%%%%%%%%%%%%%%%%%%%%
function LCR_SquareWave_ResistorPotential(numSteps, inputPeriod, V)    
    %Setup the filter
    h.index(1, 1) = 0;
    h.index(2, 1) = 1;
    h.index(3, 1) = 2;
    h.index(4, 1) = 3;
    h.data(1, 1) = 0.0465461;
    h.data(2, 1) = 0.0465461;
    h.data(3, 1) = -0.0465461;
    h.data(4, 1) = -0.0465461;
    g.index(1, 1) = 1;
    g.index(2, 1) = 2;
    g.index(3, 1) = 3;
    g.data(1, 1) = 0.813432;
    g.data(2, 1) = 0.90652;
    g.data(3, 1) = -0.906908;
    
    T = 0.00001;
    
    %Create input wave
    f.data = zeros(numSteps,1);
    f.index = zeros(numSteps,1);
    waveCount = 0;  %marks how far through current wave
    mag = 0;
    for j = 1:numSteps
       %set the wave magnitude at this time step
       f.data(j, 1) = mag;
       f.index(j, 1) = j;
       
       waveCount = waveCount + 1;
       %swap input voltage when at end or half way through a wave
       if (waveCount*T > inputPeriod/2)
           waveCount = 0;
           if (mag == 0)
                mag = V;
           else
                mag = 0;
           end
       end
    end

    %run convolution sequence
    y = feedbackconvolve(f, h, g);
    
    %plot results
    plot(y.index, y.data,'LineWidth',2);
    hold on;
    plot(f.index, f.data, 'Color','Red','LineWidth',1);
    hold off;
    title('Resistor voltage drop under applied square wave');
    
    xlabel('step k; k = t/T; T = 0.0001');
    ylabel('Blue: Resistor Voltage Drop Er[k]; Red: Applied Voltage E[k]');
end
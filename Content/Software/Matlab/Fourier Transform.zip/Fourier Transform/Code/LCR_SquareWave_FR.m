%%%%%%%%%%%%%%%%%%%%%%
%Plots the input voltage against the capacitor voltage of an LCR circuit
%A good input: (200, pi/256, 0.00001, 1 , 100, 1000, 9.9500e-007, -0.3068, 3.2)
%%%%%%%%%%%%%%%%%%%%%%
%numSteps: The number of time steps to plot. Allows one to look at x cycles
%inputPeriod: The period of the square wave driving the circuit
%L: Inductance
%C: Capacitance
%R: Resistance
%T: Time Step Size
%V: Applied Voltage Peak Magnitude
%%%%%%%%%%%%%%%%%%%%%%
function LCR_SquareWave_FR(numSteps, inputPeriod, T, L, R, C, V)
    %Find the filter characteristics
    [h1, g1, g2] = getFilterCharacteristics(L, T, R, C);
    
    %Setup the filter
    h.index(1, 1) = 0;
    h.index(2, 1) = 1;
    h.index(3, 1) = 2;
    h.data(1, 1) = h1;
    h.data(2, 1) = 2*h1;
    h.data(3, 1) = h1;
    g.index(1, 1) = 1;
    g.index(2, 1) = 2;
    g.data(1, 1) = g1;
    g.data(1, 2) = g2;
    
    %Create input wave
    f.data = zeros(numSteps,1);
    f.index = zeros(numSteps,1);
    waveCount = 0;  %marks how far through current wave
    mag = 0;
    for j = 1:numSteps
       %set the wave magnitude at this time step
       f.data(j, 1) = mag;
       f.index(j, 1) = j;
       
       waveCount = waveCount + 1;
       %swap input voltage when at end or half way through a wave
       if (waveCount*T > inputPeriod/2)
           waveCount = 0;
           if (mag == 0)
                mag = V;
           else
                mag = 0;
           end
       end
    end

    %run convolution sequence
    y = feedbackconvolve(f, h, g);
    
    %plot results
    plot(y.index, y.data,'LineWidth',2);
    hold on;
    plot(f.index, f.data, 'Color','Red','LineWidth',1);
    hold off;
    title('Capacitor voltage under applied square wave');
    
    xlabel('step k; k = t/T; T = 0.0001');
    ylabel('Blue: Capacitor Voltage Ec[k]; Red: Applied Voltage E[k]');
end
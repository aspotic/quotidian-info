%%%%%%%%%%%%%%%%%%%%%%
%Find the resistance that gives the proper ratio between the
%peak response magnitude and dc response magnitude
%A good input: (200, pi/256, 0.00001, 1 , 100, 1000, C, -0.3068, 3.2)
%%%%%%%%%%%%%%%%%%%%%%
%UILength: the length of the impulse to use in the frequency response
%omegaT: omega*T
%T: the time step
%Cmin: the minimum possible resistance
%Cmax: the maximum possible resistance
%numSteps: how many times to increment the resistance. Res. granularity
%C: the capacitance of the circuit
%inputFreqPeak: the input frequency at which the response peak occurs
%ratio: the required peak to DC response magnitude ratio (peak mag/DC mag = ratio)
%%%%%%%%%%%%%%%%%%%%%%
%R: The optimal resistance for the given ratio
%%%%%%%%%%%%%%%%%%%%%%
function R = findR(UILength, omegaT, T, Rmin, Rmax, numSteps, C, inputFreqPeak, ratio)
    %set the inductor value
    L = 0.001;
    
    %set capacitance range;
    stepSize = (Rmax-Rmin)/numSteps;
    R = Rmin;
    
    %set the filter indices
    h.index(1, 1) = 0;
    h.index(2, 1) = 1;
    h.index(3, 1) = 2;
    g.index(1, 1) = 1;
    g.index(2, 1) = 2;
    
    %Find the resistance that gives the proper ratio between the
    %peak response magnitude and dc response magnitude
    for rCount = 1:numSteps
        %get the filter values
        [h1, g1, g2] = getFilterCharacteristics(L, T, R, C);
        
        %Setup Filter
        h.data(1, 1) = h1;
        h.data(2, 1) = 2*h1;
        h.data(3, 1) = h1;
        g.data(1, 1) = g1;
        g.data(2, 1) = g2;

        %get the frequency response
        FR = FrequencyResponseWFeedback(UILength, omegaT, h, g);
        
        %find where the peak response and zero response are in the FR array
        if (rCount == 1)
            for j = 1:size(FR(:,2))
                if (FR(j,1) == inputFreqPeak)
                    peakIndex = j;
                end
                if (FR(j,1) == 0)
                    DCIndex = j;
                end
            end
            
            curBestR = R;     
            curBestRatio = abs(FR(peakIndex, 2))/abs(FR(DCIndex, 2));
        end
        
        %get the peak response magnitude
        peakResponseMag = abs(FR(peakIndex, 2));
        
        %get the DC response magnitude
        DCResponseMag = abs(FR(DCIndex, 2));
        
        %set the ratio for the current resistance
        curRatio = peakResponseMag/DCResponseMag;
        
        %check if the the ratio is better than the previously best ratio
        if (abs(curBestRatio - ratio) > abs(curRatio - ratio))
            curBestR = R;     
            curBestRatio = curRatio;
        end
        
        %check the next capacitance
        R = R + stepSize;
    end
    
    R = curBestR;
end
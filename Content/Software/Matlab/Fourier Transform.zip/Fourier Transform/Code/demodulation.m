%Separates a specific signal being carried at Fc out of a mix of multiple
%signals carried and different frequencies. The input sequence y is sampled
%at Fs steps/second. filename is the name used for saving the wav file
%containing the separated signal. The returned value z is the separated out
%signal's sequence sampled at Fs.
function z = demodulation(filename, Fc, Fs, y)
    %find low pass filter design that matches the required cutoff frequency
    R = 1;
    T = 1/Fs;
    %cutoff frequency should be 10000Hz because the channels are separated
    %by 10000Hz, and only the data for a single channel should be kept.
    C = 1/(2*pi*R*5000);

    %find convolution terms
    h.data = [((T*C)/(T+2*R*C)); ((T*C)/(T+2*R*C))];
    h.index = [0; 1];
    
    %find feedback terms
    g.data = ((2*R*C-T)/(T+2*R*C));
    g.index = 0;
    
    %shift magnitudes in frequency domain so the required carrier frequency
    %is shifted to zero where the low pass filter will not cut its data
    %the 50000 just scales it so it is easier to hear.
    y.data = 50000 * y.data .* cos((2*pi*Fc)*(y.index/Fs));
    
    %convolve shifted data to filter out sound from other channels
    z = feedbackconvolve(y, h, g);
    
    %create wav file
    wavwrite(z.data, 110250, filename);
end